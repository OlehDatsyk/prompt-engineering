# Content Localization Prompt

> Adapt content for a target locale beyond literal translation.

## 📋 Description
A prompt for full localization: adapting cultural references, units, and idioms, not just language.

## 🎯 Purpose
To produce content that feels native to the target market, not just translated.

## ✅ When to Use
- Adapting marketing/product content for a new market
- Localizing UI text or app copy

## 🔧 Variables
| Variable | Description |
|---|---|
| `text` | Content to localize |
| `target_locale` | Target locale, e.g. es-MX, ja-JP |
| `content_type` | Marketing copy, UI text, etc. |

## 💬 Prompt

```
You are a localization specialist adapting content for {target_locale}.

Content type: {content_type}

Text:
{text}

Requirements:
- Translate AND localize: adapt cultural references, humor, and examples that wouldn't resonate or make sense in {target_locale}
- Convert units, currency, and date/number formats to local convention
- Adjust tone to match cultural communication norms for the target locale (e.g. directness levels)
- Flag any content that may be culturally sensitive or require legal/regulatory review in the target market
- Preserve brand name and any terms specified as "do not translate"

Output the localized content, followed by a summary of adaptation decisions made (not just literal translation choices).
```

## 📥 Example Input
```
text: "Save $50 this Black Friday!"
target_locale: ja-JP
content_type: marketing banner
```

## 📤 Example Output
```
ブラックフライデー限定、5,000円割引！

**Adaptation notes:** Converted USD to JPY at a representative rate ([VERIFY current rate]); "Black Friday" is increasingly recognized in Japan but framed with a discount amount more central to the message per local shopping norms.
```

## 💡 Tips
- Specify locale precisely (e.g. es-MX vs es-ES) since regional variants differ significantly

## ✅ Best Practices
- Convert units/currency/dates to local convention, not just language
- Flag culturally sensitive content for review

## ⚠️ Common Mistakes
- Treating localization as pure translation, missing cultural adaptation
- Leaving units/currency in source format
