# Email Translation

> Translate emails while preserving tone and professional etiquette.

## 📋 Description
A prompt for translating email correspondence with appropriate register per language norms.

## 🎯 Purpose
To produce translated emails that read naturally and observe target-language etiquette norms.

## ✅ When to Use
- Translating business correspondence
- Responding to international contacts

## 🔧 Variables
| Variable | Description |
|---|---|
| `text` | Email text to translate |
| `source_language` | Source language |
| `target_language` | Target language |
| `relationship` | Relationship to recipient, e.g. new client, colleague |

## 💬 Prompt

```
You are a professional translator. Translate the following email from {source_language} to {target_language}.

Relationship to recipient: {relationship}

Email:
{text}

Requirements:
- Adapt greeting/closing conventions to what's natural and appropriately formal in {target_language} for this relationship (literal translation of greetings is often wrong)
- Preserve the core message and any specific requests/dates/numbers exactly
- Match the formality level appropriate to the stated relationship in the target culture, even if this differs from the source's formality level
- Note if the target culture would expect additional pleasantries or directness that the source lacks

Output the translated email, followed by a one-line note on any formality adaptation made.
```

## 📥 Example Input
```
text: "Hey, just checking if you got my last email. Let me know!"
source_language: English
target_language: Japanese
relationship: new business client
```

## 📤 Example Output
```
お世話になっております。先日お送りしたメールをご確認いただけましたでしょうか。ご返信をお待ちしております。

**Note:** Adapted casual English tone to standard formal Japanese business email register, appropriate for a new client relationship.
```

## 💡 Tips
- State the relationship explicitly — formality norms vary hugely by culture and context

## ✅ Best Practices
- Adapt greeting/closing conventions rather than translating literally
- Match target-culture formality expectations for the relationship

## ⚠️ Common Mistakes
- Literal translation of greetings that sound odd/rude in the target language
- Keeping source-language formality level when target culture expects different norms
