# Website Content Translation

> Translate website copy while preserving UX and SEO intent.

## 📋 Description
A prompt for translating web copy with attention to UI constraints and local SEO.

## 🎯 Purpose
To produce translations that work within UI space constraints and support local SEO.

## ✅ When to Use
- Translating a website for a new market
- Localizing UI microcopy (buttons, labels)

## 🔧 Variables
| Variable | Description |
|---|---|
| `text` | Website copy to translate |
| `target_language` | Target language |
| `content_type` | Page copy, UI labels, or SEO metadata |
| `space_constraints` | Character limits, if any, e.g. button labels |

## 💬 Prompt

```
You are a web localization specialist. Translate the following website content into {target_language}.

Content type: {content_type}
Space constraints: {space_constraints}

Text:
{text}

Requirements:
- Respect stated character/space constraints (critical for buttons/labels/navigation)
- If a literal translation exceeds the constraint, provide a shorter natural equivalent, not a truncation
- For SEO metadata (titles/descriptions), research-appropriate target-language keywords if a target keyword is given, don't just translate the source keyword literally
- Keep placeholder variables (e.g. {{username}}) unmodified and in the correct grammatical position for the target language
- Flag any UI string where literal translation would break layout expectations

Output the translation followed by a note on any strings that needed shortening or restructuring.
```

## 📥 Example Input
```
text: "Add to Cart"
target_language: German
content_type: button label
space_constraints: max 20 characters
```

## 📤 Example Output
```
"In den Warenkorb" (18 characters)

**Note:** Fits within constraint; standard German e-commerce convention rather than literal "Zum Warenkorb hinzufügen" which would exceed the limit.
```

## 💡 Tips
- Always state character constraints for UI elements — German/Finnish etc. often run longer than English

## ✅ Best Practices
- Prefer natural shorter equivalents over truncating literal translations
- Keep placeholder variables grammatically correct in position

## ⚠️ Common Mistakes
- Literal translations that break UI layout due to length
- Breaking placeholder variable syntax during translation
