# Technical Document Translation

> Translate technical documentation with precision and consistent terminology.

## 📋 Description
A prompt for translating technical/engineering content with strict terminology consistency.

## 🎯 Purpose
To produce technically accurate translations of specifications, manuals, or documentation.

## ✅ When to Use
- Translating user manuals or technical specs
- Translating API/software documentation

## 🔧 Variables
| Variable | Description |
|---|---|
| `text` | Technical text to translate |
| `source_language` | Source language |
| `target_language` | Target language |
| `glossary` | Key terms that must be translated consistently |

## 💬 Prompt

```
You are a technical translator specializing in {source_language} to {target_language} translation.

Text:
{text}

Required glossary (use these exact translations for these terms, consistently): {glossary}

Requirements:
- Prioritize precision over stylistic elegance — technical accuracy matters most
- Use the provided glossary terms consistently throughout; do not vary translation of the same term
- Preserve code snippets, variable names, file paths, and commands exactly unmodified
- Preserve numbered steps and formatting structure exactly
- Flag any technical term not in the glossary where multiple valid translations exist, and state which you chose and why

Output the translation, followed by a glossary consistency confirmation.
```

## 📥 Example Input
```
text: "Click Save to commit your changes to the repository."
source_language: English
target_language: Spanish
glossary: repository=repositorio, commit=confirmar
```

## 📤 Example Output
```
Haga clic en Guardar para confirmar sus cambios en el repositorio.

**Glossary check:** "repository" → "repositorio" ✓, "commit" → "confirmar" ✓ (used consistently).
```

## 💡 Tips
- Always provide a glossary for recurring technical terms to ensure consistency across a document set

## ✅ Best Practices
- Keep code/commands/paths untranslated and unmodified
- Enforce glossary term consistency throughout

## ⚠️ Common Mistakes
- Translating variable names, code, or file paths
- Inconsistent translation of the same technical term across a document
