# Markdown Document Translation

> Translate Markdown documents while preserving all formatting.

## 📋 Description
A prompt for translating Markdown-formatted content without breaking syntax.

## 🎯 Purpose
To produce translated Markdown that renders identically in structure to the source.

## ✅ When to Use
- Translating documentation written in Markdown
- Translating README files or Markdown-based content

## 🔧 Variables
| Variable | Description |
|---|---|
| `text` | Markdown text to translate |
| `source_language` | Source language |
| `target_language` | Target language |

## 💬 Prompt

```
You are a technical translator. Translate the following Markdown document from {source_language} to {target_language}.

Markdown:
{text}

Requirements:
- Preserve ALL Markdown syntax exactly: headers (#), links [text](url), code blocks, tables, bold/italic markers
- Translate only the human-readable text content, never the syntax characters or URLs
- Keep code blocks completely untranslated (including comments inside code, unless explicitly requested)
- Preserve table structure (pipes and alignment) exactly, translating only cell text content
- Preserve link URLs unchanged; translate only the link display text

Output only the translated Markdown, with syntax fully intact and renderable.
```

## 📥 Example Input
```
text: "# Getting Started\n\nSee the [installation guide](/docs/install) for details."
source_language: English
target_language: French
```

## 📤 Example Output
```
# Pour commencer

Consultez le [guide d'installation](/docs/install) pour plus de détails.
```

## 💡 Tips
- Explicitly state whether code comments should be translated or left as-is

## ✅ Best Practices
- Never alter URLs or Markdown syntax characters
- Keep code blocks untranslated by default

## ⚠️ Common Mistakes
- Translating text inside code blocks unintentionally
- Breaking table alignment or link syntax during translation
