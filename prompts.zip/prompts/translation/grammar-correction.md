# Grammar & Style Correction

> Correct grammar, spelling, and style issues while preserving voice.

## 📋 Description
A prompt for correcting language errors without rewriting the author's voice.

## 🎯 Purpose
To fix errors while preserving the original author's tone and intent.

## ✅ When to Use
- Proofreading written content
- Correcting non-native speaker writing

## 🔧 Variables
| Variable | Description |
|---|---|
| `text` | Text to correct |
| `language` | Language of the text |
| `preserve_voice` | Whether to preserve informal/personal voice or standardize fully |

## 💬 Prompt

```
You are a professional editor. Correct grammar, spelling, and punctuation in the following {language} text.

Text:
{text}

Preserve original voice/style: {preserve_voice}

Requirements:
- Fix only genuine errors (grammar, spelling, punctuation, subject-verb agreement)
- Do not rewrite sentences stylistically unless they contain an actual error
- Preserve the author's voice, tone, and word choice where preserve_voice is set to preserve it
- Provide the corrected text first
- Then list each correction made with a brief explanation, so the writer can learn from it

Do not change meaning while correcting.
```

## 📥 Example Input
```
text: "Me and my team is working on this project since three months."
language: English
preserve_voice: preserve casual tone
```

## 📤 Example Output
```
**Corrected:** "My team and I have been working on this project for three months."

**Corrections:**
1. "Me and my team is" → "My team and I have" (subject pronoun + subject-verb agreement)
2. "since three months" → "for three months" (correct preposition for duration)
```

## 💡 Tips
- State explicitly whether to preserve informal voice, or the model may over-formalize

## ✅ Best Practices
- Explain each correction so the writer learns from it
- Avoid stylistic rewrites beyond fixing genuine errors

## ⚠️ Common Mistakes
- Over-correcting into an overly formal register when informal voice should be preserved
- Silently changing meaning while 'fixing' a sentence
