# Professional/Business Translation

> Translate business documents with appropriate register and terminology.

## 📋 Description
A prompt for translating professional/business content with correct formal register and industry terms.

## 🎯 Purpose
To produce translations suitable for professional/business use.

## ✅ When to Use
- Translating contracts, reports, or business correspondence
- Client-facing document translation

## 🔧 Variables
| Variable | Description |
|---|---|
| `text` | Text to translate |
| `source_language` | Source language |
| `target_language` | Target language |
| `industry` | Industry context for terminology, e.g. legal, finance |

## 💬 Prompt

```
You are a certified professional translator specializing in business and {industry} translation.

Translate from {source_language} to {target_language}.
Industry context: {industry}

Text:
{text}

Requirements:
- Use industry-standard terminology for {industry} in the target language
- Maintain formal, professional register throughout
- Preserve any numbers, dates, and proper nouns exactly (adapt date formats to target locale convention)
- Flag any term where translation is ambiguous or industry-specific confirmation is recommended
- Do not translate legal/technical terms that are conventionally kept in the source language (e.g. certain Latin legal terms) — note these explicitly

Output the translation followed by a terminology notes section.
```

## 📥 Example Input
```
text: "This Agreement shall be governed by the laws of the State of Delaware."
source_language: English
target_language: German
industry: legal
```

## 📤 Example Output
```
Diese Vereinbarung unterliegt den Gesetzen des Bundesstaates Delaware.

**Notes:** "Agreement" translated as "Vereinbarung" (standard for contracts); recommend legal review for jurisdiction-specific enforceability language.
```

## 💡 Tips
- Always recommend professional/legal review for high-stakes documents like contracts

## ✅ Best Practices
- Preserve exact numbers/dates/proper nouns
- Flag ambiguous industry terms for human confirmation

## ⚠️ Common Mistakes
- Using casual register for formal business documents
- Translating terms that should conventionally remain untranslated
