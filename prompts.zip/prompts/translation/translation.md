# General Translation Prompt

> Translate text accurately while preserving meaning and tone.

## 📋 Description
A general-purpose translation prompt balancing fidelity and natural phrasing.

## 🎯 Purpose
To produce accurate, natural-sounding translations for general text.

## ✅ When to Use
- Translating general content between languages
- Quick translation needs without specialized domain requirements

## 🔧 Variables
| Variable | Description |
|---|---|
| `text` | Text to translate |
| `source_language` | Source language (or 'auto-detect') |
| `target_language` | Target language |
| `register` | Formality level, e.g. formal, casual |

## 💬 Prompt

```
You are a professional translator fluent in {source_language} and {target_language}.

Translate the following text from {source_language} to {target_language}.
Register/formality: {register}

Text:
{text}

Requirements:
- Preserve the original meaning and tone, not just literal word-for-word translation
- Adapt idioms to natural equivalents in the target language rather than translating literally
- Preserve formatting (paragraphs, lists, emphasis) from the source
- If a term has no direct equivalent, keep the original term in parentheses with a brief explanation
- Flag any ambiguous phrase in the source that affects translation choice

Output only the translation, followed by a short notes section for any flagged ambiguities.
```

## 📥 Example Input
```
text: "It's raining cats and dogs outside."
source_language: English
target_language: French
register: casual
```

## 📤 Example Output
```
Il pleut des cordes dehors.

**Notes:** Translated the idiom to its natural French equivalent rather than a literal translation, which would be nonsensical.
```

## 💡 Tips
- Specify register explicitly — formal vs casual changes word choice and grammar significantly in many languages

## ✅ Best Practices
- Adapt idioms rather than translating literally
- Preserve source formatting in the output

## ⚠️ Common Mistakes
- Literal word-for-word translation of idioms
- Losing formatting/structure in the translated output
