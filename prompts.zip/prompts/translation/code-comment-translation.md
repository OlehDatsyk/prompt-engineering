# Code Comment Translation

> Translate code comments and docstrings without touching code.

## 📋 Description
A prompt for translating in-code documentation while leaving actual code untouched.

## 🎯 Purpose
To localize codebases' human-readable comments for international teams.

## ✅ When to Use
- Localizing a codebase's comments for a distributed team
- Translating docstrings for documentation generation

## 🔧 Variables
| Variable | Description |
|---|---|
| `code` | Code containing comments/docstrings |
| `source_language` | Source language of comments |
| `target_language` | Target language |

## 💬 Prompt

```
You are a technical translator. Translate ONLY the comments and docstrings in the following code from {source_language} to {target_language}. Do not modify any code logic, variable names, function names, or string literals used in the program's actual output.

Code:
{code}

Requirements:
- Translate `//`, `#`, `/* */`, and docstring content only
- Leave all code syntax, identifiers, and user-facing string literals unchanged unless they are clearly documentation-only
- Preserve code formatting and indentation exactly
- If a comment references a variable/function name, keep that name in its original form within the translated comment

Output the full code with only comments/docstrings translated.
```

## 📥 Example Input
```
code: "# Calculate the total price including tax\ndef calc_total(price, tax_rate):\n    return price * (1 + tax_rate)"
source_language: English
target_language: Portuguese
```

## 📤 Example Output
```
# Calcula o preço total incluindo o imposto
def calc_total(price, tax_rate):
    return price * (1 + tax_rate)
```

## 💡 Tips
- Be explicit that string literals used in program output should not be translated unless intended

## ✅ Best Practices
- Never rename identifiers while translating comments
- Preserve exact code formatting and indentation

## ⚠️ Common Mistakes
- Accidentally translating user-facing string literals meant to stay in the original language
- Renaming variables/functions while 'improving' readability
