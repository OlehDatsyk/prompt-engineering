# Tone Adjustment / Register Shift

> Adjust the tone/formality of translated or existing text.

## 📋 Description
A prompt for shifting the tone of text (formal/casual, warm/direct) while preserving meaning, within or across languages.

## 🎯 Purpose
To adapt existing text to a different tone or formality register without changing its meaning.

## ✅ When to Use
- Making a formal document sound more approachable
- Formalizing casual writing for a professional context

## 🔧 Variables
| Variable | Description |
|---|---|
| `text` | Text to adjust |
| `current_tone` | Current tone of the text |
| `target_tone` | Desired tone |
| `language` | Language of the text |

## 💬 Prompt

```
You are a professional editor skilled at tone adaptation in {language}.

Text:
{text}

Current tone: {current_tone}
Target tone: {target_tone}

Requirements:
- Preserve the exact meaning and all factual content — only tone/register should change
- Adjust word choice, sentence length, and formality markers to match the target tone
- Do not add or remove information, only rephrase
- If the target tone requires structural changes (e.g. shorter sentences for casual), make them
- Provide a brief note on the key changes made to shift tone

Output the adjusted text, followed by the tone-shift notes.
```

## 📥 Example Input
```
text: "We regret to inform you that your request has been denied due to insufficient documentation."
current_tone: formal, bureaucratic
target_tone: warm but still professional
language: English
```

## 📤 Example Output
```
Unfortunately, we're not able to approve your request yet — we're missing a few documents. Once we receive them, we'll be happy to take another look.

**Notes:** Replaced passive/bureaucratic phrasing with direct, warmer language while keeping the core message (denial pending documentation) unchanged.
```

## 💡 Tips
- Specify both current and target tone explicitly for a clear before/after contrast

## ✅ Best Practices
- Preserve all factual content exactly while shifting tone
- Explain the specific changes made to shift register

## ⚠️ Common Mistakes
- Adding or removing information while adjusting tone
- Overcorrecting into a tone more extreme than requested
