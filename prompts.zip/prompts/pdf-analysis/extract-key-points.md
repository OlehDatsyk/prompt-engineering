# Key Points Extractor

> Extract the most important points from a document as a clean list.

## 📋 Description
A prompt for pulling out discrete, actionable key points from lengthy PDF content.

## 🎯 Purpose
To convert long-form content into a scannable list of key points.

## ✅ When to Use
- Prepping notes from a long document
- Extracting takeaways for a team update

## 🔧 Variables
| Variable | Description |
|---|---|
| `document_text` | Extracted PDF text |
| `num_points` | Approximate number of points wanted |
| `audience` | Who will read the extracted points |

## 💬 Prompt

```
You are an analyst extracting key points for {audience}.

Document:
{document_text}

Extract approximately {num_points} key points.

Requirements:
- Each point should be a single, self-contained idea (no compound points)
- Order points by importance, not by document order
- Use direct, concise language — no filler phrasing
- Attribute each point to its source section if the document is long/multi-section
- Do not include points that are not explicitly supported by the document text
```

## 📥 Example Input
```
document_text: [board meeting minutes, 8 pages]
num_points: 8
audience: executive team
```

## 📤 Example Output
```
1. Budget for Q4 marketing was approved at $250K (Section: Finance)
2. The product launch was delayed to January due to supply chain issues (Section: Operations)
...
```

## 💡 Tips
- Specify the audience — executives want different granularity than a working team

## ✅ Best Practices
- Keep each point atomic and self-contained
- Order by importance, not document order

## ⚠️ Common Mistakes
- Compound points bundling multiple ideas together
- Including unsupported inference as if it were a stated point
