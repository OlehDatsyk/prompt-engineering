# PDF Summarizer

> Summarize a PDF document into key points.

## 📋 Description
A prompt for producing an accurate, structured summary of a PDF's content.

## 🎯 Purpose
To quickly understand the core content of a long document.

## ✅ When to Use
- Reviewing a long report before a meeting
- Getting the gist of a document before deep reading

## 🔧 Variables
| Variable | Description |
|---|---|
| `document_text` | Extracted text content of the PDF |
| `length` | Target summary length |
| `focus` | Specific focus area, if any |

## 💬 Prompt

```
You are a professional analyst. Summarize the following document.

Document:
{document_text}

Target summary length: {length}
Focus area (if any): {focus}

Requirements:
- Summarize only what is stated in the document — do not add outside information or inference presented as fact
- Organize by section if the document has clear sections
- Preserve any critical numbers, dates, or names exactly as written
- Note if any section is ambiguous or the extracted text seems incomplete/garbled (common with PDF extraction)
- End with a 3-bullet "key takeaways" section
```

## 📥 Example Input
```
document_text: [12-page quarterly report]
length: one page
focus: financial performance
```

## 📤 Example Output
```
## Summary
The report covers Q3 performance across three business units...

## Key Takeaways
- Revenue grew 8% YoY
- Operating margin declined due to increased logistics costs
- [Note: page 7 table appears to have extraction artifacts, verify against original]
```

## 💡 Tips
- Note that PDF text extraction can be imperfect — ask the model to flag garbled sections

## ✅ Best Practices
- Never let the model add outside information not in the document
- Preserve exact numbers/dates from the source

## ⚠️ Common Mistakes
- Treating garbled extraction artifacts as real content without flagging
- Summarizing so briefly that key nuance is lost
