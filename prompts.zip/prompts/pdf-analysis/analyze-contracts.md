# Contract Analysis Assistant

> Analyze a contract for key terms, obligations, and risk areas.

## 📋 Description
A prompt for structured contract review highlighting key clauses and potential concerns.

## 🎯 Purpose
To surface key terms and risk areas in a contract for review (not as a substitute for legal advice).

## ✅ When to Use
- Reviewing a contract before signing
- Summarizing contract terms for stakeholders

## 🔧 Variables
| Variable | Description |
|---|---|
| `document_text` | Contract text |
| `party_perspective` | Which party's interest to analyze from |
| `focus_areas` | Specific clause types to prioritize, if any |

## 💬 Prompt

```
You are a contract analyst. Note: this analysis is for informational review purposes only and is not a substitute for review by a licensed attorney.

Contract text:
{document_text}

Analyzing from the perspective of: {party_perspective}
Focus areas (if any): {focus_areas}

Provide:
1. Summary of the contract's core purpose and parties involved
2. Key obligations for each party
3. Important dates/deadlines (effective date, termination, renewal, notice periods)
4. Payment terms
5. Termination and liability/indemnification clauses, summarized in plain language
6. Clauses that may be unfavorable to {party_perspective}, with a plain-language explanation of the risk
7. Explicit recommendation to have a qualified attorney review before signing, especially for flagged items

Do not provide definitive legal conclusions — describe what the text says and flag areas warranting professional legal review.
```

## 📥 Example Input
```
document_text: [SaaS vendor agreement]
party_perspective: the customer
focus_areas: liability and termination
```

## 📤 Example Output
```
**Core purpose:** SaaS subscription agreement between Vendor Inc. and Customer for use of [Product].

**Potentially unfavorable clause:** Section 8 limits vendor liability to fees paid in the last 3 months — recommend legal review given the scope of data handled.

**Recommendation:** Have a licensed attorney review Sections 8 and 12 before signing.
```

## 💡 Tips
- Always pair this with actual legal review for any binding agreement

## ✅ Best Practices
- Explicitly disclaim that this is not legal advice
- Flag unfavorable clauses in plain language, not just legal jargon

## ⚠️ Common Mistakes
- Presenting analysis as definitive legal advice
- Missing key risk clauses buried in dense legal language
