# Quiz from PDF

> Generate a quiz directly from document content.

## 📋 Description
A prompt for producing a quiz grounded strictly in a given PDF's content.

## 🎯 Purpose
To create assessment material based on specific source material.

## ✅ When to Use
- Testing comprehension of a specific reading
- Creating a quiz from training material

## 🔧 Variables
| Variable | Description |
|---|---|
| `document_text` | Extracted document text |
| `num_questions` | Number of questions |
| `question_types` | Question format(s) desired |

## 💬 Prompt

```
You are an assessment designer. Create a quiz based strictly on the following document.

Document:
{document_text}

Number of questions: {num_questions}
Question types: {question_types}

Requirements:
- Every question and correct answer must be verifiable directly from the document text — no outside knowledge
- Vary question difficulty (some direct recall, some requiring synthesis of two parts of the document)
- For multiple choice, distractors should be plausible but clearly wrong upon careful reading of the source
- Provide an answer key citing the relevant part of the document for each answer
```

## 📥 Example Input
```
document_text: [policy document PDF]
num_questions: 6
question_types: multiple choice
```

## 📤 Example Output
```
1. According to the document, what is the notice period for cancellation?
   A) 7 days B) 14 days C) 30 days D) 60 days

**Answer Key:** 1. C — stated in Section 4: "a 30-day written notice is required"
```

## 💡 Tips
- Restrict explicitly to document content to prevent hallucinated questions

## ✅ Best Practices
- Cite the document location for every answer key entry
- Make distractors plausible but verifiably wrong

## ⚠️ Common Mistakes
- Including questions answerable only with outside knowledge, not the source
- Vague answer keys without document citations
