# Financial Report Analysis

> Analyze a financial report for key metrics and trends.

## 📋 Description
A prompt for structured extraction and analysis of financial report content.

## 🎯 Purpose
To quickly surface key financial metrics and trends from a report (not investment advice).

## ✅ When to Use
- Reviewing quarterly/annual reports
- Preparing a financial summary for stakeholders

## 🔧 Variables
| Variable | Description |
|---|---|
| `document_text` | Financial report text |
| `focus_metrics` | Specific metrics of interest, if any |

## 💬 Prompt

```
You are a financial analyst. Note: this analysis is for informational purposes only and is not personalized investment or financial advice.

Report text:
{document_text}

Focus metrics (if any): {focus_metrics}

Provide:
1. Key financial metrics as stated in the report (revenue, net income, margins, cash flow) — preserve exact figures
2. Period-over-period trend (growth/decline) based only on figures present in the document
3. Notable one-time items or unusual entries called out
4. Management's stated explanation for key changes, clearly attributed as their statement, not verified fact
5. Areas where the report itself flags risk or uncertainty
6. A note that this summary should not be used as the sole basis for investment decisions

Do not invent figures not present in the document. Do not provide buy/sell/hold recommendations.
```

## 📥 Example Input
```
document_text: [Q2 earnings report]
focus_metrics: revenue growth, margins
```

## 📤 Example Output
```
**Revenue:** $45.2M, up 12% YoY (stated in report, p.3)
**Gross margin:** 62%, down from 65% last year — management attributes this to increased shipping costs (their stated explanation, p.4)

**Note:** This summary is informational only; not investment advice.
```

## 💡 Tips
- Always disclaim that this is not investment advice, and avoid recommendation language

## ✅ Best Practices
- Preserve exact figures from the source
- Attribute management explanations as their claims, not verified fact

## ⚠️ Common Mistakes
- Providing buy/sell recommendations, which crosses into investment advice
- Inventing or rounding figures not precisely stated in the source
