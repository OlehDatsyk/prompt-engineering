# Research Paper Analysis

> Break down an academic paper's methodology, findings, and limitations.

## 📋 Description
A prompt for structured, critical analysis of academic research papers.

## 🎯 Purpose
To quickly and critically understand a research paper's contribution and limitations.

## ✅ When to Use
- Reviewing a paper for a literature review
- Evaluating research before citing it

## 🔧 Variables
| Variable | Description |
|---|---|
| `document_text` | Paper text |
| `reader_background` | Reader's familiarity with the field |

## 💬 Prompt

```
You are a research analyst with expertise in critically evaluating academic papers.

Paper text:
{document_text}

Reader background: {reader_background}

Provide:
1. Research question/hypothesis (plain language)
2. Methodology summary — study design, sample size, key methods
3. Key findings, stated precisely (preserve actual reported numbers/effect sizes)
4. Limitations the authors themselves acknowledge
5. Additional methodological concerns you notice (e.g. small sample, no control group), clearly labeled as your own critical assessment, not the authors' claims
6. How this fits into the broader field, if statable from the text alone (no outside literature claims not in the paper)

Do not overstate certainty of findings beyond what the paper itself supports (e.g. correlation vs. causation).
```

## 📥 Example Input
```
document_text: [psychology study on sleep and memory]
reader_background: graduate student, familiar with basic stats
```

## 📤 Example Output
```
**Research question:** Does sleep deprivation impair working memory consolidation?

**Methodology:** N=45, within-subjects design, PSQI-screened participants...

**Critical note (my assessment, not the authors'):** The sample skews heavily toward college-age adults, limiting generalizability to other age groups.
```

## 💡 Tips
- Explicitly separate the paper's own stated limitations from your own critical assessment

## ✅ Best Practices
- Preserve exact reported statistics/effect sizes
- Never claim causation when the paper only supports correlation

## ⚠️ Common Mistakes
- Overstating findings' certainty beyond what the study design supports
- Blending the authors' stated limitations with your own critique without distinguishing them
