# Flashcards from PDF

> Generate study flashcards directly from PDF/document content.

## 📋 Description
A prompt for converting document content into flashcards for study.

## 🎯 Purpose
To turn source material into active-recall study flashcards.

## ✅ When to Use
- Studying from a textbook chapter PDF
- Converting lecture slides into review cards

## 🔧 Variables
| Variable | Description |
|---|---|
| `document_text` | Extracted document text |
| `num_cards` | Number of flashcards to generate |

## 💬 Prompt

```
You are a learning science specialist. Create flashcards from the following document.

Document:
{document_text}

Number of cards: {num_cards}

Requirements:
- Base every card strictly on content explicitly present in the document — no outside knowledge added
- Each card should test one atomic fact/concept
- Prioritize the most important/testable content, not trivial details
- Format: Front (question) | Back (concise answer)
- Order from foundational to advanced concepts as they appear in the document's logic, not necessarily document order
```

## 📥 Example Input
```
document_text: [chapter PDF on cellular respiration]
num_cards: 10
```

## 📤 Example Output
```
1. Front: What are the three main stages of cellular respiration? | Back: Glycolysis, the Krebs cycle, and oxidative phosphorylation.
2. Front: Where does glycolysis occur in the cell? | Back: The cytoplasm.
```

## 💡 Tips
- Explicitly restrict to document content only — otherwise the model may blend in outside knowledge

## ✅ Best Practices
- Keep every card grounded strictly in the source document
- One atomic fact per card

## ⚠️ Common Mistakes
- Blending in outside knowledge not present in the source document
- Testing trivial details instead of core concepts
