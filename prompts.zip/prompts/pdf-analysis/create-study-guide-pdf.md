# Study Guide from PDF

> Convert a PDF document into an organized study guide.

## 📋 Description
A prompt for restructuring source document content into a study-friendly guide.

## 🎯 Purpose
To transform dense source material into an organized review resource.

## ✅ When to Use
- Preparing to study from an assigned reading
- Converting reference material into review notes

## 🔧 Variables
| Variable | Description |
|---|---|
| `document_text` | Extracted document text |
| `focus` | Specific focus areas, if any |

## 💬 Prompt

```
You are a study skills expert. Convert the following document into a study guide.

Document:
{document_text}

Focus (if any): {focus}

Requirements:
- Organize by topic/section with clear headings, reorganizing for logical flow if the source is not well-organized
- Bold and define key terms on first use
- Include a "key facts/formulas" quick-reference block if the document contains any
- Include 3-5 self-check questions per section based only on the source content
- Do not add information not present in the source document
```

## 📥 Example Input
```
document_text: [textbook chapter on supply chains]
focus: none, cover the whole chapter
```

## 📤 Example Output
```
## Supply Chain Fundamentals
**Key term: Bullwhip effect** — the amplification of demand variability upstream in a supply chain.

**Self-check:** What causes the bullwhip effect according to this chapter?
```

## 💡 Tips
- If the source is disorganized, ask explicitly for logical reorganization rather than following source order

## ✅ Best Practices
- Ground all content strictly in the source document
- Include self-check questions per section

## ⚠️ Common Mistakes
- Adding outside information not present in the source
- Following a disorganized source's structure without improving it
