# Table Extractor

> Extract tabular data from a PDF into a clean structured format.

## 📋 Description
A prompt for converting PDF table content into clean Markdown or CSV format.

## 🎯 Purpose
To convert visually-formatted PDF tables into structured, reusable data.

## ✅ When to Use
- Pulling data tables out of reports for analysis
- Converting PDF tables to spreadsheet-ready format

## 🔧 Variables
| Variable | Description |
|---|---|
| `document_text` | Extracted PDF text containing the table(s) |
| `output_format` | Markdown table or CSV |
| `table_description` | Which table(s) to extract, if multiple |

## 💬 Prompt

```
You are a data extraction specialist. Extract tabular data from the following document text.

Document text:
{document_text}

Target table(s): {table_description}
Output format: {output_format}

Requirements:
- Preserve exact column headers and row values as they appear
- If a cell value is ambiguous due to extraction artifacts, mark it [UNCLEAR: best guess] rather than silently guessing
- Maintain correct row/column alignment even if the source formatting was irregular
- If multiple tables are present, output each separately with a label
- Do not perform any calculations or add derived columns unless explicitly requested
```

## 📥 Example Input
```
document_text: [PDF text with a pricing table]
output_format: Markdown table
table_description: the pricing tier table
```

## 📤 Example Output
```
| Tier | Price | Users |
|---|---|---|
| Basic | $9/mo | 1 |
| Pro | $29/mo | 5 |
| Enterprise | [UNCLEAR: extraction shows '$--'] | Unlimited |
```

## 💡 Tips
- Always ask for [UNCLEAR] flagging on ambiguous cells rather than silent guessing

## ✅ Best Practices
- Preserve exact values, don't compute or infer missing data
- Flag ambiguous extraction rather than guessing silently

## ⚠️ Common Mistakes
- Silently guessing unclear cell values as if certain
- Misaligning rows/columns from irregular source formatting
