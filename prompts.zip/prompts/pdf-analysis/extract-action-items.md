# Action Item Extractor

> Extract action items and owners from meeting notes or reports.

## 📋 Description
A prompt for pulling explicit and implicit action items out of documents.

## 🎯 Purpose
To convert meeting notes/reports into a trackable action item list.

## ✅ When to Use
- Processing meeting minutes
- Extracting follow-ups from a report or email thread

## 🔧 Variables
| Variable | Description |
|---|---|
| `document_text` | Document text to process |
| `default_owner` | Fallback if no owner is stated |

## 💬 Prompt

```
You are an executive assistant extracting action items.

Document:
{document_text}

Extract all action items, explicit or clearly implied. For each, provide: Action | Owner | Deadline (if stated) | Source context (brief quote or reference).

Requirements:
- If no owner is explicitly stated, write "{default_owner}" or "Unassigned — needs owner"
- If no deadline is stated, write "No deadline stated"
- Do not invent action items not supported by the text
- Flag items that are ambiguous about whether they're actually a commitment vs. just discussion
- Output as a table
```

## 📥 Example Input
```
document_text: [meeting notes mentioning several follow-ups]
default_owner: Unassigned — needs owner
```

## 📤 Example Output
```
| Action | Owner | Deadline | Source |
|---|---|---|---|
| Send updated proposal to client | Sarah | Friday | "Sarah, can you get that proposal out by Friday?" |
| Review budget numbers | Unassigned — needs owner | No deadline stated | "someone should look at the budget again" |
```

## 💡 Tips
- Ask explicitly for ambiguous commitment-vs-discussion items to be flagged separately

## ✅ Best Practices
- Never invent action items not supported by the text
- Always cite source context for traceability

## ⚠️ Common Mistakes
- Inventing action items implied by general discussion but not actually committed
- Missing deadline/owner fields, making items hard to track
