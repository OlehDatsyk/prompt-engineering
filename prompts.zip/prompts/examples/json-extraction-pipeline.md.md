# Example: Structured Data Extraction Pipeline

> Demonstrates `prompt-patterns/json-prompting.md` and `prompts/developer-prompts/structured-output-prompt.md` for a data pipeline use case.

## Scenario
Extracting structured lead information from unstructured contact form submissions for a CRM integration.

## Prompt
```
Extract structured lead information from the following form submission.

Return ONLY valid JSON matching this schema:
{
  "name": "string",
  "email": "string or null",
  "company": "string or null",
  "budget_mentioned": "number or null",
  "urgency": "low" | "medium" | "high" | null,
  "notes": "string — anything relevant not captured above"
}

If a field isn't present in the text, use null. Do not invent values.

Submission: "Hi, I'm Jordan from Blue Ridge Consulting. We need a solution ASAP, ideally 
within budget of around $15k. Can someone call me today?"
```

## Output
```json
{
  "name": "Jordan",
  "email": null,
  "company": "Blue Ridge Consulting",
  "budget_mentioned": 15000,
  "urgency": "high",
  "notes": "Requested a same-day call."
}
```

## Why This Works
The explicit null-handling rule prevents the model from either omitting missing fields (breaking a fixed-schema parser) or inventing plausible-but-fake values (e.g. guessing an email address). The "ASAP" and "today" language is correctly inferred as high urgency without being explicitly labeled that way in the source text — a reasonable inference clearly within the schema's intent.

## Related
`prompts/developer-prompts/structured-output-prompt.md`, `prompt-patterns/json-prompting.md`
