# Example: Full Blog Post Workflow (Prompt Chaining in Practice)

> Demonstrates `prompt-patterns/prompt-chaining.md` applied to `prompts/marketing/blog-writing.md`.

## Scenario
You need a well-researched blog post, and a single mega-prompt tends to produce shallow, generic output. This example chains three prompts together.

## Step 1 — Outline
**Prompt:**
```
Generate a 6-point outline for a blog post titled "Why Most Startups Fail at Pricing" 
targeting early-stage SaaS founders. Each point should be a distinct angle, not overlapping.
```
**Output:** A 6-point outline covering: cost-plus pricing pitfalls, value-based pricing intro, common founder mistakes, when to raise prices, communicating price changes, and a case study framework.

## Step 2 — Draft Each Section
**Prompt (repeated per outline point):**
```
Expand outline point 3 ("Common founder mistakes when setting initial pricing") into a 
200-word section. Tone: direct, experienced peer — not academic. Include one concrete example.
```

## Step 3 — Assemble & Polish
**Prompt:**
```
Combine these 6 sections into a cohesive blog post. Add a hook introduction and a conclusion 
with a clear next step for the reader. Ensure smooth transitions between sections — 
don't just concatenate them.

[PASTE ALL 6 SECTIONS]
```

## Why This Works Better Than One Prompt
Each step has a narrow, well-defined job, so quality per step is higher. The outline step prevents overlapping/repetitive sections — a common failure mode when generating a full post in one shot.

## Related
`prompts/marketing/blog-writing.md`, `prompt-patterns/prompt-chaining.md`
