# Example: Code Review Combining Role Prompting + Chain-of-Thought

> Demonstrates combining `prompt-patterns/role-prompting.md` and `prompt-patterns/chain-of-thought.md` with `prompts/programming/code-review.md`.

## Scenario
A generic "review this code" request often produces shallow, surface-level comments. Combining a specific role with explicit reasoning steps produces sharper, more actionable review feedback.

## Prompt
```
You are a senior security-focused engineer conducting a code review. You've caught 
subtle vulnerabilities that generic reviews miss, because you always reason through 
how each piece of user input flows through the system before judging it safe.

For each function below:
1. Trace where user input enters
2. Reason step by step about what happens to that input at each stage
3. Only after tracing the full flow, state whether it's safe and why

Code:
[PASTE CODE]
```

## Why This Works
- The security-focused role primes the model to prioritize a specific lens (injection, validation, access control) over generic style comments
- The explicit trace-then-judge structure (a form of chain-of-thought) prevents the model from pattern-matching "looks fine" without actually reasoning about data flow — a common source of missed vulnerabilities in unstructured review prompts

## Related
`prompts/programming/code-review.md`, `prompts/system-prompts/software-engineer.md`, `prompt-patterns/role-prompting.md`, `prompt-patterns/chain-of-thought.md`
