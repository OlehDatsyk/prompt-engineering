# Example: SQL Debugging Walkthrough

> Demonstrates `prompts/sql/debug-sql.md` on a realistic incorrect-results scenario.

## Scenario
A report is showing inflated revenue totals and the analyst doesn't know why.

## Prompt
```
You are a database debugging expert. Diagnose the following issue.

Query:
SELECT c.region, SUM(o.total) as revenue
FROM customers c
JOIN orders o ON c.id = o.customer_id
JOIN order_items oi ON o.id = oi.order_id
GROUP BY c.region;

Schema: customers(id, region), orders(id, customer_id, total), order_items(id, order_id, product_id, qty)
Expected result: total revenue per region
Actual result: revenue numbers are roughly 3x too high

Process:
1. Identify the most likely root cause
2. Provide the corrected query
3. Explain why the original produced inflated numbers
```

## Model's Diagnosis (summarized)
The join to `order_items` multiplies each order row once per line item (a one-to-many relationship), so `SUM(o.total)` — which is an order-level total — gets counted once per line item instead of once per order. The fix: don't join to `order_items` at all if only order-level totals are needed, or use `SUM(DISTINCT ...)` carefully, or aggregate line items separately before joining.

## Why This Works
Rather than guessing at a fix, the structured process forces root-cause identification first (the classic "join causing row multiplication" bug), which is far more reliable than pattern-matching a fix without understanding the mechanism.

## Related
`prompts/sql/debug-sql.md`, `prompts/sql/joins.md`, `prompt-patterns/chain-of-thought.md`
