# Example: Bad Prompt vs. Good Prompt Side-by-Side

> A direct before/after comparison illustrating several principles from this library at once.

## Scenario
Requesting marketing copy for a product launch.

## ❌ Weak Prompt
```
Write some marketing copy for my new app.
```

**Why it's weak:** No audience, no tone, no format, no length, no specifics about the app. The model has to guess at nearly everything, so the output will be generic and likely won't match what the requester actually wanted.

## ✅ Strong Prompt
```
You are a conversion copywriter (see prompts/system-prompts/marketing-expert.md for persona).

Task: Write launch announcement copy for a new app.

Context:
- Product: Habit-tracking app called "Streakly," core feature is a visual streak calendar
- Audience: people who've tried and abandoned habit apps before (skeptical of another app)
- Tone: honest, a little self-aware about "yet another habit app" fatigue, not hype-y

Requirements:
- One-line hook (under 15 words)
- 100-word body addressing the skepticism directly before pitching the differentiator
- One clear CTA: download on the App Store

Output format: Markdown with a Hook / Body / CTA structure.
```

**Why it's strong:** Specific product, named audience with a stated psychological state (skepticism) to address, explicit tone guidance, clear structural requirements, and explicit format — leaving minimal ambiguity for the model to fill in with generic defaults.

## Key Takeaway
The difference isn't length for its own sake — it's specificity. Every added detail (audience's mental state, tone, structure) directly removes a decision the model would otherwise have to make blindly.

## Related
`prompts/templates/task-prompt-template.md`, `prompts/marketing/sales-copy.md`
