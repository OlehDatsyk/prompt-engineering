# Step-by-Step Prompting

> Explicitly instructing the model to work through a task in a defined sequence of steps, whether for reasoning (see chain-of-thought) or for structuring a multi-part deliverable.

## What It Is
Step-by-step prompting provides an explicit numbered process for the model to follow, rather than leaving it to infer the right approach. This is broader than chain-of-thought (which is specifically about reasoning) — it also applies to structuring how a deliverable should be built (e.g. "first outline, then draft, then revise").

## When to Use
- Tasks with a natural procedural structure (research → analysis → recommendation)
- When you've observed the model skipping an important step when instructions are less explicit
- Onboarding a prompt template for a team, where an explicit process improves consistency

## Example
```
Follow this process:
1. First, list the key requirements from the request
2. Then, identify any requirement that conflicts with another
3. Propose a solution that satisfies as many requirements as possible, noting any necessary tradeoff
4. Only after steps 1-3, write the final recommendation
```

## Strengths
- Reduces the chance of the model skipping important intermediate work
- Makes multi-part deliverables more consistent and complete
- Easy to audit which step, if any, went wrong

## Limitations
- Overly rigid step lists can constrain a better organic approach for genuinely open-ended tasks
- Adds length to the prompt; only worth it when the structure genuinely improves output quality

## Related Patterns
Closely related to `chain-of-thought.md` (reasoning-specific) and `prompt-chaining.md` (multi-prompt version of the same idea).
