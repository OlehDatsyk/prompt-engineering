# JSON Prompting

> Requesting output in strict JSON format for reliable programmatic parsing, typically paired with an explicit schema definition.

## What It Is
JSON prompting instructs the model to return its response as valid JSON matching a specified schema, rather than free-form prose — essential for any application that needs to parse the model's output programmatically.

## When to Use
- Building integrations where the model's output feeds directly into application logic
- Data extraction tasks (pulling structured fields from unstructured text)
- Any case where downstream code, not a human, consumes the output

## Example
```
Extract the following fields as JSON: {"name": string, "email": string or null, "urgency": "low"|"medium"|"high"}

Return ONLY the JSON object, no other text.

Text: [...]
```

## Strengths
- Enables reliable programmatic parsing without complex free-text extraction logic
- Explicit schemas reduce ambiguity about expected field names/types

## Limitations
- Prompt-only JSON enforcement can occasionally still produce malformed output (extra text, invalid syntax) — prefer your API's native structured output/tool-calling feature when available, as it enforces schema compliance more reliably than prompting alone
- Requires explicit null/empty-array handling instructions to avoid missing keys

## Related Patterns
See `prompts/templates/json-output-template.md`; often the target format for `prompt-chaining.md` intermediate steps.
