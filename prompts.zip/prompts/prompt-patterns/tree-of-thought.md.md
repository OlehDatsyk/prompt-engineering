# Tree-of-Thought (ToT)

> Exploring multiple reasoning branches in parallel (like a search tree) rather than committing to a single linear chain of reasoning, allowing backtracking from dead ends.

## What It Is
Tree-of-thought generalizes chain-of-thought by allowing the model to explore several possible next steps at each point in its reasoning, evaluate which branches look promising, and backtrack from ones that don't pan out — similar to how a person might explore several approaches to a puzzle.

## When to Use
- Complex problems with multiple plausible solution strategies where the best approach isn't obvious upfront
- Planning tasks, puzzles, or creative problems where backtracking from a wrong turn is valuable
- When a single linear chain-of-thought has been observed to get "stuck" on a suboptimal path

## Example
```
Solve this puzzle by exploring multiple approaches:

1. Propose 3 distinct strategies for solving [PROBLEM]
2. For each, reason a few steps ahead and evaluate whether it seems promising or stuck
3. Abandon strategies that hit a dead end, explaining why
4. Pursue the most promising strategy to a full solution

Problem: [...]
```

## Strengths
- More robust than a single linear chain for problems with several plausible approaches
- Explicit dead-end abandonment reduces the risk of committing to a flawed early assumption

## Limitations
- Significantly more tokens/latency than simple chain-of-thought
- Overkill for problems with an obvious single approach
- Requires careful prompting to actually get genuine branch exploration rather than superficial variation

## Related Patterns
Builds on `chain-of-thought.md`; conceptually related to `self-consistency.md` but explores different strategies rather than repeating the same one.
