# Few-Shot Prompting

> Providing a small number of worked examples (input → output pairs) before the actual task, to demonstrate the desired pattern.

## What It Is
Few-shot prompting shows the model 2-5 examples of the input-output pattern you want, before giving it the real input. This disambiguates format, tone, and edge-case handling far better than a written instruction alone.

## When to Use
- Output format is specific/non-standard (custom JSON shape, particular tone, unusual categorization scheme)
- Consistency across many similar tasks matters (e.g. batch classification)
- Zero-shot attempts produce inconsistent or incorrect formatting

## Example
```
Classify each ticket by urgency (Low/Medium/High):

Ticket: "App crashes every time I open it" → High
Ticket: "Would love a dark mode option" → Low
Ticket: "Checkout button doesn't work for some users" → High
Ticket: "Can you add a filter for date range?" → Low

Ticket: "Payment page shows an error for 20% of users at checkout"
```

## Strengths
- Significantly more reliable format/tone consistency than zero-shot
- Effectively teaches edge-case handling by example rather than lengthy instruction

## Limitations
- Uses more tokens per request
- Poor examples (unrepresentative, biased selection) can mislead the model as much as they help
- Examples with a repeated pattern (e.g. all the same answer) can bias output toward that pattern

## Related Patterns
Pairs well with `structured-prompting.md` for the example format, and contrasts with `zero-shot.md`.
