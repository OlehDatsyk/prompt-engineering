# ReAct (Reasoning + Acting)

> A pattern combining step-by-step reasoning with interleaved tool use/actions, where the model reasons, acts, observes the result, and repeats.

## What It Is
ReAct structures agentic behavior as a loop: Reason about what to do next → Act (e.g. call a tool/search) → Observe the result → Reason again based on the new information → repeat until the task is complete. This is the foundation of most modern tool-using agents.

## When to Use
- Building agents that use external tools (search, calculators, APIs, code execution)
- Multi-step tasks where later steps depend on the results of earlier actions
- Tasks requiring up-to-date or external information the model doesn't have natively

## Example
```
You have access to a search tool and a calculator tool.

Task: What is the population density of the capital city of the country that won the most 
recent FIFA World Cup?

For each step: state your reasoning (Thought), the action you're taking (Action), 
and wait for the result (Observation) before reasoning further.
```

## Strengths
- Grounds reasoning in real, verifiable information rather than the model's possibly outdated internal knowledge
- The explicit Thought/Action/Observation structure makes agent behavior auditable and debuggable

## Limitations
- More complex to implement (requires actual tool execution infrastructure)
- Can loop unnecessarily without loop-detection safeguards
- Each reasoning-action cycle adds latency

## Related Patterns
Extends `chain-of-thought.md` with actions; see `prompts/developer-prompts/agent-tool-use-prompt.md` for a ready-to-use implementation.
