# Chain-of-Thought (CoT) Prompting

> Instructing the model to reason step by step before giving a final answer, improving accuracy on multi-step or logical tasks.

## What It Is
Chain-of-thought prompting asks the model to show its reasoning process explicitly before arriving at a conclusion, rather than jumping directly to an answer. This has been shown to improve accuracy on math, logic, and multi-step reasoning tasks.

## When to Use
- Math problems, logical deduction, multi-step analysis
- Debugging or root-cause analysis tasks
- Any task where the final answer depends on getting several intermediate steps right

## Example
```
A store had 120 items. They sold 35% on Monday and 20% of the remainder on Tuesday. 
How many items are left?

Think through this step by step before giving the final answer.
```

## Strengths
- Meaningfully improves accuracy on multi-step reasoning tasks compared to direct-answer prompting
- Makes errors easier to spot and debug, since the reasoning is visible

## Limitations
- Uses more tokens and increases latency
- Can occasionally produce plausible-sounding but incorrect reasoning chains (the reasoning can be wrong even if it looks systematic) — verify important conclusions independently
- Not necessary for simple factual lookups where reasoning adds no value

## Related Patterns
See `self-consistency.md` for combining CoT with multiple reasoning paths, and `tree-of-thought.md` for exploring multiple reasoning branches.
