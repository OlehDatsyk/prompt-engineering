# Role Prompting

> Assigning the model a persona or professional role to shape tone, framing, and the lens through which it approaches a task.

## What It Is
Role prompting instructs the model to act as a specific persona ("You are a senior security engineer...") to influence vocabulary, priorities, and the type of reasoning applied.

## When to Use
- You want domain-appropriate framing/vocabulary without manually specifying every stylistic detail
- Establishing consistent tone/expertise across a long conversation or system prompt
- Making feedback/critique more specific (e.g. "as a copy editor" vs. generic feedback)

## Example
```
You are a skeptical due-diligence analyst reviewing a startup pitch deck. 
Your job is to find the weakest claims, not to be encouraging.

Review this pitch deck summary: [...]
```

## Strengths
- Efficiently sets tone, priorities, and vocabulary in one instruction
- Can measurably shift output quality for domain-specific tasks (e.g. code review framed as "senior engineer" catches more issues than unframed requests)

## Limitations
- A role alone doesn't guarantee accuracy — it shapes framing, not factual correctness
- Overly elaborate personas can distract from the actual task; keep roles concise and relevant
- Should not be used to imply credentials that would inappropriately bypass normal caveats (e.g. "licensed doctor" to get medical advice without disclaimers)

## Related Patterns
Often combined with `step-by-step-prompting.md` and used as the foundation for `prompts/system-prompts/`.
