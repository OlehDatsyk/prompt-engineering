# Prompt Chaining

> Breaking a complex task into a sequence of smaller prompts, where each step's output feeds into the next step's input.

## What It Is
Rather than asking a model to do everything in one large, complex prompt, prompt chaining decomposes the task into discrete steps executed as separate prompts (e.g. outline → draft → edit → format), often with different instructions or even different models per step.

## When to Use
- Complex, multi-stage tasks where quality suffers when everything is requested at once
- When intermediate output should be reviewable/editable by a human before proceeding
- Tasks where different steps benefit from different instructions or specialized prompts

## Example
```
Step 1: "Generate a 5-point outline for a blog post about [TOPIC]."
Step 2 (using Step 1's output): "Expand outline point 1 into a full paragraph, in [TONE]."
Step 3 (using all paragraphs): "Combine these paragraphs into a cohesive post with 
transitions, then write an introduction and conclusion."
```

## Strengths
- Each step's prompt can be simpler and more focused, improving reliability per step
- Allows human review/editing between steps for higher-stakes work
- Easier to debug — you can identify exactly which step produced a problem

## Limitations
- More orchestration complexity (managing state between steps)
- Increases total latency and token usage
- Errors in early steps can propagate and compound through later steps

## Related Patterns
Often combined with `structured-prompting.md` to ensure each step's output is cleanly parseable as input to the next.
