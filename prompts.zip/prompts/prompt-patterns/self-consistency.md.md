# Self-Consistency

> Generating multiple independent reasoning paths for the same problem and selecting the most consistent/common answer, improving reliability over a single chain-of-thought pass.

## What It Is
Self-consistency extends chain-of-thought by sampling multiple independent reasoning attempts (often with some randomness/temperature) and taking the majority or most consistent answer, rather than trusting a single reasoning pass.

## When to Use
- High-stakes tasks where a single reasoning error would be costly
- Ambiguous problems where different valid reasoning paths might reach different conclusions
- When you have the budget (latency/cost) for multiple generations

## Example
```
Solve this problem three independent times, reasoning from scratch each time without 
referencing your previous attempts. Then compare the three answers: if they agree, 
report that answer with high confidence. If they disagree, explain the discrepancy 
and identify which reasoning is most likely correct.

Problem: [...]
```

## Strengths
- Reduces the impact of a single flawed reasoning chain
- Surfaces genuine ambiguity in a problem (disagreement across attempts is itself informative)

## Limitations
- Multiplies cost and latency by the number of samples
- Not practical for real-time/high-volume applications without careful cost management
- Majority answer isn't guaranteed correct — it increases reliability, not certainty

## Related Patterns
Builds directly on `chain-of-thought.md`; related to `tree-of-thought.md` for structured exploration of multiple paths.
