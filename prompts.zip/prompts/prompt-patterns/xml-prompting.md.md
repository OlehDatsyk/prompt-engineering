# XML Prompting

> Using XML-style tags to delimit sections of a prompt or requested output, improving structure clarity — particularly effective with Claude models.

## What It Is
XML prompting wraps distinct parts of a prompt or expected output in custom tags (e.g. `<context>`, `<instructions>`, `<answer>`) to make the structure unambiguous to both the model and any code parsing the response.

## When to Use
- Separating reasoning from final answers in the output (e.g. `<thinking>` / `<answer>`)
- Providing multiple distinct pieces of context (e.g. `<document>`, `<question>`) without ambiguity about where one ends and another begins
- When output needs to be reliably parsed by code using tag boundaries

## Example
```
<document>
[long document text]
</document>

<question>
What are the three main risks mentioned in this document?
</question>

Answer using only information in <document>. Wrap your answer in <answer></answer> tags.
```

## Strengths
- Claude models are specifically trained to respect and reliably use custom XML tag structures
- Removes ambiguity about section boundaries compared to plain prose headers
- Easy to parse programmatically with simple string/regex extraction

## Limitations
- Adds some token overhead
- Tag names should be descriptive and consistent; inconsistent or overly generic tag names reduce the benefit

## Related Patterns
See `prompts/templates/xml-output-template.md` for a ready-to-use template; complements `structured-prompting.md`.
