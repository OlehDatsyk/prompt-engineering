# Zero-Shot Prompting

> Asking the model to perform a task with no examples, relying entirely on its pretrained knowledge and the instruction itself.

## What It Is
Zero-shot prompting gives the model a task description with no worked examples. The model relies purely on instruction-following and general knowledge to produce output.

## When to Use
- Simple, well-defined tasks the model has clearly seen many times in training (translation, summarization, classification of common categories)
- Quick prototyping before investing in few-shot examples
- When you don't have representative examples available

## Example
```
Classify the sentiment of this review as positive, negative, or neutral:

"The battery life is decent but the screen is disappointing for the price."
```

## Strengths
- Fast to write, no example curation needed
- Works well for tasks close to common training distribution

## Limitations
- Less reliable for tasks with unusual output formats or domain-specific conventions
- No way to disambiguate edge-case handling without examples

## Related Patterns
See `few-shot.md` for when zero-shot isn't reliable enough, and `role-prompting.md` for improving zero-shot accuracy via persona framing.
