# Structured Prompting

> Explicitly defining the input and output structure of a prompt (sections, fields, format) rather than relying on free-form natural language framing.

## What It Is
Structured prompting organizes a prompt into clearly labeled sections (Task, Context, Requirements, Constraints, Output Format) rather than a single free-form paragraph. This reduces ambiguity and makes prompts easier to reuse, template, and debug.

## When to Use
- Any production/reusable prompt, especially ones used repeatedly or by a team
- Complex tasks with multiple distinct requirements that are easy to lose track of in prose
- Building prompt templates meant to be filled with variables

## Example
```
Task: [description]
Context: [background]
Requirements:
- [requirement 1]
- [requirement 2]
Constraints: [limits]
Output format: [format]
```

## Strengths
- Easier to spot missing information when building/reviewing a prompt
- More reliable output consistency across many uses of the same template
- Simplifies prompt versioning and team collaboration

## Limitations
- Can feel rigid/verbose for simple, one-off conversational requests
- Overly long structured prompts with many sections can bury the actual task

## Related Patterns
Foundation for `prompts/templates/task-prompt-template.md`; often combined with `xml-prompting.md` or `json-prompting.md` for machine-parseable structure.
