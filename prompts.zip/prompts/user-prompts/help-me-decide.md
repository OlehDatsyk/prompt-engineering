# "Help Me Decide" Reusable Prompt

> A general-purpose end-user prompt for structured decision support.

## Prompt

```
I'm trying to decide between: [OPTION A] and [OPTION B] (and possibly [OPTION C]).

My priorities, in order: [PRIORITY 1, PRIORITY 2, PRIORITY 3]
Constraints: [BUDGET/TIME/OTHER LIMITS]

Don't just tell me which one to pick — lay out the real tradeoffs of each option against my stated priorities, 
then give me your recommendation with reasoning I can push back on.
```

## When to Use
- Any personal or professional decision with multiple viable options

## Tips
- Stating your priorities in ranked order (not just a list) meaningfully improves how well the response matches what you actually care about
- Explicitly asking for "reasoning I can push back on" tends to produce more balanced, less one-sided answers
