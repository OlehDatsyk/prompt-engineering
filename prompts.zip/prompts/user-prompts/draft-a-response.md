# "Draft a Response" Reusable Prompt

> A general-purpose end-user prompt for drafting a reply to a message/email.

## Prompt

```
I need to reply to this message: [PASTE ORIGINAL MESSAGE]

Context: [YOUR RELATIONSHIP TO THIS PERSON / SITUATION BACKGROUND]
What I want to communicate: [YOUR KEY POINTS]
Tone: [e.g. warm but firm / brief and professional / apologetic]

Draft a reply. Keep it [LENGTH]. Don't over-explain or add unnecessary hedging.
```

## When to Use
- Drafting email/message replies, especially for sensitive or high-stakes communications

## Tips
- Providing the original message in full (not paraphrased) helps the draft actually respond to what was said
- Specify tone explicitly — this single detail has the biggest impact on whether the draft feels right
