# "Summarize This" Reusable Prompt

> A general-purpose end-user prompt for summarizing any pasted content.

## Prompt

```
Summarize the following in [LENGTH, e.g. 3 bullet points / one paragraph]. 
Focus on [WHAT MATTERS MOST TO ME, e.g. action items / key numbers / main argument].
Don't add information that isn't in the original text.

[PASTE CONTENT HERE]
```

## When to Use
- Quickly digesting long articles, emails, or documents

## Tips
- Always specify what you actually care about (action items? key numbers? overall argument?) — generic summaries miss what matters to you specifically
- Add "don't add information not in the original" to prevent embellishment
