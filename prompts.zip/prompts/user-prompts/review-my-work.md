# "Review My Work" Reusable Prompt

> A general-purpose end-user prompt for getting honest, actionable feedback.

## Prompt

```
Review the following [TYPE OF WORK, e.g. email / essay / code / plan]. Be honest — I'd rather hear real 
issues now than have this fail later.

Specifically look for: [WHAT YOU'RE WORRIED ABOUT, e.g. "clarity" / "logical gaps" / "tone"]

For each issue: explain why it's a problem and suggest a specific fix, not just "this could be better."

[PASTE YOUR WORK HERE]
```

## When to Use
- Getting feedback on writing, code, plans, or any other work product before finalizing it

## Tips
- Explicitly asking for honesty tends to reduce reflexive praise/hedging in the response
- Naming your specific worry focuses the review instead of getting generic feedback across everything
