# "Explain Like I'm..." Reusable Prompt

> A general-purpose end-user prompt for getting explanations at the right depth.

## Prompt

```
Explain [TOPIC] to me like I'm [YOUR BACKGROUND, e.g. "a complete beginner" / "someone with a CS degree but no ML background"].

Use an analogy if it helps, but make sure it doesn't oversimplify to the point of being wrong.
Then give me one thing I could look into next if I want to go deeper.
```

## When to Use
- Learning a new topic at the appropriate depth for your background

## Tips
- Be specific about your actual background rather than just saying "simply" — "beginner" means different things for different topics
- Asking for a "next step" turns a one-off explanation into a learning path
