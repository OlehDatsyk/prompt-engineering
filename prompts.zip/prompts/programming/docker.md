# Dockerfile Generator

> Generate an optimized, secure Dockerfile.

## 📋 Description
A prompt for producing production-ready, minimal-size Dockerfiles.

## 🎯 Purpose
To produce efficient, secure container images.

## ✅ When to Use
- Containerizing a new application
- Optimizing an existing Dockerfile

## 🔧 Variables
| Variable | Description |
|---|---|
| `app_type` | Language/framework of the app |
| `build_steps` | Build requirements, e.g. compiled assets |
| `runtime_needs` | Runtime dependencies |

## 💬 Prompt

```
You are a DevOps engineer. Write a production-ready Dockerfile.

Application type: {app_type}
Build steps needed: {build_steps}
Runtime needs: {runtime_needs}

Requirements:
- Use multi-stage builds to keep the final image minimal
- Use a specific, minimal base image tag (not `latest`)
- Run the application as a non-root user
- Copy only necessary files (assume a sensible .dockerignore exists, and suggest its contents)
- Order layers to maximize Docker build cache efficiency (dependencies before source code)
- Set appropriate `HEALTHCHECK` if applicable

Output the Dockerfile, a suggested .dockerignore, and a short explanation of key decisions.
```

## 📥 Example Input
```
app_type: Node.js/Express API
build_steps: npm install, no compile step
runtime_needs: Node 20, port 3000
```

## 📤 Example Output
```
```dockerfile
FROM node:20-alpine AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci --production
COPY . .

FROM node:20-alpine
WORKDIR /app
RUN adduser -D appuser
COPY --from=build /app /app
USER appuser
EXPOSE 3000
CMD ["node", "index.js"]
```
```

## 💡 Tips
- Specify exact runtime version needed to pin the base image tag

## ✅ Best Practices
- Always run containers as non-root
- Use multi-stage builds to reduce final image size

## ⚠️ Common Mistakes
- Using `latest` tag, causing unpredictable builds
- Running the container process as root
