# Performance Optimization Advisor

> Identify and fix performance bottlenecks in code.

## 📋 Description
A prompt for diagnosing performance issues and proposing measured optimizations.

## 🎯 Purpose
To improve code performance based on actual bottleneck analysis, not guesswork.

## ✅ When to Use
- Code is running slower than expected
- Preparing code for higher scale

## 🔧 Variables
| Variable | Description |
|---|---|
| `code` | Code to optimize |
| `performance_issue` | Observed symptom, e.g. slow response time, high memory use |
| `constraints` | Constraints, e.g. must keep same output, limited memory |

## 💬 Prompt

```
You are a performance engineer. Analyze the following code for performance issues.

Code:
{code}

Observed issue: {performance_issue}
Constraints: {constraints}

Process:
1. Identify the likely bottleneck(s) with reasoning (e.g. O(n²) loop, N+1 query, unnecessary re-renders)
2. State the current approximate time/space complexity
3. Propose an optimized approach, explaining the tradeoff (e.g. memory for speed)
4. Show the optimized code
5. State the new approximate complexity
6. Note if the optimization changes behavior in any edge case — this must be called out explicitly

Do not micro-optimize a part of the code that isn't the actual bottleneck.
```

## 📥 Example Input
```
code: [function doing nested loop lookups over two large lists]
performance_issue: takes 30s for 10k items
constraints: must return identical results
```

## 📤 Example Output
```
**Bottleneck:** Nested loop creates O(n×m) complexity — for each item in list A, scanning all of list B.

**Fix:** Convert list B to a set/dict for O(1) lookups, reducing overall complexity to O(n+m).

```python
b_lookup = {item.id: item for item in list_b}
...
```
**New complexity:** O(n+m). Output verified identical for all tested cases.
```

## 💡 Tips
- Provide profiling data if you have it — it focuses the analysis on the real bottleneck

## ✅ Best Practices
- Optimize based on measured/reasoned bottlenecks, not assumptions
- Always verify optimized code preserves identical output

## ⚠️ Common Mistakes
- Optimizing code that isn't actually the bottleneck
- Introducing subtle behavior changes while optimizing
