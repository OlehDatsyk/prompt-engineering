# React Component Generator

> Generate a functional React component with hooks.

## 📋 Description
A prompt for producing clean, accessible React functional components.

## 🎯 Purpose
To produce production-ready React components following current best practices.

## ✅ When to Use
- Building a new UI component
- Refactoring a class component to hooks

## 🔧 Variables
| Variable | Description |
|---|---|
| `component_purpose` | What the component does |
| `props` | Props the component accepts |
| `styling` | Styling approach, e.g. Tailwind, CSS Modules |

## 💬 Prompt

```
You are a senior React engineer. Build a functional React component.

Purpose: {component_purpose}
Props: {props}
Styling approach: {styling}

Requirements:
- Use functional components with hooks only (no class components)
- Type props explicitly (TypeScript interface or PropTypes if JS)
- Ensure accessibility: semantic HTML, ARIA attributes where needed, keyboard navigation
- Handle loading/error/empty states if the component fetches data
- Keep the component focused (single responsibility); extract subcomponents if needed
- Include a short usage example

Output only the code, followed by a brief explanation of key decisions.
```

## 📥 Example Input
```
component_purpose: a searchable dropdown select
props: options: string[], onSelect: (value: string) => void
styling: Tailwind CSS
```

## 📤 Example Output
```
```tsx
interface SearchableSelectProps {
  options: string[];
  onSelect: (value: string) => void;
}

export function SearchableSelect({ options, onSelect }: SearchableSelectProps) {
  const [query, setQuery] = useState('');
  ...
}
```
```

## 💡 Tips
- Always specify styling approach to match your project's conventions

## ✅ Best Practices
- Keep components single-responsibility
- Always handle loading/error/empty UI states

## ⚠️ Common Mistakes
- Skipping accessibility attributes
- Mixing multiple responsibilities into one component
