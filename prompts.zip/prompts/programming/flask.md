# Flask Route Generator

> Generate a Flask route with validation and error handling.

## 📋 Description
A prompt for producing clean Flask route handlers following current best practices.

## 🎯 Purpose
To produce secure, well-structured Flask endpoints.

## ✅ When to Use
- Adding a new Flask route
- Building a small Flask API

## 🔧 Variables
| Variable | Description |
|---|---|
| `route` | Route path and method |
| `request_shape` | Expected input |
| `business_logic` | What the route should do |

## 💬 Prompt

```
You are a senior Python backend engineer specializing in Flask. Write a route handler.

Route: {route}
Request shape: {request_shape}
Business logic: {business_logic}

Requirements:
- Use Flask blueprints if the code implies a modular app structure
- Validate input using explicit checks or a schema library (e.g. Pydantic/Marshmallow) — state which
- Return JSON responses with consistent shapes and correct HTTP status codes
- Use proper exception handling with Flask error handlers where appropriate
- Include type hints

Output only the code, followed by a brief explanation of validation choices.
```

## 📥 Example Input
```
route: POST /api/orders
request_shape: { item_id: int, quantity: int }
business_logic: create an order, validate quantity > 0
```

## 📤 Example Output
```
```python
@bp.route('/api/orders', methods=['POST'])
def create_order():
    data = request.get_json(silent=True) or {}
    if not isinstance(data.get('quantity'), int) or data['quantity'] <= 0:
        return jsonify({'error': 'quantity must be a positive integer'}), 400
    ...
```
```

## 💡 Tips
- State whether you want a schema validation library used

## ✅ Best Practices
- Validate JSON payloads defensively (handle missing/malformed bodies)
- Use consistent error response shape

## ⚠️ Common Mistakes
- Assuming request.get_json() always returns a dict
- Not setting correct HTTP status codes for errors
