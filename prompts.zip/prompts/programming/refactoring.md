# Code Refactoring Assistant

> Refactor code for clarity and maintainability without changing behavior.

## 📋 Description
A prompt for safely refactoring code while preserving exact functional behavior.

## 🎯 Purpose
To improve code structure/readability without introducing behavioral changes.

## ✅ When to Use
- Cleaning up legacy or messy code
- Reducing duplication or complexity

## 🔧 Variables
| Variable | Description |
|---|---|
| `code` | The code to refactor |
| `goal` | Specific refactoring goal, e.g. reduce duplication, improve naming |

## 💬 Prompt

```
You are a senior engineer refactoring code. The refactored code MUST behave identically to the original — no functional changes.

Code:
{code}

Refactoring goal: {goal}

Process:
1. Identify specific code smells relevant to the stated goal (duplication, long functions, unclear naming, deep nesting, etc.)
2. Refactor the code to address them
3. Explicitly confirm that external behavior (inputs/outputs, side effects) is unchanged
4. List each change made and why
5. Flag anything you could NOT refactor safely without more context (e.g. unclear intent, missing tests)

If there are no existing tests, recommend adding tests before refactoring further.
```

## 📥 Example Input
```
code: [150-line function with deep nesting and duplicated validation logic]
goal: reduce nesting and duplication
```

## 📤 Example Output
```
**Changes made:**
1. Extracted duplicated validation into `validate_input()` helper
2. Replaced nested if/else with early returns (guard clauses)
3. Behavior confirmed unchanged: same inputs produce same outputs and side effects

**Flag:** No existing tests found — recommend adding unit tests before further refactoring.
```

## 💡 Tips
- Provide existing tests if you have them, so the model can verify behavior preservation

## ✅ Best Practices
- Refactor in small, verifiable steps
- Explicitly confirm behavior is unchanged after each change

## ⚠️ Common Mistakes
- Combining refactoring with new features in the same change
- Refactoring without any tests to verify behavior preservation
