# Unit Test Writer (Function-Level)

> Write focused unit tests for a single function.

## 📋 Description
A prompt for generating isolated unit tests for a specific function or method.

## 🎯 Purpose
To produce fast, isolated unit tests with no external dependencies.

## ✅ When to Use
- Testing a pure function or isolated method
- Adding missing unit coverage

## 🔧 Variables
| Variable | Description |
|---|---|
| `function_code` | The function to test |
| `framework` | Testing framework |

## 💬 Prompt

```
You are a senior engineer writing unit tests for a single function. Tests must be fully isolated — no network, filesystem, or database calls.

Function:
{function_code}

Framework: {framework}

Requirements:
- One assertion focus per test (test one behavior per test case)
- Include: typical input, boundary values, invalid/malformed input, and null/empty input if applicable
- Mock any external calls the function makes
- Use parametrized/table-driven tests if the framework supports it and there are many similar cases
- Keep tests fast (no sleeps, no real I/O)

Output the test code only, followed by a one-line coverage summary.
```

## 📥 Example Input
```
function_code: def calculate_discount(price, percent): return price * (1 - percent/100)
framework: pytest
```

## 📤 Example Output
```
```python
import pytest

@pytest.mark.parametrize('price,percent,expected', [
    (100, 10, 90),
    (100, 0, 100),
    (100, 100, 0),
])
def test_calculate_discount(price, percent, expected):
    assert calculate_discount(price, percent) == expected
```
**Coverage:** typical, zero, and full-discount boundary cases.
```

## 💡 Tips
- Use parametrized tests for functions with many similar input/output pairs

## ✅ Best Practices
- One behavior per test case
- Keep unit tests free of real I/O for speed and reliability

## ⚠️ Common Mistakes
- Bundling multiple assertions/behaviors into one test
- Introducing real I/O, making tests slow/flaky
