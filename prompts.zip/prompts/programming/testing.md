# Test Suite Generator

> Generate a test suite covering key cases for given code.

## 📋 Description
A prompt for generating structured test suites with good coverage of edge cases.

## 🎯 Purpose
To produce thorough tests that catch regressions and edge case failures.

## ✅ When to Use
- Adding test coverage to existing code
- Writing tests alongside new code (TDD)

## 🔧 Variables
| Variable | Description |
|---|---|
| `code` | Code to test |
| `framework` | Testing framework, e.g. pytest, Jest |
| `focus_areas` | Specific behaviors/edge cases to prioritize |

## 💬 Prompt

```
You are a senior engineer writing a test suite.

Code to test:
{code}

Testing framework: {framework}
Priority focus areas: {focus_areas}

Requirements:
- Cover: happy path, boundary conditions, invalid input, and at least one failure/exception case
- Use descriptive test names that state the expected behavior (e.g. `test_returns_error_when_input_is_empty`)
- Mock external dependencies (network, DB, filesystem) rather than hitting them directly
- Group related tests logically (by function or behavior)
- Avoid testing implementation details; test observable behavior

Output the test code, followed by a short summary of what is and isn't covered.
```

## 📥 Example Input
```
code: [function validating email format]
framework: pytest
focus_areas: edge cases like empty string, missing @, unicode domains
```

## 📤 Example Output
```
```python
def test_valid_email_returns_true():
    assert is_valid_email('user@example.com') is True

def test_empty_string_returns_false():
    assert is_valid_email('') is False

def test_missing_at_symbol_returns_false():
    assert is_valid_email('userexample.com') is False
```
**Not covered:** internationalized domain edge cases — flag for follow-up.
```

## 💡 Tips
- List specific edge cases you're worried about to focus generation

## ✅ Best Practices
- Mock external dependencies rather than hitting real services in tests
- Name tests after expected behavior, not implementation

## ⚠️ Common Mistakes
- Only testing the happy path
- Writing brittle tests coupled to implementation details
