# GitHub PR/Issue Writer

> Write clear, structured GitHub pull request descriptions and issues.

## 📋 Description
A prompt for producing well-structured PR descriptions and bug reports.

## 🎯 Purpose
To produce PR/issue text that gives reviewers/maintainers everything they need efficiently.

## ✅ When to Use
- Opening a pull request
- Filing a bug report or feature request

## 🔧 Variables
| Variable | Description |
|---|---|
| `type` | PR description or issue |
| `changes_or_bug` | What changed, or what the bug is |
| `context` | Relevant background, linked tickets |

## 💬 Prompt

```
You are a senior engineer writing GitHub documentation for a {type}.

Details: {changes_or_bug}
Context: {context}

If PR description, include:
- Summary (what and why, 2-3 sentences)
- Changes made (bulleted)
- How to test / reviewer checklist
- Screenshots placeholder if UI-related
- Related issue links

If bug report, include:
- Summary
- Steps to reproduce (numbered, precise)
- Expected vs actual behavior
- Environment details
- Severity/impact assessment

Keep it scannable — reviewers/maintainers should understand the core point in under 10 seconds.
```

## 📥 Example Input
```
type: PR description
changes_or_bug: added rate limiting middleware to the API
context: fixes issue #482, related to abuse reports
```

## 📤 Example Output
```
## Summary
Adds rate limiting middleware to prevent API abuse, closing #482.

## Changes
- Added `rateLimiter` middleware (100 req/min per IP)
- Added tests for limiter behavior

## How to test
1. Send >100 requests in 60s and confirm 429 response
```

## 💡 Tips
- Link related issues explicitly to build institutional context

## ✅ Best Practices
- Keep the summary understandable in under 10 seconds
- Include explicit reviewer testing steps

## ⚠️ Common Mistakes
- Vague PR titles/summaries requiring reviewers to read the whole diff to understand intent
- Bug reports missing reproduction steps
