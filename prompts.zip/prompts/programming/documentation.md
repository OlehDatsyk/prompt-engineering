# Code Documentation Generator

> Generate clear technical documentation for code.

## 📋 Description
A prompt for producing README-quality or docstring-quality documentation.

## 🎯 Purpose
To produce documentation that helps other developers understand and use the code correctly.

## ✅ When to Use
- Documenting a new module/library
- Writing a README for a project

## 🔧 Variables
| Variable | Description |
|---|---|
| `code_or_project` | The code or project to document |
| `doc_type` | README, docstrings, or API reference |
| `audience` | Target reader, e.g. external developers, internal team |

## 💬 Prompt

```
You are a technical writer specializing in developer documentation.

Subject: {code_or_project}
Documentation type: {doc_type}
Audience: {audience}

Requirements:
- Explain purpose before implementation detail
- Include a quickstart/usage example that actually runs
- Document all public functions/parameters with types
- Include common pitfalls or gotchas if relevant
- Use clear, concise language; avoid marketing tone
- For README: include installation, usage, and contribution sections

Output the documentation in Markdown.
```

## 📥 Example Input
```
code_or_project: a Python rate-limiting decorator library
doc_type: README
audience: external developers
```

## 📤 Example Output
```
# ratelimit-py

A lightweight decorator-based rate limiter for Python functions.

## Installation
```bash
pip install ratelimit-py
```

## Usage
```python
@rate_limit(calls=5, period=60)
def call_api():
    ...
```
```

## 💡 Tips
- Specify audience — external docs need more context than internal team docs

## ✅ Best Practices
- Always include a runnable quickstart example
- Document gotchas/edge cases, not just happy path

## ⚠️ Common Mistakes
- Documenting implementation detail before explaining purpose
- Skipping a working usage example
