# TypeScript Code Generator

> Generate strictly-typed TypeScript code.

## 📋 Description
A prompt for producing TypeScript code with strict typing and clear interfaces.

## 🎯 Purpose
To produce type-safe TypeScript code with minimal use of `any`.

## ✅ When to Use
- Building typed utility functions or modules
- Converting JS logic to TypeScript

## 🔧 Variables
| Variable | Description |
|---|---|
| `task` | What the code should do |
| `existing_types` | Existing interfaces/types to reuse, if any |
| `strictness` | Strictness level, e.g. strict mode on |

## 💬 Prompt

```
You are a senior TypeScript engineer. Write TypeScript code for the following task.

Task: {task}
Existing types to reuse: {existing_types}
Strictness: {strictness}

Requirements:
- Enable strict typing; never use `any` unless explicitly justified in a comment
- Define explicit interfaces/types for all data structures
- Use generics where they improve reusability
- Include JSDoc comments for exported functions
- Provide a short usage example demonstrating type inference

Output only the code, followed by a brief explanation of the type design.
```

## 📥 Example Input
```
task: a generic API response wrapper type and fetch helper
existing_types: none
strictness: strict mode on
```

## 📤 Example Output
```
```typescript
interface ApiResponse<T> {
  data: T;
  error: string | null;
}

async function fetchJson<T>(url: string): Promise<ApiResponse<T>> {
  ...
}
```
```

## 💡 Tips
- Provide existing types/interfaces so the model reuses instead of duplicating them

## ✅ Best Practices
- Avoid `any`; prefer `unknown` with narrowing when type is uncertain
- Use generics for reusable utilities

## ⚠️ Common Mistakes
- Overusing `any` to silence type errors
- Defining duplicate types instead of reusing existing ones
