# Python Code Generator

> Generate clean, idiomatic Python code from a spec.

## 📋 Description
A prompt for generating production-quality Python code with proper typing, docstrings, and error handling.

## 🎯 Purpose
To produce working, idiomatic Python code that follows modern best practices.

## ✅ When to Use
- Implementing a new function/module from a spec
- Prototyping a script quickly

## 🔧 Variables
| Variable | Description |
|---|---|
| `task` | What the code should do |
| `constraints` | Libraries allowed/forbidden, Python version |
| `style` | Style requirements, e.g. PEP8, type hints |

## 💬 Prompt

```
You are a senior Python engineer. Write Python code for the following task.

Task: {task}
Constraints: {constraints}
Style requirements: {style}

Requirements:
- Use Python type hints throughout
- Include a docstring for every function/class (Google style)
- Handle edge cases and invalid input explicitly with clear exceptions
- Follow PEP8 formatting
- Avoid unnecessary dependencies
- Include a minimal usage example in a `if __name__ == "__main__":` block

Output only the code, followed by a short explanation of key design decisions.
```

## 📥 Example Input
```
task: parse a CSV of transactions and return total spend per category
constraints: standard library only, Python 3.11
style: PEP8, full type hints
```

## 📤 Example Output
```
```python
from pathlib import Path
from collections import defaultdict
import csv

def total_spend_by_category(path: Path) -> dict[str, float]:
    """Compute total spend per category from a transactions CSV."""
    ...
```
**Design notes:** Used `defaultdict` to avoid explicit key checks...
```

## 💡 Tips
- Specify Python version explicitly to control syntax features used

## ✅ Best Practices
- Always request type hints and docstrings
- Specify allowed dependencies to avoid unwanted imports

## ⚠️ Common Mistakes
- Not specifying Python version, causing incompatible syntax
- Omitting edge case handling instructions
