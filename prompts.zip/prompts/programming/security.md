# Security Code Audit Assistant

> Audit code for common security vulnerabilities.

## 📋 Description
A prompt for identifying security issues in code following OWASP-style categories.

## 🎯 Purpose
To catch common vulnerability classes before code reaches production.

## ✅ When to Use
- Reviewing code that handles user input or sensitive data
- Pre-deployment security pass

## 🔧 Variables
| Variable | Description |
|---|---|
| `code` | Code to audit |
| `context` | What the code handles, e.g. auth, payments, file uploads |

## 💬 Prompt

```
You are an application security engineer performing a code audit.

Context: {context}

Code:
{code}

Audit for these vulnerability classes (only report what's actually present, don't pad with generic warnings):
- Injection (SQL, command, template)
- Broken authentication/session handling
- Sensitive data exposure (secrets in code, logs, unencrypted storage)
- Broken access control
- Insecure deserialization
- Missing input validation/sanitization
- Insecure direct object references

For each finding: severity (critical/high/medium/low), specific location, exploit scenario in one sentence, and a concrete fix. End with an overall risk summary.
```

## 📥 Example Input
```
context: file upload endpoint for user avatars
code: [Express handler saving uploaded file using client-provided filename]
```

## 📤 Example Output
```
**[CRITICAL] Path Traversal:** The filename from the client is used directly in the file save path without sanitization, allowing `../../etc/passwd` style traversal.
**Fix:** Generate a server-side UUID filename; never use client-supplied filenames directly.

**Risk summary:** One critical finding; must fix before deployment.
```

## 💡 Tips
- Provide the surrounding context (auth, payments, etc.) — it changes what's high risk

## ✅ Best Practices
- Report severity per finding to prioritize fixes
- Focus on realistic exploit scenarios, not theoretical ones

## ⚠️ Common Mistakes
- Trusting any client-supplied value (filenames, IDs) without validation
- Logging sensitive data like passwords or tokens
