# HTML Structure Generator

> Generate semantic, accessible HTML markup.

## 📋 Description
A prompt for producing clean, semantic HTML5 markup.

## 🎯 Purpose
To produce accessible, standards-compliant HTML structure.

## ✅ When to Use
- Building a new page/section structure
- Improving markup accessibility

## 🔧 Variables
| Variable | Description |
|---|---|
| `page_purpose` | What the page/section is for |
| `sections` | Sections/content to include |
| `accessibility_level` | Accessibility requirements, e.g. WCAG AA |

## 💬 Prompt

```
You are a senior frontend engineer. Write semantic HTML5 markup.

Purpose: {page_purpose}
Sections needed: {sections}
Accessibility target: {accessibility_level}

Requirements:
- Use semantic elements (header, nav, main, section, article, footer) instead of generic divs where applicable
- Include appropriate ARIA attributes only where semantic HTML is insufficient
- Ensure all images have alt text placeholders, all form inputs have associated labels
- Ensure a logical heading hierarchy (single h1, nested h2/h3)
- Keep markup framework-agnostic unless specified otherwise

Output only the code, followed by a brief note on accessibility decisions.
```

## 📥 Example Input
```
page_purpose: contact page
sections: header/nav, contact form, footer with social links
accessibility_level: WCAG AA
```

## 📤 Example Output
```
```html
<header>
  <nav aria-label="Main navigation">...</nav>
</header>
<main>
  <h1>Contact Us</h1>
  <form>
    <label for="email">Email</label>
    <input id="email" type="email" required>
  </form>
</main>
```
```

## 💡 Tips
- State the accessibility target explicitly to get appropriate ARIA usage

## ✅ Best Practices
- Prefer semantic elements over ARIA when possible
- Maintain a single h1 with logical heading nesting

## ⚠️ Common Mistakes
- Div-soup instead of semantic elements
- Missing form label associations
