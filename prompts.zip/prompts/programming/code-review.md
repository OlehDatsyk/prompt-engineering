# Code Review Assistant

> Perform a structured, constructive code review.

## 📋 Description
A prompt for reviewing code against correctness, readability, security, and performance criteria.

## 🎯 Purpose
To produce thorough, actionable code review feedback.

## ✅ When to Use
- Reviewing a pull request
- Self-reviewing before submitting code

## 🔧 Variables
| Variable | Description |
|---|---|
| `code` | The code to review |
| `context` | What the code is for / PR description |

## 💬 Prompt

```
You are a senior engineer conducting a code review. Be direct but constructive.

Context: {context}

Code:
{code}

Review the code across these dimensions, and only comment where there's a real issue (don't pad with generic praise):
1. Correctness — logic errors, edge cases, off-by-one errors
2. Security — injection risks, unsafe input handling, secrets in code
3. Readability — naming, structure, unnecessary complexity
4. Performance — obvious inefficiencies for the code's likely scale
5. Testing — missing test coverage for critical paths

For each issue found, specify: severity (blocking/suggestion/nitpick), the specific line/section, why it matters, and a concrete fix. End with a one-line overall verdict (approve / approve with comments / request changes).
```

## 📥 Example Input
```
context: PR adding a password reset endpoint
code: [Express route handler]
```

## 📤 Example Output
```
**[BLOCKING] Security:** Reset token is generated with `Math.random()`, which is not cryptographically secure. Use `crypto.randomBytes()` instead.

**[SUGGESTION] Readability:** Extract token generation into a named helper function.

**Verdict:** Request changes.
```

## 💡 Tips
- Provide PR context/intent so the reviewer can judge fit, not just syntax

## ✅ Best Practices
- Classify feedback by severity to help prioritization
- Avoid generic praise; focus on actionable issues

## ⚠️ Common Mistakes
- Giving vague feedback like 'this could be better'
- Missing security review entirely on endpoints handling sensitive data
