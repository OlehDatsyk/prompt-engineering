# Node.js API Endpoint Generator

> Generate a Node.js backend endpoint with validation and error handling.

## 📋 Description
A prompt for producing production-ready Node.js route handlers.

## 🎯 Purpose
To produce secure, well-structured backend endpoints.

## ✅ When to Use
- Adding a new REST endpoint
- Building backend business logic

## 🔧 Variables
| Variable | Description |
|---|---|
| `endpoint` | Route and method, e.g. POST /users |
| `framework` | Express, Fastify, etc. |
| `request_shape` | Expected request body/params |
| `business_logic` | What the endpoint should do |

## 💬 Prompt

```
You are a senior Node.js backend engineer. Write a route handler.

Endpoint: {endpoint}
Framework: {framework}
Request shape: {request_shape}
Business logic: {business_logic}

Requirements:
- Validate input explicitly (reject malformed/missing fields with 400 responses)
- Use async/await with proper try/catch and next(error) pattern
- Never trust client input directly in database queries (parameterized queries only)
- Return consistent JSON response shapes, including for errors
- Include appropriate HTTP status codes
- Add brief inline comments explaining non-obvious logic

Output only the code, followed by a short explanation of validation and error-handling choices.
```

## 📥 Example Input
```
endpoint: POST /users
framework: Express
request_shape: { email: string, password: string }
business_logic: create a new user account, hash the password
```

## 📤 Example Output
```
```javascript
router.post('/users', async (req, res, next) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'email and password required' });
  }
  ...
});
```
```

## 💡 Tips
- Specify the framework explicitly since middleware patterns differ

## ✅ Best Practices
- Always validate input before processing
- Use parameterized queries to prevent injection

## ⚠️ Common Mistakes
- Trusting request body without validation
- Returning inconsistent error response shapes
