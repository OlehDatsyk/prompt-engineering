# REST API Design Assistant

> Design a REST API resource with endpoints, schemas, and conventions.

## 📋 Description
A prompt for designing consistent, well-documented REST API resources.

## 🎯 Purpose
To produce a complete API design following REST conventions.

## ✅ When to Use
- Designing a new API resource
- Standardizing API conventions across a project

## 🔧 Variables
| Variable | Description |
|---|---|
| `resource` | The resource being modeled, e.g. 'orders' |
| `operations` | CRUD or custom operations needed |
| `auth_model` | Authentication/authorization approach |

## 💬 Prompt

```
You are a senior API designer. Design a REST API for the following resource.

Resource: {resource}
Operations needed: {operations}
Auth model: {auth_model}

Produce:
1. A table of endpoints: Method | Path | Description | Auth required
2. Request/response JSON schema examples for each endpoint
3. Standard error response shape used across all endpoints
4. Pagination approach for list endpoints (if applicable)
5. Versioning approach (e.g. URL path versioning)
6. Status code usage table for this resource

Follow REST conventions: plural nouns, proper HTTP verbs, no verbs in URLs.
```

## 📥 Example Input
```
resource: orders
operations: list, get by id, create, cancel
auth_model: Bearer JWT
```

## 📤 Example Output
```
| Method | Path | Description | Auth |
|---|---|---|---|
| GET | /orders | List orders | Required |
| POST | /orders | Create order | Required |
| POST | /orders/{id}/cancel | Cancel order | Required |

**Error shape:**
```json
{ "error": { "code": "string", "message": "string" } }
```
```

## 💡 Tips
- Specify whether custom actions (like /cancel) are acceptable or must stay strictly CRUD

## ✅ Best Practices
- Use plural nouns and proper HTTP verbs, no verbs in URL paths
- Define a single consistent error response shape

## ⚠️ Common Mistakes
- Mixing verbs into URLs (e.g. /getOrder)
- Inconsistent error response shapes across endpoints
