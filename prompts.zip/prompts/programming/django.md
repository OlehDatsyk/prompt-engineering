# Django View/Model Generator

> Generate Django models, views, or serializers.

## 📋 Description
A prompt for producing idiomatic Django code following the framework's conventions.

## 🎯 Purpose
To produce Django code consistent with the framework's ORM and view patterns.

## ✅ When to Use
- Adding a new Django model
- Building a DRF view/serializer

## 🔧 Variables
| Variable | Description |
|---|---|
| `component_type` | Model, view, or serializer |
| `spec` | Fields/behavior needed |
| `uses_drf` | Whether Django REST Framework is used |

## 💬 Prompt

```
You are a senior Django engineer. Write the following Django component.

Component type: {component_type}
Spec: {spec}
Uses Django REST Framework: {uses_drf}

Requirements:
- Follow Django naming and app-structure conventions
- For models: include appropriate field types, constraints, `Meta` options, and `__str__`
- For views: use class-based views where idiomatic, with proper permission/auth checks
- For serializers (if DRF): include validation methods for any non-trivial business rules
- Include migrations note if a model changes (mention `makemigrations` needed)

Output only the code, followed by a brief explanation.
```

## 📥 Example Input
```
component_type: model
spec: BlogPost with title, slug, author (FK to User), published_at, is_published
uses_drf: false
```

## 📤 Example Output
```
```python
class BlogPost(models.Model):
    title = models.CharField(max_length=200)
    slug = models.SlugField(unique=True)
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    published_at = models.DateTimeField(null=True, blank=True)
    is_published = models.BooleanField(default=False)

    def __str__(self):
        return self.title
```
```

## 💡 Tips
- Specify whether DRF is in use, since serializer conventions differ significantly

## ✅ Best Practices
- Always add __str__ to models for admin readability
- Add explicit permission checks to views handling sensitive data

## ⚠️ Common Mistakes
- Forgetting unique/db constraints on fields like slugs/emails
- Skipping permission checks on class-based views
