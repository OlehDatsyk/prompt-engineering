# VS Code Configuration Generator

> Generate VS Code workspace settings, tasks, or launch configs.

## 📋 Description
A prompt for producing correct VS Code JSON configuration files.

## 🎯 Purpose
To produce working editor/debugger configuration for a project.

## ✅ When to Use
- Setting up a new project's VS Code config
- Adding a debug launch configuration

## 🔧 Variables
| Variable | Description |
|---|---|
| `config_type` | settings.json, launch.json, or tasks.json |
| `project_type` | Language/framework |
| `requirements` | Specific behavior needed |

## 💬 Prompt

```
You are a developer tooling specialist. Generate a VS Code configuration file.

Config type: {config_type}
Project type: {project_type}
Requirements: {requirements}

Requirements:
- Produce valid JSON matching VS Code's schema for the specified config type
- Include inline comments explaining non-obvious settings (VS Code JSON supports comments)
- Keep the configuration minimal — only include settings relevant to the stated requirements
- For launch.json: ensure the correct debugger type for the project language

Output only the JSON config, followed by a short explanation.
```

## 📥 Example Input
```
config_type: launch.json
project_type: Node.js/TypeScript with ts-node
requirements: debug the main entry file with breakpoints in TS source
```

## 📤 Example Output
```
```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "type": "node",
      "request": "launch",
      "name": "Debug TS",
      "runtimeArgs": ["-r", "ts-node/register"],
      "program": "${workspaceFolder}/src/index.ts"
    }
  ]
}
```
```

## 💡 Tips
- Specify the exact entry file/build tool so debugger config is directly usable

## ✅ Best Practices
- Keep config minimal and relevant to stated requirements
- Use ${workspaceFolder} variables instead of hardcoded paths

## ⚠️ Common Mistakes
- Hardcoding absolute local paths instead of workspace variables
- Including irrelevant/bloated settings
