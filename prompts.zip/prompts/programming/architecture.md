# Software Architecture Advisor

> Design a system architecture for a given set of requirements.

## 📋 Description
A prompt for producing a reasoned architecture proposal with tradeoffs made explicit.

## 🎯 Purpose
To generate a well-reasoned architectural design with clear tradeoff analysis.

## ✅ When to Use
- Designing a new system or service
- Evaluating architectural options

## 🔧 Variables
| Variable | Description |
|---|---|
| `requirements` | Functional and non-functional requirements |
| `constraints` | Team size, budget, timeline, existing stack |
| `scale` | Expected scale, e.g. users, throughput |

## 💬 Prompt

```
You are a senior software architect. Propose an architecture for the following system.

Requirements: {requirements}
Constraints: {constraints}
Expected scale: {scale}

Produce:
1. A high-level architecture description (components and how they interact)
2. A simple Mermaid diagram representing the architecture
3. Key technology choices with 1-2 sentence justification each, grounded in the stated constraints (not generic "best practice")
4. Explicit tradeoffs considered and why the chosen option was preferred over alternatives
5. Scaling considerations and likely future bottlenecks
6. Risks and mitigation notes

Do not over-engineer for scale that isn't justified by the stated requirements.
```

## 📥 Example Input
```
requirements: task management app, real-time updates between collaborators
constraints: team of 2, 3-month timeline, familiar with Node.js
scale: expected 5,000 users in year one
```

## 📤 Example Output
```
## Architecture Overview
A modular monolith (not microservices) given the 2-person team and 3-month timeline...

```mermaid
graph LR
  Client -->|WebSocket| API
  API --> DB[(PostgreSQL)]
```

**Tradeoff:** Chose modular monolith over microservices to avoid operational overhead unjustified at this scale.
```

## 💡 Tips
- Always state team size/timeline constraints — they should shape complexity

## ✅ Best Practices
- Avoid recommending microservices/over-engineering for small teams/early stage
- Justify each tech choice against the specific constraints given

## ⚠️ Common Mistakes
- Recommending enterprise-scale architecture for a small early-stage project
- Skipping tradeoff explanations, presenting one option as objectively correct
