# FastAPI Endpoint Generator

> Generate a FastAPI endpoint with Pydantic validation.

## 📋 Description
A prompt for producing type-safe FastAPI endpoints with automatic validation.

## 🎯 Purpose
To produce production-ready FastAPI routes leveraging Pydantic models.

## ✅ When to Use
- Building a new FastAPI endpoint
- Adding request/response validation

## 🔧 Variables
| Variable | Description |
|---|---|
| `endpoint` | Route and method |
| `request_model` | Expected request fields |
| `response_model` | Expected response fields |
| `business_logic` | What the endpoint does |

## 💬 Prompt

```
You are a senior Python backend engineer specializing in FastAPI. Write an endpoint.

Endpoint: {endpoint}
Request fields: {request_model}
Response fields: {response_model}
Business logic: {business_logic}

Requirements:
- Define Pydantic models for request and response
- Use proper type hints and FastAPI dependency injection where relevant (e.g. for DB sessions)
- Raise HTTPException with appropriate status codes for error cases
- Add docstrings that will populate FastAPI's auto-generated docs
- Keep business logic separated from the route handler where practical (service function)

Output only the code, followed by a brief explanation.
```

## 📥 Example Input
```
endpoint: GET /items/{item_id}
request_model: item_id: int (path param)
response_model: id: int, name: str, price: float
business_logic: fetch item from DB, 404 if not found
```

## 📤 Example Output
```
```python
class ItemResponse(BaseModel):
    id: int
    name: str
    price: float

@router.get('/items/{item_id}', response_model=ItemResponse)
async def get_item(item_id: int, db: Session = Depends(get_db)):
    item = db.query(Item).get(item_id)
    if not item:
        raise HTTPException(status_code=404, detail='Item not found')
    return item
```
```

## 💡 Tips
- List response fields explicitly so the Pydantic model matches your API contract

## ✅ Best Practices
- Use response_model for automatic response validation/docs
- Separate business logic from route handlers for testability

## ⚠️ Common Mistakes
- Skipping response_model, losing auto-generated docs and validation
- Returning raw ORM objects without a schema boundary
