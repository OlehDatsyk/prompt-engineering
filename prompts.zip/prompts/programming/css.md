# CSS/Layout Generator

> Generate modern, responsive CSS.

## 📋 Description
A prompt for producing clean, responsive CSS using modern layout techniques.

## 🎯 Purpose
To produce maintainable, responsive CSS without unnecessary complexity.

## ✅ When to Use
- Styling a new component
- Building a responsive layout

## 🔧 Variables
| Variable | Description |
|---|---|
| `element` | What is being styled |
| `layout_approach` | Flexbox, Grid, etc. |
| `breakpoints` | Responsive breakpoints needed |

## 💬 Prompt

```
You are a senior frontend engineer. Write CSS for the following.

Element/component: {element}
Layout approach: {layout_approach}
Breakpoints: {breakpoints}

Requirements:
- Use modern CSS (Grid/Flexbox, custom properties for repeated values)
- Use relative units (rem/%/fr) over fixed px where appropriate for responsiveness
- Include the specified breakpoints using mobile-first media queries
- Avoid !important and overly specific selectors
- Add brief comments explaining non-obvious layout decisions

Output only the code, followed by a short explanation.
```

## 📥 Example Input
```
element: 3-column card grid that collapses to 1 column
layout_approach: CSS Grid
breakpoints: mobile <640px, tablet 640-1024px, desktop >1024px
```

## 📤 Example Output
```
```css
.card-grid {
  display: grid;
  grid-template-columns: 1fr;
  gap: 1.5rem;
}

@media (min-width: 640px) {
  .card-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (min-width: 1024px) {
  .card-grid { grid-template-columns: repeat(3, 1fr); }
}
```
```

## 💡 Tips
- Specify mobile-first vs desktop-first explicitly if it matters to your codebase

## ✅ Best Practices
- Use mobile-first media queries
- Avoid !important; increase specificity intentionally instead

## ⚠️ Common Mistakes
- Using fixed pixel widths that break responsiveness
- Overusing !important to override specificity issues
