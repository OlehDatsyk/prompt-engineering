# SQL Query Generator (Programming Context)

> Generate SQL queries embedded in application code.

## 📋 Description
A prompt for generating parameterized SQL queries safe for use in application code.

## 🎯 Purpose
To produce safe, efficient SQL for use within an application codebase.

## ✅ When to Use
- Writing a query to embed in backend code
- Adding a new data access function

## 🔧 Variables
| Variable | Description |
|---|---|
| `goal` | What the query should retrieve/modify |
| `schema` | Relevant table schema |
| `dialect` | SQL dialect, e.g. PostgreSQL |

## 💬 Prompt

```
You are a senior backend engineer writing SQL for use in application code.

Goal: {goal}
Schema: {schema}
Dialect: {dialect}

Requirements:
- Write the query using parameterized placeholders (never string-concatenate user input)
- Use explicit column names, never SELECT *
- Add an index recommendation if the query would benefit from one
- Note the expected time complexity/performance characteristics for large tables
- Provide the query wrapped as it would appear in application code (e.g. with a parameterized execute call)

Output the query and a short explanation.
```

## 📥 Example Input
```
goal: fetch a user's 10 most recent orders
schema: orders(id, user_id, created_at, total)
dialect: PostgreSQL
```

## 📤 Example Output
```
```sql
SELECT id, user_id, created_at, total
FROM orders
WHERE user_id = $1
ORDER BY created_at DESC
LIMIT 10;
```
**Index recommendation:** `CREATE INDEX idx_orders_user_created ON orders(user_id, created_at DESC);`
```

## 💡 Tips
- Always specify the dialect since syntax for pagination/params differs

## ✅ Best Practices
- Never SELECT *; specify columns explicitly
- Always use parameterized queries

## ⚠️ Common Mistakes
- String-concatenating user input into SQL (injection risk)
- Missing indexes on frequently filtered/sorted columns
