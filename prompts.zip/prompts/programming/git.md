# Git Workflow Assistant

> Generate correct git commands and resolve git situations.

## 📋 Description
A prompt for getting precise, safe git command sequences for a given situation.

## 🎯 Purpose
To avoid destructive git mistakes by getting the exact right command sequence.

## ✅ When to Use
- Unsure of the correct git command for a situation
- Recovering from a git mistake

## 🔧 Variables
| Variable | Description |
|---|---|
| `situation` | Current git state/problem |
| `goal` | Desired outcome |
| `risk_tolerance` | Whether history rewriting/force-push is acceptable |

## 💬 Prompt

```
You are a senior engineer helping with a git situation. Prioritize safety — never suggest destructive commands without an explicit warning.

Current situation: {situation}
Desired outcome: {goal}
Risk tolerance (is force-push/history rewrite acceptable?): {risk_tolerance}

Provide:
1. The exact command sequence to achieve the goal
2. A one-line explanation of what each command does
3. An explicit warning if any command is destructive or rewrites shared history, including how to back out safely first (e.g. creating a backup branch)
4. An alternative safer approach if one exists, even if slightly more steps

Do not suggest force-push to shared branches unless the user has explicitly confirmed it's safe to do so.
```

## 📥 Example Input
```
situation: committed to main by mistake, need it on a new branch instead
goal: move the last commit to a new branch without losing it
risk_tolerance: no force-push, main is shared
```

## 📤 Example Output
```
```bash
git branch feature/my-fix   # create new branch at current commit
git reset --hard HEAD~1     # move main back, WARNING: discards the commit from main's history locally
git checkout feature/my-fix # switch to new branch with the commit
```
**Warning:** `reset --hard` discards local changes if any are uncommitted — verify working tree is clean first.
```

## 💡 Tips
- State explicitly whether the branch is shared to avoid unsafe force-push suggestions

## ✅ Best Practices
- Always flag destructive/history-rewriting commands explicitly
- Suggest a backup branch before risky operations

## ⚠️ Common Mistakes
- Suggesting force-push to shared branches without warning
- Suggesting `reset --hard` without checking for uncommitted work
