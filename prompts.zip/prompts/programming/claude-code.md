# Claude Code Task Prompt

> Write an effective task prompt for Claude Code (agentic coding).

## 📋 Description
A prompt template for delegating a coding task to Claude Code with the right context and constraints.

## 🎯 Purpose
To get high-quality autonomous coding output by giving Claude Code clear scope and success criteria.

## ✅ When to Use
- Delegating a multi-file coding task to Claude Code
- Writing a task spec for agentic execution

## 🔧 Variables
| Variable | Description |
|---|---|
| `task` | The coding task to accomplish |
| `scope` | Files/directories in scope |
| `success_criteria` | How to know the task is done correctly |
| `constraints` | Things not to change/break |

## 💬 Prompt

```
Task: {task}

Scope: {scope}

Success criteria:
{success_criteria}

Constraints:
{constraints}

Instructions:
- Before making changes, briefly explore the relevant files to understand existing patterns and conventions, and follow them
- Make the smallest change that fully satisfies the task — avoid unrelated refactors
- Run existing tests (or write new ones if none exist for this area) to verify the change
- If you encounter ambiguity, state your assumption explicitly and proceed rather than stopping
- Summarize the changes made and how they were verified at the end
```

## 📥 Example Input
```
task: add input validation to the signup endpoint
scope: src/routes/auth.js
success_criteria: invalid emails/short passwords return 400 with clear error message; existing tests still pass
constraints: don't change the response shape for valid requests
```

## 📤 Example Output
```
[Claude Code explores auth.js and existing validation patterns, implements validation matching existing error format, runs test suite, summarizes: "Added email/password validation matching existing error response shape. All 12 existing tests pass; added 4 new tests for validation cases."]
```

## 💡 Tips
- Give explicit success criteria — agentic tools perform much better with a clear definition of done

## ✅ Best Practices
- Constrain scope explicitly to avoid unrelated refactors
- Ask the agent to verify via existing tests, not just claim success

## ⚠️ Common Mistakes
- Vague task descriptions leading to overly broad changes
- Not specifying success criteria, making it hard to verify the result
