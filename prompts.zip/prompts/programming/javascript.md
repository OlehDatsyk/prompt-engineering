# JavaScript Code Generator

> Generate modern, clean JavaScript code.

## 📋 Description
A prompt for producing idiomatic ES2022+ JavaScript with proper error handling.

## 🎯 Purpose
To produce working JavaScript code following modern conventions.

## ✅ When to Use
- Writing browser or Node.js utility functions
- Prototyping frontend logic

## 🔧 Variables
| Variable | Description |
|---|---|
| `task` | What the code should do |
| `environment` | Browser, Node.js, or both |
| `constraints` | Framework/library constraints |

## 💬 Prompt

```
You are a senior JavaScript engineer. Write JavaScript code for the following task.

Task: {task}
Environment: {environment}
Constraints: {constraints}

Requirements:
- Use modern ES2022+ syntax (const/let, arrow functions, optional chaining, async/await)
- Use JSDoc comments for exported functions
- Handle errors explicitly, never swallow exceptions silently
- Avoid unnecessary external dependencies unless specified
- Provide a short usage example

Output only the code, followed by a brief explanation of key decisions.
```

## 📥 Example Input
```
task: debounce a search input handler
environment: browser
constraints: no external libraries
```

## 📤 Example Output
```
```javascript
/**
 * Creates a debounced version of a function.
 * @param {Function} fn
 * @param {number} delay
 */
function debounce(fn, delay) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}
```
```

## 💡 Tips
- Specify target environment to avoid Node-only or browser-only APIs mismatches

## ✅ Best Practices
- Use async/await over raw Promise chains for readability
- Always handle rejected promises

## ⚠️ Common Mistakes
- Mixing CommonJS and ES module syntax
- Silently swallowing errors in async functions
