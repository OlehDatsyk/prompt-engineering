# Code Debugging Assistant

> Diagnose and fix a bug with clear reasoning.

## 📋 Description
A structured prompt for debugging code by isolating root cause before proposing a fix.

## 🎯 Purpose
To systematically diagnose bugs rather than guessing at fixes.

## ✅ When to Use
- An error/bug needs diagnosis
- Unexpected behavior needs root-cause analysis

## 🔧 Variables
| Variable | Description |
|---|---|
| `code` | The buggy code |
| `error_or_symptom` | Error message or observed incorrect behavior |
| `expected_behavior` | What should happen instead |

## 💬 Prompt

```
You are a senior engineer debugging production code. Do not guess — reason systematically.

Code:
{code}

Error/symptom observed: {error_or_symptom}
Expected behavior: {expected_behavior}

Process:
1. Identify the likely root cause, explaining your reasoning step by step
2. State any assumptions you're making about the surrounding system
3. Propose the minimal fix that addresses the root cause (not a symptom patch)
4. Show the corrected code
5. Suggest a test case that would have caught this bug
6. Note any related risk areas in the code that could have similar bugs

If you're not fully certain of the root cause from the given information, say so explicitly and ask for the missing detail rather than guessing.
```

## 📥 Example Input
```
code: [function that occasionally returns None]
error_or_symptom: intermittent AttributeError: 'NoneType' object has no attribute 'id'
expected_behavior: should always return a valid object or raise explicitly
```

## 📤 Example Output
```
**Root cause:** The function returns `None` when the database query finds no match, but callers assume a result always exists...

**Fix:**
```python
def get_user(id):
    user = db.query(...).first()
    if user is None:
        raise UserNotFoundError(id)
    return user
```
```

## 💡 Tips
- Always include the exact error message/traceback, not a paraphrase

## ✅ Best Practices
- Ask the model to state its confidence and assumptions explicitly
- Request a regression test alongside the fix

## ⚠️ Common Mistakes
- Accepting a symptom patch instead of a root-cause fix
- Omitting the full error traceback, leading to guesswork
