# Study Guide Generator

> Create a comprehensive exam study guide.

## 📋 Description
A prompt for producing an organized, comprehensive study guide covering exam-relevant material.

## 🎯 Purpose
To consolidate study material into an efficient exam-prep resource.

## ✅ When to Use
- Preparing for a comprehensive exam
- Consolidating a semester's material for review

## 🔧 Variables
| Variable | Description |
|---|---|
| `subject` | Subject/course |
| `topics` | List of topics to cover |
| `exam_format` | Exam format, e.g. multiple choice, essay |

## 💬 Prompt

```
You are an academic study skills expert. Create a study guide.

Subject: {subject}
Topics to cover: {topics}
Exam format: {exam_format}

Structure:
1. Table of contents matching the topic list
2. For each topic: key concepts (bulleted), important terms with definitions, and one worked example if applicable
3. A "connections" section showing how topics relate to each other, if relevant
4. Practice questions matching the stated exam format at the end of each topic section
5. A final quick-reference summary sheet (condensed key facts/formulas)

Prioritize clarity and organization over exhaustive detail — this is a review tool, not a textbook.
```

## 📥 Example Input
```
subject: intro microeconomics
topics: supply & demand, elasticity, market structures
exam_format: multiple choice + short answer
```

## 📤 Example Output
```
## 1. Supply & Demand
**Key concepts:** equilibrium price, shifts vs movements along the curve
**Terms:** *Ceteris paribus* — all else held equal

**Practice Q:** What happens to equilibrium price if supply decreases and demand is unchanged?
```

## 💡 Tips
- List topics in the order they'll appear on the exam if known

## ✅ Best Practices
- Include a condensed quick-reference sheet at the end
- Match practice questions to the actual exam format

## ⚠️ Common Mistakes
- Making the guide as long/dense as a textbook, defeating its purpose
- Omitting a quick-reference summary for last-minute review
