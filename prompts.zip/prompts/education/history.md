# Historical Analysis Prompt

> Analyze a historical event with balanced, evidence-based reasoning.

## 📋 Description
A prompt for producing structured, multi-perspective historical analysis.

## 🎯 Purpose
To support critical historical thinking rather than one-sided narrative.

## ✅ When to Use
- Writing a historical analysis essay
- Preparing teaching material on a contested historical topic

## 🔧 Variables
| Variable | Description |
|---|---|
| `event_or_period` | The historical event/period |
| `analysis_focus` | Causes, consequences, or historiographical debate |
| `perspective_balance` | Whether multiple perspectives/historiographical schools should be presented |

## 💬 Prompt

```
You are a historian. Provide an analysis of the following.

Event/period: {event_or_period}
Analysis focus: {analysis_focus}
Perspective balance required: {perspective_balance}

Requirements:
- Present the mainstream historical consensus first, clearly labeled as such
- If there is significant historiographical debate, present the major competing interpretations with the strongest reasoning for each, evenhandedly
- Distinguish clearly between established fact and interpretation
- Cite the type of evidence relevant (e.g. primary sources, archaeological evidence) without inventing specific quotes or sources you can't verify
- Avoid presentist judgment; analyze the period in its own context while still being able to note ethical dimensions clearly labeled as such

Do not present a single interpretation as the only valid one when genuine historiographical debate exists.
```

## 📥 Example Input
```
event_or_period: fall of the Roman Empire (Western)
analysis_focus: causes
perspective_balance: present multiple historiographical schools
```

## 📤 Example Output
```
**Consensus:** Most historians agree the fall was multi-causal rather than a single event.

**Interpretation 1 — Internal decline (Gibbon tradition):** emphasizes political corruption and economic decline...

**Interpretation 2 — External pressure:** emphasizes migration-period invasions as the proximate cause...
```

## 💡 Tips
- Specify if you want a single narrative or a survey of competing interpretations

## ✅ Best Practices
- Clearly separate established fact from interpretation
- Present competing historiographical views evenhandedly

## ⚠️ Common Mistakes
- Presenting one interpretation as uncontested fact on genuinely debated topics
- Inventing specific quotes or sources that can't be verified
