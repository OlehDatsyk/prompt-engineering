# Study Summary Generator

> Summarize study material into a concise, structured summary.

## 📋 Description
A prompt for condensing material into an accurate, well-organized study summary.

## 🎯 Purpose
To produce concise summaries that retain the key ideas needed for study/review.

## ✅ When to Use
- Condensing lecture notes or a textbook chapter
- Preparing quick-review material before an exam

## 🔧 Variables
| Variable | Description |
|---|---|
| `material` | The source material to summarize |
| `length` | Target summary length |
| `focus` | Specific focus, if any, e.g. definitions, formulas |

## 💬 Prompt

```
You are a study skills expert. Summarize the following material for review purposes.

Material:
{material}

Target length: {length}
Focus: {focus}

Requirements:
- Organize by subtopic with clear headings
- Bold key terms on first use with a short definition
- Use bullet points over dense paragraphs
- Preserve any critical formulas/dates/facts exactly as given — do not alter numbers
- End with a "Key Takeaways" section of 3-5 bullet points

Do not introduce information not present in the source material.
```

## 📥 Example Input
```
material: [3-page chapter on the causes of the French Revolution]
length: half a page
focus: causes and key dates
```

## 📤 Example Output
```
## Economic Causes
- **Deficit spending**: France's involvement in the American Revolution left it near bankruptcy...

## Key Takeaways
- Financial crisis, social inequality, and Enlightenment ideas combined to spark revolution in 1789
```

## 💡 Tips
- Specify focus areas if the source covers more than you need summarized

## ✅ Best Practices
- Preserve exact numbers/dates from the source without alteration
- Bold and define key terms on first use

## ⚠️ Common Mistakes
- Introducing facts not present in the source material
- Summarizing so tersely that key relationships between ideas are lost
