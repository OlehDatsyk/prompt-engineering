# Flashcard Generator

> Generate spaced-repetition-ready flashcards on a topic.

## 📋 Description
A prompt for producing concise, effective flashcards for active recall study.

## 🎯 Purpose
To produce flashcards optimized for retention via active recall.

## ✅ When to Use
- Studying for an exam
- Building a spaced-repetition deck (e.g. Anki)

## 🔧 Variables
| Variable | Description |
|---|---|
| `topic` | Subject matter |
| `num_cards` | Number of flashcards |
| `format` | Term-definition, Q&A, or cloze deletion |

## 💬 Prompt

```
You are a learning science specialist creating flashcards optimized for active recall.

Topic: {topic}
Number of cards: {num_cards}
Format: {format}

Requirements:
- Each card tests ONE discrete fact/concept (atomic — no compound questions)
- Front: a clear question or prompt; Back: a concise, unambiguous answer
- Avoid yes/no questions — they don't exercise real recall
- Order from foundational to more advanced concepts
- For cloze deletion format, bold the blanked term with {{c1::term}} style notation

Output as a numbered list: Front | Back.
```

## 📥 Example Input
```
topic: Spanish present tense irregular verbs
num_cards: 10
format: Q&A
```

## 📤 Example Output
```
1. Front: What is the yo-form of 'tener'? | Back: tengo
2. Front: What is the yo-form of 'ser'? | Back: soy
...
```

## 💡 Tips
- Request atomic single-fact cards explicitly — compound cards hurt recall testing

## ✅ Best Practices
- Keep each card testing exactly one fact
- Order cards from foundational to advanced

## ⚠️ Common Mistakes
- Compound cards testing multiple facts at once
- Yes/no questions that don't require real recall
