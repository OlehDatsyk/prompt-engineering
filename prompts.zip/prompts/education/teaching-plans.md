# Unit/Course Teaching Plan Generator

> Plan a multi-session teaching unit with sequencing and assessment.

## 📋 Description
A prompt for producing a full unit plan spanning multiple lessons.

## 🎯 Purpose
To produce a coherent multi-session teaching sequence with built-in assessment.

## ✅ When to Use
- Planning a multi-week unit
- Structuring a course syllabus at the unit level

## 🔧 Variables
| Variable | Description |
|---|---|
| `unit_topic` | Overall unit topic |
| `num_sessions` | Number of class sessions |
| `grade_level` | Target level |
| `final_assessment` | Type of culminating assessment |

## 💬 Prompt

```
You are a curriculum designer. Plan a full teaching unit.

Unit topic: {unit_topic}
Number of sessions: {num_sessions}
Grade level: {grade_level}
Final assessment: {final_assessment}

Structure:
1. Unit-level learning objectives (3-5)
2. Session-by-session breakdown table: Session # | Topic | Key Activity | Formative Check
3. Sequencing rationale: why topics are ordered this way (build from foundational to complex)
4. Description of the final assessment and how it maps back to the unit objectives
5. Suggested differentiation strategies used across the unit

Ensure session topics build logically on each other — no session should require knowledge not yet taught.
```

## 📥 Example Input
```
unit_topic: introduction to programming with Python
num_sessions: 6
grade_level: high school
final_assessment: small coding project
```

## 📤 Example Output
```
| Session | Topic | Activity | Check |
|---|---|---|---|
| 1 | Variables & Types | Live coding + exercises | Exit ticket |
| 2 | Conditionals | Pair programming | Quick quiz |

**Sequencing rationale:** Variables before conditionals before loops, each building on prior session's syntax...
```

## 💡 Tips
- Specify the final assessment upfront so earlier sessions can build toward it

## ✅ Best Practices
- Ensure logical topic sequencing with no forward dependencies
- Map the final assessment explicitly to unit objectives

## ⚠️ Common Mistakes
- Session topics that require unteached prerequisite knowledge
- No clear link between daily activities and the final assessment
