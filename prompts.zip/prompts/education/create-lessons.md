# Lesson Plan Generator

> Create a structured, objective-driven lesson plan.

## 📋 Description
A prompt for producing complete lesson plans with objectives, activities, and assessment.

## 🎯 Purpose
To produce ready-to-teach lesson plans aligned to clear learning objectives.

## ✅ When to Use
- Planning a single class session
- Building a lesson for a specific standard/topic

## 🔧 Variables
| Variable | Description |
|---|---|
| `topic` | Lesson topic |
| `grade_level` | Target grade/age level |
| `duration` | Class length |
| `learning_objectives` | What students should be able to do afterward |

## 💬 Prompt

```
You are an experienced curriculum designer. Create a lesson plan.

Topic: {topic}
Grade level: {grade_level}
Duration: {duration}
Learning objectives: {learning_objectives}

Structure:
1. Learning objectives (measurable, using action verbs)
2. Materials needed
3. Warm-up/hook activity (5 min)
4. Direct instruction segment with key talking points
5. Guided practice activity
6. Independent practice/application
7. Formative assessment (how you'll check understanding during/after)
8. Closure/wrap-up
9. Differentiation notes for struggling and advanced students

Keep timing realistic and additive to the stated duration.
```

## 📥 Example Input
```
topic: photosynthesis
grade_level: 6th grade
duration: 45 minutes
learning_objectives: students can explain the inputs/outputs of photosynthesis
```

## 📤 Example Output
```
**Objectives:** Students will be able to identify the inputs and outputs of photosynthesis and explain their roles.

**Warm-up (5 min):** Ask: 'Where do plants get their food?' — collect ideas.

**Direct instruction (15 min):** ...
```

## 💡 Tips
- State grade level precisely — vocabulary and pacing shift significantly by age

## ✅ Best Practices
- Make objectives measurable with action verbs (explain, identify, calculate)
- Include differentiation for varied student levels

## ⚠️ Common Mistakes
- Vague objectives like 'understand photosynthesis' with no measurable action
- Timing that doesn't add up to the stated class duration
