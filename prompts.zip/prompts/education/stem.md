# STEM Problem Walkthrough Generator

> Produce a clear, step-by-step STEM problem solution.

## 📋 Description
A prompt for generating fully worked STEM solutions with reasoning shown at each step.

## 🎯 Purpose
To produce solutions that teach the method, not just the final answer.

## ✅ When to Use
- Working through a math/science/engineering problem
- Creating worked examples for study material

## 🔧 Variables
| Variable | Description |
|---|---|
| `problem` | The STEM problem to solve |
| `subject` | Math, physics, chemistry, engineering, etc. |
| `show_level` | How detailed the steps should be |

## 💬 Prompt

```
You are a STEM educator. Solve the following problem with full reasoning shown.

Problem: {problem}
Subject: {subject}
Detail level for steps: {show_level}

Requirements:
- State the relevant formula/principle before applying it
- Show each calculation step explicitly, not just the final numbers
- Explain WHY each step is taken, not just what is being done
- Double-check the final answer by verifying units/plausibility
- Highlight the final answer clearly at the end

If you find you've made an arithmetic error while double-checking, correct it and note the correction rather than hiding it.
```

## 📥 Example Input
```
problem: A 2kg object accelerates from rest to 10 m/s in 4 seconds. Find the net force applied.
subject: physics
show_level: full detail for a high school student
```

## 📤 Example Output
```
**Step 1 — Find acceleration:** a = Δv/Δt = 10/4 = 2.5 m/s²
**Step 2 — Apply Newton's second law:** F = ma = 2kg × 2.5 m/s² = 5 N
**Check:** Units resolve to Newtons; magnitude is reasonable for a light object.

**Final Answer: 5 N**
```

## 💡 Tips
- Ask for a self-check/verification step to catch arithmetic errors

## ✅ Best Practices
- Explain the reasoning behind each step, not just mechanics
- Verify units and plausibility of the final answer

## ⚠️ Common Mistakes
- Skipping the 'why' and only showing mechanical steps
- Not verifying the final answer, letting arithmetic slips through
