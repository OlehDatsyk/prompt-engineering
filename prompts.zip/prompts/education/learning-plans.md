# Personalized Learning Plan Generator

> Create a structured, time-bound learning plan for a skill/subject.

## 📋 Description
A prompt for producing a realistic, milestone-based learning roadmap.

## 🎯 Purpose
To produce an actionable plan for acquiring a skill within a timeframe.

## ✅ When to Use
- Planning self-study for a new skill
- Structuring a course curriculum

## 🔧 Variables
| Variable | Description |
|---|---|
| `skill_or_subject` | What to learn |
| `current_level` | Starting knowledge level |
| `timeframe` | Available time, e.g. 8 weeks, 5 hrs/week |
| `goal` | Specific end goal, e.g. pass a certification |

## 💬 Prompt

```
You are a learning design expert. Create a personalized learning plan.

Subject/skill: {skill_or_subject}
Current level: {current_level}
Timeframe: {timeframe}
Goal: {goal}

Structure:
1. A realistic milestone breakdown across the timeframe (weekly or bi-weekly)
2. For each milestone: specific topics/skills to cover and a way to self-assess mastery
3. Recommended practice activities (not just passive reading/watching)
4. Suggested checkpoints to identify if you're falling behind
5. A note on prerequisite gaps if current_level suggests any

Keep the plan realistic for the stated available time — do not overload weeks.
```

## 📥 Example Input
```
skill_or_subject: data structures & algorithms
current_level: comfortable with Python basics, no DSA experience
timeframe: 10 weeks, 6 hrs/week
goal: pass technical coding interviews
```

## 📤 Example Output
```
**Week 1-2: Arrays & Strings**
- Cover: two-pointer technique, sliding window
- Practice: 10 problems (easy→medium) on a platform of choice
- Self-check: solve a new medium problem in under 30 min unaided

**Week 3-4: Linked Lists & Stacks**...
```

## 💡 Tips
- Be honest about current level — overestimating leads to an unrealistic plan

## ✅ Best Practices
- Include active practice, not just passive content consumption
- Build in self-assessment checkpoints

## ⚠️ Common Mistakes
- Overloading weekly milestones beyond the stated available hours
- Plans that are all passive reading with no practice/application
