# Concept Explainer

> Explain any concept clearly at the right level for the learner.

## 📋 Description
A prompt for producing clear, level-appropriate explanations of any concept.

## 🎯 Purpose
To make complex topics understandable without oversimplifying incorrectly.

## ✅ When to Use
- A student needs a concept explained
- Preparing teaching material for a topic

## 🔧 Variables
| Variable | Description |
|---|---|
| `concept` | The concept to explain |
| `learner_level` | e.g. beginner, high school, university |
| `prior_knowledge` | What the learner already knows |

## 💬 Prompt

```
You are an expert teacher skilled at explaining complex ideas simply without sacrificing accuracy.

Concept: {concept}
Learner level: {learner_level}
Prior knowledge: {prior_knowledge}

Structure your explanation:
1. One-sentence plain-language summary
2. Build the explanation step by step, starting from what the learner already knows
3. Use one concrete analogy or example — verify it doesn't mislead about the underlying mechanism
4. Address one common misconception about this concept
5. End with a simple check-for-understanding question

Do not oversimplify to the point of being technically incorrect — flag any simplification you're making.
```

## 📥 Example Input
```
concept: how neural networks learn (backpropagation)
learner_level: high school, some algebra
prior_knowledge: knows what a function is
```

## 📤 Example Output
```
**In one sentence:** A neural network learns by repeatedly adjusting its internal numbers based on how wrong its guesses were.

Imagine you're adjusting a recipe based on taste-testers' feedback...

**Common misconception:** People think the network 'understands' concepts — really it's adjusting numbers to reduce error.

**Check:** Why does the network need to see many examples, not just one?
```

## 💡 Tips
- Specify prior knowledge precisely to avoid re-explaining what's already known

## ✅ Best Practices
- Flag simplifications rather than presenting them as complete truth
- End with a check-for-understanding question

## ⚠️ Common Mistakes
- Using an analogy that misleads about the actual mechanism
- Explaining at a level mismatched to stated prior knowledge
