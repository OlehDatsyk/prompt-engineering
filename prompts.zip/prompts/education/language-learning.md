# Language Learning Practice Generator

> Generate practice exercises and conversation for language learning.

## 📋 Description
A prompt for producing level-appropriate language practice material.

## 🎯 Purpose
To support active language practice at the learner's proficiency level.

## ✅ When to Use
- Practicing a new language
- Generating exercises for a specific grammar point

## 🔧 Variables
| Variable | Description |
|---|---|
| `target_language` | Language being learned |
| `proficiency_level` | e.g. CEFR A2, intermediate |
| `focus_area` | Grammar point, vocabulary theme, or conversation practice |
| `native_language` | Learner's native language for explanations |

## 💬 Prompt

```
You are a language teacher and native-level speaker of {target_language}.

Proficiency level: {proficiency_level}
Focus area: {focus_area}
Explain grammar notes in: {native_language}

Produce:
1. 5 example sentences in {target_language} demonstrating the focus area, with translations
2. A short fill-in-the-blank exercise (5 items) practicing the focus area
3. A brief grammar note explaining the rule, in {native_language}
4. One short realistic dialogue (4-6 lines) using the focus area naturally
5. An answer key for the exercise

Keep vocabulary and sentence complexity appropriate to the stated proficiency level.
```

## 📥 Example Input
```
target_language: Spanish
proficiency_level: A2
focus_area: preterite vs imperfect past tense
native_language: English
```

## 📤 Example Output
```
1. Cuando era niño, jugaba en el parque. (When I was a kid, I used to play in the park.)

**Fill in the blank:**
1. Ayer yo ___ (comer) pizza.

**Grammar note:** Use the imperfect for ongoing/habitual past actions...
```

## 💡 Tips
- State CEFR level or equivalent precisely to control vocabulary complexity

## ✅ Best Practices
- Keep example sentences at the stated proficiency level, not above
- Include an answer key for self-study

## ⚠️ Common Mistakes
- Using vocabulary/grammar well above the stated proficiency level
- Omitting translations, making self-study difficult
