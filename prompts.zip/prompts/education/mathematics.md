# Math Concept & Practice Generator

> Explain a math concept and generate practice problems with solutions.

## 📋 Description
A prompt for producing a math concept explanation paired with graduated practice problems.

## 🎯 Purpose
To support both conceptual understanding and procedural practice in math.

## ✅ When to Use
- Teaching or reviewing a math topic
- Generating practice sets

## 🔧 Variables
| Variable | Description |
|---|---|
| `topic` | Math topic |
| `level` | Grade/course level |
| `num_problems` | Number of practice problems |
| `include_solutions` | Whether full worked solutions are needed |

## 💬 Prompt

```
You are a math teacher. Cover the following topic.

Topic: {topic}
Level: {level}
Number of practice problems: {num_problems}
Include full worked solutions: {include_solutions}

Structure:
1. A concise explanation of the concept with one worked example
2. {num_problems} practice problems, ordered from easier to harder
3. If solutions requested: full step-by-step solutions for each, not just final answers
4. A note on the most common error students make with this topic

Ensure problems are solvable using only the concept covered (no unstated prerequisite knowledge).
```

## 📥 Example Input
```
topic: solving quadratic equations by factoring
level: 9th grade algebra
num_problems: 5
include_solutions: yes
```

## 📤 Example Output
```
**Concept:** To solve ax²+bx+c=0 by factoring, rewrite as a product of two binomials equal to zero...

**Problem 1:** x² - 5x + 6 = 0
**Solution:** (x-2)(x-3)=0 → x=2 or x=3

**Common error:** Forgetting that a quadratic can have two solutions, not just one.
```

## 💡 Tips
- Order problems from easy to hard for scaffolded practice

## ✅ Best Practices
- Include the most common student error as a teaching note
- Ensure no unstated prerequisite is required to solve the problems

## ⚠️ Common Mistakes
- Jumping straight to hard problems without scaffolding
- Giving only final answers when full solutions were requested
