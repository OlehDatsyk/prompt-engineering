# Quiz Generator

> Generate a quiz with varied question types and an answer key.

## 📋 Description
A prompt for producing balanced quizzes testing different cognitive levels.

## 🎯 Purpose
To produce ready-to-use quizzes with accurate answer keys.

## ✅ When to Use
- Creating a formative assessment
- Generating practice questions on a topic

## 🔧 Variables
| Variable | Description |
|---|---|
| `topic` | Quiz topic |
| `num_questions` | Number of questions |
| `question_types` | Multiple choice, short answer, etc. |
| `difficulty` | Target difficulty level |

## 💬 Prompt

```
You are an assessment designer. Create a quiz.

Topic: {topic}
Number of questions: {num_questions}
Question types: {question_types}
Difficulty: {difficulty}

Requirements:
- Vary cognitive level: include recall, application, and at least one analysis-level question
- For multiple choice: 4 options each, with plausible distractors (not obviously wrong)
- Number all questions clearly
- Provide a separate answer key at the end with a one-line justification for each answer
- Ensure no question can be answered correctly using only another question's content (no leakage)
```

## 📥 Example Input
```
topic: World War I causes
num_questions: 5
question_types: multiple choice, one short answer
difficulty: high school
```

## 📤 Example Output
```
1. Which of the following was a long-term cause of WWI?
   A) Assassination of Franz Ferdinand  B) Alliance systems  C) ...

**Answer Key**
1. B — Alliance systems created a long-term structural cause, unlike the assassination which was the immediate trigger.
```

## 💡 Tips
- Specify difficulty explicitly, since 'basic' recall questions vs analysis-level differ significantly

## ✅ Best Practices
- Make multiple choice distractors genuinely plausible, not obviously wrong
- Vary cognitive level, not just recall questions

## ⚠️ Common Mistakes
- Distractors that are obviously wrong, making questions trivial
- Answer key with no justification, making errors hard to catch
