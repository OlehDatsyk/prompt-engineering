# Programming Course Module Generator

> Design a self-contained programming course module.

## 📋 Description
A prompt for producing a structured programming lesson with exercises and solutions.

## 🎯 Purpose
To produce a teachable, hands-on programming module.

## ✅ When to Use
- Building a course curriculum
- Creating a workshop/tutorial module

## 🔧 Variables
| Variable | Description |
|---|---|
| `topic` | Programming topic/concept |
| `language` | Programming language |
| `learner_level` | Beginner, intermediate, advanced |
| `duration` | Module length, e.g. 1 hour |

## 💬 Prompt

```
You are a programming instructor designing a course module.

Topic: {topic}
Language: {language}
Learner level: {learner_level}
Duration: {duration}

Structure:
1. Learning objectives (2-3, specific and testable)
2. Concept explanation with a minimal working code example
3. A guided coding exercise (starter code + instructions, not the full solution)
4. The complete solution code, with comments explaining key lines
5. A "common pitfalls" section specific to this topic
6. A stretch challenge for learners who finish early

Ensure all code actually runs and follows current best practices for the specified language.
```

## 📥 Example Input
```
topic: list comprehensions
language: Python
learner_level: beginner (knows basic loops)
duration: 30 minutes
```

## 📤 Example Output
```
**Objectives:** Write a list comprehension to transform and filter a list.

**Concept:** ```python
squares = [x**2 for x in range(10)]
```

**Exercise:** Given a list of words, write a comprehension that returns only words longer than 4 characters, uppercased.

**Solution:** ```python
result = [w.upper() for w in words if len(w) > 4]
```
```

## 💡 Tips
- State prior knowledge assumed so the module doesn't re-teach basics unnecessarily

## ✅ Best Practices
- Give starter code for exercises, not just instructions
- Include a stretch challenge for fast finishers

## ⚠️ Common Mistakes
- Providing the full solution embedded in the exercise instructions
- Code examples that don't actually run as written
