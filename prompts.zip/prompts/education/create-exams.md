# Exam Generator

> Generate a comprehensive exam covering multiple topics/units.

## 📋 Description
A prompt for producing structured, weighted exams spanning multiple learning objectives.

## 🎯 Purpose
To produce a complete summative exam with appropriate coverage and weighting.

## ✅ When to Use
- Creating a unit or final exam
- Building a comprehensive assessment across topics

## 🔧 Variables
| Variable | Description |
|---|---|
| `topics` | List of topics/units covered |
| `total_points` | Total point value |
| `format` | Mix of question formats |
| `time_limit` | Exam duration |

## 💬 Prompt

```
You are an assessment designer. Create a full exam.

Topics covered: {topics}
Total points: {total_points}
Format: {format}
Time limit: {time_limit}

Requirements:
- Weight point allocation roughly proportional to topic importance/time spent (state your weighting rationale briefly)
- Organize by section per topic, with clear point values per question
- Include a mix of difficulty within each section (not all hard or all easy)
- Provide a complete answer key with point breakdowns for partial credit where applicable
- Ensure total points sum exactly to {total_points}
```

## 📥 Example Input
```
topics: cell biology (40%), genetics (35%), evolution (25%)
total_points: 100
format: multiple choice + short answer + one essay
time_limit: 60 minutes
```

## 📤 Example Output
```
**Section 1: Cell Biology (40 pts)**
1. (4 pts) Which organelle...

**Section 3: Evolution — Essay (25 pts)**
Explain how natural selection leads to adaptation, using a specific example. (Rubric: 10 pts mechanism, 10 pts example accuracy, 5 pts clarity)
```

## 💡 Tips
- Provide relative topic weighting/importance to guide point allocation

## ✅ Best Practices
- State weighting rationale so point distribution is defensible
- Include partial-credit guidance for open-ended questions

## ⚠️ Common Mistakes
- Point totals that don't sum correctly
- Uneven difficulty within a section, all clustered at one extreme
