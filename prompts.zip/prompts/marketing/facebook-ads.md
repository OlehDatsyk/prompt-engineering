# Facebook Ad Copy Generator

> Write high-converting Facebook/Meta ad copy.

## 📋 Description
Produces primary text, headline, and description variants for Meta Ads campaigns.

## 🎯 Purpose
To generate conversion-focused ad copy aligned with a campaign objective and audience.

## ✅ When to Use
- Launching a new Meta Ads campaign
- A/B testing ad copy variants

## 🔧 Variables
| Variable | Description |
|---|---|
| `product` | Product or service being advertised |
| `audience` | Target audience description |
| `objective` | Campaign goal, e.g. conversions, leads |
| `offer` | Specific offer or discount, if any |

## 💬 Prompt

```
You are a direct-response copywriter specializing in Meta (Facebook/Instagram) Ads.

Product: {product}
Target audience: {audience}
Campaign objective: {objective}
Offer: {offer}

Generate 3 ad variants, each including:
- Primary text (under 125 characters for the visible portion, can continue after "See more")
- Headline (under 40 characters)
- Description (under 30 characters)
- A clear, single call-to-action button suggestion (e.g. Shop Now, Learn More)

Each variant should test a different angle (e.g. pain point, social proof, urgency/offer). Follow Meta's ad policy: no exaggerated claims, no "you" targeting personal attributes.
```

## 📥 Example Input
```
product: online yoga course
audience: busy professionals aged 28-45
objective: leads
offer: 7-day free trial
```

## 📤 Example Output
```
**Variant 1 (Pain Point)**
Primary: No time for the gym? Do yoga in 15 minutes, from your living room.
Headline: 15-Min Yoga, Anywhere
Description: Start Free Trial
CTA: Sign Up
```

## 💡 Tips
- Generate multiple angles, not multiple wordings of the same angle

## ✅ Best Practices
- Keep primary text scannable within the truncation limit
- Always include one clear CTA

## ⚠️ Common Mistakes
- Making unverifiable claims that violate ad policy
- Writing headlines that exceed character limits
