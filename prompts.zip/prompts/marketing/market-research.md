# Market Research Assistant

> Structure and synthesize market research on a given niche.

## 📋 Description
Guides structured market research covering trends, audience, and opportunity gaps.

## 🎯 Purpose
To produce an organized research summary supporting strategic decisions.

## ✅ When to Use
- Evaluating a new market or niche
- Preparing a research brief for stakeholders

## 🔧 Variables
| Variable | Description |
|---|---|
| `industry` | Industry or niche to research |
| `focus_area` | Specific angle, e.g. trends, pricing, audience needs |
| `region` | Geographic scope |

## 💬 Prompt

```
You are a market research analyst. Structure a research summary for the following.

Industry/niche: {industry}
Focus area: {focus_area}
Region: {region}

Produce a structured brief with:
1. Market overview (2-3 sentences)
2. Key trends (bulleted, with brief explanation each)
3. Target audience segments (2-3, with needs/pain points)
4. Notable gaps or underserved needs
5. Key risks or headwinds
6. Suggested next research steps

IMPORTANT: Do not fabricate specific statistics, market sizes, or company data. Where real data would strengthen the brief, insert [VERIFY: specific data point] instead of inventing numbers.
```

## 📥 Example Input
```
industry: pet tech (smart pet feeders/trackers)
focus_area: consumer trends
region: North America
```

## 📤 Example Output
```
## Market Overview
The pet tech space has grown alongside rising pet ownership and willingness to spend on premium care...

## Key Trends
- Subscription-based pet food/tech bundles
- [VERIFY: market size figures]
```

## 💡 Tips
- Always pair this with real search/data sources before presenting externally

## ✅ Best Practices
- Explicitly instruct the model not to fabricate statistics
- Use structured sections for easy stakeholder review

## ⚠️ Common Mistakes
- Trusting fabricated market size or growth figures without verification
- Treating output as final research instead of a starting brief
