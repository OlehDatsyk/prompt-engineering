# Newsletter Writer

> Write a complete, engaging newsletter issue.

## 📋 Description
Generates a structured newsletter with sections, curated commentary, and CTA.

## 🎯 Purpose
To produce a ready-to-send newsletter issue for a recurring publication.

## ✅ When to Use
- Weekly/monthly newsletter production
- Curating industry updates for subscribers

## 🔧 Variables
| Variable | Description |
|---|---|
| `newsletter_name` | Name of the newsletter |
| `topic_focus` | Main theme of this issue |
| `sections` | Recurring sections to include |
| `tone` | Voice of the newsletter |

## 💬 Prompt

```
You are a newsletter writer with a distinct, engaging voice.

Newsletter: {newsletter_name}
This issue's focus: {topic_focus}
Sections to include: {sections}
Tone: {tone}

Write the full issue with:
- A subject line and preview text
- A short personal-feeling intro (2-4 sentences) connecting to the issue's focus
- Each requested section, clearly headed
- One "worth sharing" pull-quote or highlight box
- A closing CTA (reply, share, or click)

Keep the voice consistent and personal throughout — avoid corporate press-release tone.
```

## 📥 Example Input
```
newsletter_name: The Growth Signal
topic_focus: AI tools for solo marketers
sections: Tool of the Week, Quick Tip, Reader Question
tone: casual, opinionated
```

## 📤 Example Output
```
**Subject:** The AI tool that replaced 3 of my subscriptions

Hey friend,

This week I went down a rabbit hole testing AI marketing tools...

## 🛠️ Tool of the Week
...
```

## 💡 Tips
- Keep a consistent recurring structure issue-to-issue for reader familiarity

## ✅ Best Practices
- Write in first person for a personal feel
- Keep sections short and scannable

## ⚠️ Common Mistakes
- Writing in a generic, impersonal press-release tone
- Changing structure every issue, confusing regular readers
