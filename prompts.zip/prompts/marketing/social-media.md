# Social Media Post Generator

> Create platform-native social posts from a single content idea.

## 📋 Description
Generates a batch of social media posts adapted to platform-specific norms and constraints.

## 🎯 Purpose
To quickly repurpose one idea into multiple platform-optimized posts.

## ✅ When to Use
- Promoting a blog post or product launch across channels
- Building a week's worth of social content

## 🔧 Variables
| Variable | Description |
|---|---|
| `topic` | Core message or content to promote |
| `platforms` | List of platforms, e.g. Twitter/X, LinkedIn, Instagram |
| `cta` | Desired call to action |

## 💬 Prompt

```
You are a social media strategist. Create platform-native posts for the following topic.

Topic: {topic}
Platforms: {platforms}
Call to action: {cta}

For each platform, follow its norms:
- Twitter/X: under 280 characters, punchy, 1-2 relevant hashtags
- LinkedIn: professional tone, 3-5 short paragraphs, no more than 3 hashtags
- Instagram: caption with a hook first line, line breaks for readability, 5-10 hashtags at the end
- Facebook: conversational, 2-3 sentences, question to drive engagement

Include the CTA naturally in each post. Do not reuse identical wording across platforms.
```

## 📥 Example Input
```
topic: launching a new productivity app
platforms: Twitter/X, LinkedIn
cta: sign up for early access
```

## 📤 Example Output
```
**Twitter/X:** We built the productivity app we wished existed. Early access is open 👇 [link] #ProductivityApp

**LinkedIn:** After 8 months of building, we're opening early access to our new productivity app...
```

## 💡 Tips
- Ask for 2-3 variations per platform for A/B testing

## ✅ Best Practices
- Match tone and length norms per platform
- Always end with a single clear CTA

## ⚠️ Common Mistakes
- Copy-pasting the same post across all platforms
- Overusing hashtags on LinkedIn
