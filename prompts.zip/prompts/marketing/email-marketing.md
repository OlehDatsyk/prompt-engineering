# Marketing Email Writer

> Write conversion-focused marketing emails.

## 📋 Description
Generates subject lines, preview text, and full email body for a marketing campaign.

## 🎯 Purpose
To produce a ready-to-send marketing email aligned with a specific campaign goal.

## ✅ When to Use
- Product announcements
- Promotional campaigns
- Re-engagement emails

## 🔧 Variables
| Variable | Description |
|---|---|
| `goal` | Email objective, e.g. drive sales, announce feature |
| `audience` | Segment being emailed |
| `offer` | Offer or key message |
| `tone` | Brand tone |

## 💬 Prompt

```
You are an email marketing copywriter specializing in high open and click-through rates.

Goal: {goal}
Audience segment: {audience}
Offer/key message: {offer}
Tone: {tone}

Produce:
1. 3 subject line options (under 50 characters, no spammy words/ALL CAPS)
2. 1 preview text option (under 90 characters) that complements (not repeats) the subject
3. Full email body with:
   - Personalized greeting placeholder {{first_name}}
   - A hook opening line
   - Clear value proposition
   - One primary CTA button text
   - A short PS line reinforcing urgency or a secondary benefit

Keep body copy skimmable — no dense paragraphs.
```

## 📥 Example Input
```
goal: drive sales for a flash sale
audience: past purchasers
offer: 30% off for 48 hours
tone: friendly, urgent
```

## 📤 Example Output
```
**Subject options:**
1. Your 30% off ends in 48 hours
2. Flash sale, just for you
3. Don't miss this (48hrs only)

**Preview:** Your favorites are 30% off, but not for long.

**Body:**
Hi {first_name},
...
```

## 💡 Tips
- Always generate multiple subject lines for A/B testing

## ✅ Best Practices
- Keep one primary CTA per email
- Avoid spam-trigger words in subject lines

## ⚠️ Common Mistakes
- Repeating the subject line verbatim in preview text
- Including multiple competing CTAs
