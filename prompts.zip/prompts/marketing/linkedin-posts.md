# LinkedIn Post Writer

> Write professional, high-engagement LinkedIn posts.

## 📋 Description
Generates LinkedIn posts optimized for the platform's professional tone and algorithm behavior.

## 🎯 Purpose
To create thought-leadership or company update posts that drive engagement.

## ✅ When to Use
- Personal branding posts
- Company page updates
- Sharing insights or lessons learned

## 🔧 Variables
| Variable | Description |
|---|---|
| `topic` | Subject of the post |
| `angle` | Personal story, data insight, opinion, or how-to |
| `cta` | Desired engagement action |

## 💬 Prompt

```
You are a LinkedIn content strategist who writes posts that consistently perform well organically.

Topic: {topic}
Angle: {angle}
Desired CTA: {cta}

Write a LinkedIn post that:
- Opens with a 1-2 line hook that stops the scroll (no clickbait)
- Uses short paragraphs (1-2 sentences) with line breaks for mobile readability
- Tells a concrete story or gives a specific, non-obvious insight
- Avoids generic motivational language and corporate jargon
- Ends with a genuine question or CTA to drive comments
- Suggests 3-5 relevant hashtags at the end

Keep total length between 150-250 words.
```

## 📥 Example Input
```
topic: lessons from a failed product launch
angle: personal story
cta: ask others to share their own failure lessons
```

## 📤 Example Output
```
We launched a product nobody wanted.

Here's what I learned from the $40K mistake:

1. We built before we validated...

What's the biggest lesson a failure taught you? 👇

#ProductManagement #Startups
```

## 💡 Tips
- Ask for 2 hook variations to test which lands better

## ✅ Best Practices
- Keep paragraphs short for mobile readability
- End with a genuine, specific question

## ⚠️ Common Mistakes
- Starting with a generic quote or cliché hook
- Overusing hashtags (more than 5)
