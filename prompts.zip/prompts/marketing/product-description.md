# Product Description Writer

> Write persuasive, benefit-driven product descriptions.

## 📋 Description
Generates e-commerce product descriptions that balance features, benefits, and SEO.

## 🎯 Purpose
To produce descriptions that convert browsers into buyers.

## ✅ When to Use
- Adding new products to an online store
- Refreshing underperforming product pages

## 🔧 Variables
| Variable | Description |
|---|---|
| `product_name` | Name of the product |
| `features` | List of key features/specs |
| `target_customer` | Who the product is for |
| `keywords` | SEO keywords to include |

## 💬 Prompt

```
You are an e-commerce copywriter. Write a product description that sells benefits, not just features.

Product: {product_name}
Features/specs: {features}
Target customer: {target_customer}
SEO keywords: {keywords}

Structure:
1. A short, punchy headline (not the product name)
2. 2-3 sentence opening that speaks to the customer's need or desire
3. Bullet list translating each feature into a benefit
4. A short closing line addressing a common hesitation (e.g. sizing, durability)

Naturally include SEO keywords without keyword stuffing. Keep total length under 150 words.
```

## 📥 Example Input
```
product_name: TrailPro Hiking Backpack
features: 40L capacity, waterproof, adjustable straps
target_customer: weekend hikers
keywords: waterproof hiking backpack
```

## 📤 Example Output
```
**Built for the Trail, Ready for Anything**

When the weather turns, your gear shouldn't fail you...

- 40L capacity — pack for multi-day trips without overpacking
- Fully waterproof — because forecasts lie
...
```

## 💡 Tips
- Ask for feature-to-benefit bullets explicitly, not just feature lists

## ✅ Best Practices
- Lead with the customer's need, not the product name
- Address one common objection near the end

## ⚠️ Common Mistakes
- Listing specs without translating them into benefits
- Keyword stuffing the opening sentence
