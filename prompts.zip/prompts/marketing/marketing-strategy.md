# Marketing Strategy Outline Generator

> Draft a structured go-to-market or marketing strategy outline.

## 📋 Description
Produces a high-level strategic marketing plan aligned to business goals and budget.

## 🎯 Purpose
To create a strategic starting framework for planning marketing efforts.

## ✅ When to Use
- Planning a product launch
- Setting quarterly marketing direction

## 🔧 Variables
| Variable | Description |
|---|---|
| `business_goal` | Primary business objective |
| `product` | Product/service |
| `budget_level` | Rough budget tier, e.g. bootstrapped, moderate, well-funded |
| `timeframe` | Planning horizon, e.g. Q3 2026 |

## 💬 Prompt

```
You are a marketing strategist. Draft a strategic marketing plan outline.

Business goal: {business_goal}
Product: {product}
Budget level: {budget_level}
Timeframe: {timeframe}

Structure the plan with:
1. Strategic objective (SMART-style, one sentence)
2. Target audience summary
3. Core positioning statement
4. Channel strategy: recommended channels with rationale, appropriate to the stated budget level
5. Key initiatives (3-5), each with a goal and success metric
6. Suggested KPIs to track overall
7. Key risks/assumptions

Keep recommendations realistic for the stated budget level — do not recommend an enterprise multi-channel strategy for a bootstrapped budget.
```

## 📥 Example Input
```
business_goal: reach 1000 paying customers
product: B2B SaaS scheduling tool
budget_level: bootstrapped
timeframe: next 2 quarters
```

## 📤 Example Output
```
**Objective:** Acquire 1,000 paying customers within 2 quarters through low-cost, high-leverage channels.

**Channel Strategy:** Prioritize content SEO and community-led growth over paid acquisition given budget constraints...
```

## 💡 Tips
- Always state budget level explicitly to keep channel recommendations realistic

## ✅ Best Practices
- Tie every initiative to a measurable KPI
- Keep the plan honest about resource constraints

## ⚠️ Common Mistakes
- Recommending expensive channels regardless of stated budget
- Vague objectives without measurable targets
