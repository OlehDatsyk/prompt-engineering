# Blog Post Writer

> Generate SEO-friendly, well-structured blog posts on any topic.

## 📋 Description
A production-ready prompt for generating complete, publish-ready blog posts with proper structure, tone, and SEO awareness.

## 🎯 Purpose
To produce long-form blog content that is engaging, well-organized, and optimized for both readers and search engines.

## ✅ When to Use
- Drafting a new blog post from a topic or outline
- Repurposing research into article form
- Producing content at scale for a content calendar

## 🔧 Variables
| Variable | Description |
|---|---|
| `topic` | The subject of the blog post |
| `audience` | Target reader persona |
| `tone` | Voice, e.g. professional, casual, witty |
| `word_count` | Target length |
| `keywords` | Primary SEO keywords to include |

## 💬 Prompt

```
You are a professional content writer and SEO strategist with 10+ years of experience writing high-performing blog content.

Write a complete blog post on the topic: {topic}

Requirements:
- Target audience: {audience}
- Tone: {tone}
- Target length: {word_count} words
- Naturally incorporate these keywords: {keywords}
- Include an attention-grabbing title (H1)
- Use H2/H3 subheadings to structure the content logically
- Open with a hook that states the reader's problem or curiosity gap
- Include a short introduction, well-developed body sections, and a conclusion with a clear call to action
- Write in clear, scannable paragraphs (3-4 sentences max)
- Avoid generic filler phrases and clichés
- Do not fabricate statistics; if data is needed, mark it as [VERIFY: source needed]

Output the post in Markdown format, ready to publish.
```

## 📥 Example Input
```
topic: "Remote work productivity tips"
audience: startup employees
tone: friendly, practical
word_count: 900
keywords: remote work productivity, work from home tips
```

## 📤 Example Output
```
# 7 Remote Work Productivity Tips That Actually Work

Working from home sounds great — until your kitchen table becomes your office and Slack never stops buzzing...

## 1. Design a Dedicated Workspace
...

## Conclusion
Start with one habit this week and build from there.
```

## 💡 Tips
- Feed the model a rough outline first for tighter structure
- Ask for 3 title variations and pick the strongest
- Request a meta description separately for SEO

## ✅ Best Practices
- Always specify audience and tone explicitly
- Set explicit word count ranges, not exact numbers
- Ask the model to flag unverified claims

## ⚠️ Common Mistakes
- Leaving tone undefined, resulting in generic corporate voice
- Not specifying keyword placement, causing keyword stuffing
- Accepting fabricated statistics without verification
