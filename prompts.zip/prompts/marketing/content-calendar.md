# Content Calendar Planner

> Plan a structured multi-week content calendar.

## 📋 Description
Generates a themed content calendar with post topics, formats, and channels.

## 🎯 Purpose
To plan consistent content output aligned with business goals and themes.

## ✅ When to Use
- Planning monthly/quarterly content
- Aligning content with campaigns or product launches

## 🔧 Variables
| Variable | Description |
|---|---|
| `business_goal` | Primary goal, e.g. brand awareness, lead gen |
| `channels` | Channels to plan for |
| `duration` | Time period, e.g. 4 weeks |
| `themes` | Content themes or pillars |

## 💬 Prompt

```
You are a content strategist. Build a content calendar.

Business goal: {business_goal}
Channels: {channels}
Duration: {duration}
Content pillars/themes: {themes}

For each week, produce a table with columns: Day | Channel | Content Pillar | Topic/Idea | Format | CTA.
Balance content types (educational, promotional, engagement, behind-the-scenes) at roughly a 60/20/20 ratio.
Ensure no repeated topics within the period. End with a short rationale explaining the content mix.
```

## 📥 Example Input
```
business_goal: lead generation
channels: LinkedIn, email
duration: 2 weeks
themes: productivity, remote work culture
```

## 📤 Example Output
```
| Day | Channel | Pillar | Topic | Format | CTA |
|---|---|---|---|---|---|
| Mon Wk1 | LinkedIn | Productivity | 5 tools remote teams swear by | Carousel | Comment your favorite |
```

## 💡 Tips
- Specify a content pillar ratio if you have a strong opinion on mix

## ✅ Best Practices
- Balance promotional and value-driven content
- Avoid topic repetition within the period

## ⚠️ Common Mistakes
- Overloading the calendar with purely promotional posts
- Not aligning topics to stated business goal
