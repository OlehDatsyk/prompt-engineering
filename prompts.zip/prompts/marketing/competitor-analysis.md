# Competitor Analysis Framework

> Structure a competitive analysis for strategic positioning.

## 📋 Description
Produces a structured competitor comparison covering positioning, strengths, and gaps.

## 🎯 Purpose
To support positioning and differentiation strategy against named competitors.

## ✅ When to Use
- Evaluating competitive landscape before launch
- Refreshing positioning strategy

## 🔧 Variables
| Variable | Description |
|---|---|
| `your_product` | Your product/service |
| `competitors` | List of competitor names |
| `comparison_criteria` | Dimensions to compare, e.g. pricing, features, messaging |

## 💬 Prompt

```
You are a competitive strategy analyst. Build a competitor analysis.

Your product: {your_product}
Competitors: {competitors}
Comparison criteria: {comparison_criteria}

Produce:
1. A comparison table with competitors as rows and criteria as columns (use [VERIFY] for any factual claim you're not certain about, such as exact pricing)
2. For each competitor: 2-3 sentence summary of their positioning/messaging
3. A gap analysis: what none of the competitors are doing well
4. 3 differentiation opportunities for your product based on the gaps

Do not invent specific pricing, feature lists, or user numbers you cannot verify — mark them [VERIFY].
```

## 📥 Example Input
```
your_product: async standup tool for remote teams
competitors: Standuply, Geekbot
comparison_criteria: pricing, integrations, ease of use
```

## 📤 Example Output
```
| | Pricing | Integrations | Ease of Use |
|---|---|---|---|
| Standuply | [VERIFY] | Slack, Teams | Moderate |

**Gap Analysis:** Neither competitor offers deep analytics on team sentiment over time...
```

## 💡 Tips
- Follow up with real competitor research to fill in [VERIFY] tags

## ✅ Best Practices
- Mark unverifiable factual claims explicitly
- Focus the gap analysis on actionable differentiation

## ⚠️ Common Mistakes
- Presenting invented competitor data as fact
- Comparing on vanity criteria instead of buyer-relevant ones
