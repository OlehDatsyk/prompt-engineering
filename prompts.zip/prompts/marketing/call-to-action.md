# Call-to-Action Generator

> Generate high-converting CTA variations.

## 📋 Description
Produces multiple CTA options tailored to context, urgency, and audience.

## 🎯 Purpose
To generate strong, testable CTA copy for buttons, emails, and ads.

## ✅ When to Use
- Choosing button copy for a landing page
- A/B testing CTA variations

## 🔧 Variables
| Variable | Description |
|---|---|
| `action` | The action you want the user to take |
| `context` | Where the CTA appears, e.g. button, email footer |
| `tone` | Desired tone, e.g. urgent, friendly, minimal |

## 💬 Prompt

```
You are a conversion copywriter specializing in CTAs.

Desired action: {action}
Context: {context}
Tone: {tone}

Generate 8 CTA variations, grouped by approach:
- 2 direct/action-oriented (e.g. "Start Free Trial")
- 2 benefit-driven (e.g. "Get More Leads")
- 2 low-friction/soft (e.g. "See How It Works")
- 2 urgency-driven (e.g. "Claim Your Spot")

Keep each under 5 words where the context is a button. Avoid generic "Click Here" or "Submit".
```

## 📥 Example Input
```
action: sign up for a free trial
context: landing page hero button
tone: confident, friendly
```

## 📤 Example Output
```
**Direct:** Start Free Trial | Try It Free
**Benefit:** Get Organized Today | See Results Fast
**Soft:** See How It Works | Take a Quick Look
**Urgency:** Claim Your Spot | Start Before Spots Fill
```

## 💡 Tips
- Test across categories, not just wording tweaks of the same CTA

## ✅ Best Practices
- Keep button CTAs under 5 words
- Avoid generic verbs like 'Submit' or 'Click Here'

## ⚠️ Common Mistakes
- Generating 8 variants that are all the same category/angle
- Using vague CTAs that don't state the value
