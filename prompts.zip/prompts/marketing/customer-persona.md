# Customer Persona Builder

> Create a detailed, research-grounded buyer persona.

## 📋 Description
Generates a structured customer persona for use in marketing and product decisions.

## 🎯 Purpose
To create a shared reference for who the target customer is and what they need.

## ✅ When to Use
- Kicking off a new marketing campaign
- Aligning teams on target audience

## 🔧 Variables
| Variable | Description |
|---|---|
| `product` | Product/service |
| `known_customer_traits` | Known facts about actual customers, if any |
| `industry` | Industry context |

## 💬 Prompt

```
You are a customer research strategist. Build a buyer persona.

Product: {product}
Known customer traits/data (if any): {known_customer_traits}
Industry: {industry}

Produce a persona with:
1. Name and short archetype title (e.g. "Efficiency-Obsessed Emma")
2. Demographics (role, age range, company size if B2B)
3. Goals (what they're trying to achieve)
4. Pain points (specific, not generic)
5. Objections to purchasing
6. Where they discover new tools/content (channels)
7. A representative quote in their voice

If known_customer_traits is provided, ground the persona in that data rather than inventing demographics wholesale. If not provided, clearly label the persona as a hypothesis to validate.
```

## 📥 Example Input
```
product: invoicing software for freelancers
known_customer_traits: none yet
industry: freelance/gig economy
```

## 📤 Example Output
```
**Persona (Hypothesis — validate with real customer interviews): "Freelance Fiona"**
- Role: Independent graphic designer, 2-5 years freelancing
- Goal: Get paid faster, look professional to clients
...
```

## 💡 Tips
- Base personas on real interview data when available rather than pure assumption

## ✅ Best Practices
- Label assumption-based personas clearly as hypotheses
- Keep pain points specific and behavioral, not generic

## ⚠️ Common Mistakes
- Presenting an invented persona as validated research
- Making personas too broad to be actionable
