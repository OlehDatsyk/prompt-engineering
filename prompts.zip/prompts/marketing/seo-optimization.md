# SEO Content Optimizer

> Optimize existing content for search engine visibility.

## 📋 Description
Analyzes and rewrites content to improve on-page SEO while preserving readability and intent.

## 🎯 Purpose
To improve search ranking potential of existing content without sacrificing quality.

## ✅ When to Use
- Optimizing an existing article for a target keyword
- Auditing content before publishing
- Improving underperforming pages

## 🔧 Variables
| Variable | Description |
|---|---|
| `content` | The existing text to optimize |
| `target_keyword` | Primary keyword to rank for |
| `secondary_keywords` | Supporting keywords |

## 💬 Prompt

```
You are an SEO specialist. Analyze and optimize the following content for search engines while keeping it natural and reader-friendly.

Target keyword: {target_keyword}
Secondary keywords: {secondary_keywords}

Content:
{content}

Tasks:
1. Suggest an optimized title tag (under 60 characters)
2. Suggest a meta description (under 155 characters)
3. Rewrite headings to include target/secondary keywords naturally
4. Identify keyword density issues (over- or under-optimization)
5. Suggest 3 internal linking opportunities (topic areas, not fake URLs)
6. Rewrite the introduction to include the target keyword within the first 100 words
7. Provide a bullet list of specific SEO improvements made

Do not sacrifice readability for keyword placement.
```

## 📥 Example Input
```
content: [800-word article about coffee brewing]
target_keyword: best coffee brewing methods
secondary_keywords: pour over coffee, french press guide
```

## 📤 Example Output
```
**Title Tag:** Best Coffee Brewing Methods: A Complete 2026 Guide
**Meta Description:** Discover the best coffee brewing methods...

**Improvements:**
- Added target keyword to H1 and first paragraph
- Restructured H2s around brewing methods
...
```

## 💡 Tips
- Paste raw content, don't summarize it first
- Ask for a before/after keyword density comparison

## ✅ Best Practices
- Always keep primary keyword in title, H1, and intro
- Prioritize readability over keyword density

## ⚠️ Common Mistakes
- Over-optimizing and creating keyword stuffing
- Ignoring search intent behind the keyword
