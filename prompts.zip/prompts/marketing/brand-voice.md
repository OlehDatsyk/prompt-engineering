# Brand Voice Guide Generator

> Define and document a consistent brand voice.

## 📋 Description
Produces a structured brand voice guide with tone attributes, do's/don'ts, and example rewrites.

## 🎯 Purpose
To create a reference document ensuring consistent brand tone across all content.

## ✅ When to Use
- Onboarding new writers or agencies
- Standardizing tone across marketing channels

## 🔧 Variables
| Variable | Description |
|---|---|
| `brand_name` | Name of the brand |
| `brand_values` | Core brand values |
| `audience` | Target audience |
| `competitors` | Reference competitors for differentiation |

## 💬 Prompt

```
You are a brand strategist. Create a brand voice guide.

Brand: {brand_name}
Core values: {brand_values}
Audience: {audience}
Competitors to differentiate from: {competitors}

Produce:
1. 3-5 voice attributes (e.g. "witty, not silly") each with a one-line definition
2. A "We are / We are not" table (5 rows)
3. Vocabulary guidance: words to use, words to avoid
4. 3 example sentence rewrites: generic version → on-brand version
5. Guidance for tone shifts across channels (social vs. support vs. email)

Format as a clean reference document other writers can follow without further explanation.
```

## 📥 Example Input
```
brand_name: Fernweg Travel
brand_values: adventure, authenticity, sustainability
audience: millennial travelers
competitors: generic travel booking sites
```

## 📤 Example Output
```
## Voice Attributes
1. **Adventurous, not reckless** — inspire bold choices while being honest about risk.

## We Are / We Are Not
| We Are | We Are Not |
|---|---|
| Warm | Corporate |
```

## 💡 Tips
- Use real competitor examples to sharpen differentiation

## ✅ Best Practices
- Include concrete rewrite examples, not just abstract adjectives
- Address tone variation by channel

## ⚠️ Common Mistakes
- Using vague, interchangeable adjectives like 'friendly' with no definition
- Skipping example rewrites
