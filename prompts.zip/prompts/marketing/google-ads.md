# Google Ads Copy Generator

> Write RSA-ready headlines and descriptions for Google Ads.

## 📋 Description
Generates Responsive Search Ad headlines and descriptions that comply with Google's character limits.

## 🎯 Purpose
To produce a full set of Google Ads assets ready to paste into an RSA campaign.

## ✅ When to Use
- Setting up a new Google Search campaign
- Refreshing underperforming ad copy

## 🔧 Variables
| Variable | Description |
|---|---|
| `product` | Product or service |
| `keywords` | Primary keywords being targeted |
| `usp` | Unique selling proposition |
| `landing_page_focus` | What the landing page offers |

## 💬 Prompt

```
You are a Google Ads specialist. Generate Responsive Search Ad assets.

Product/service: {product}
Target keywords: {keywords}
USP: {usp}
Landing page focus: {landing_page_focus}

Generate:
- 15 headlines, each strictly under 30 characters
- 4 descriptions, each strictly under 90 characters
- Include at least 3 headlines with a keyword insertion
- Include at least 2 headlines with a number or specific claim
- Include at least 2 CTA-focused headlines (e.g. "Get Started Today")

Output as a numbered list with character counts shown next to each line.
```

## 📥 Example Input
```
product: project management software
keywords: project management tool, team collaboration software
usp: set up in under 5 minutes
landing_page_focus: free 14-day trial
```

## 📤 Example Output
```
1. Project Mgmt Tool (18)
2. Set Up In 5 Minutes (20)
3. Team Collaboration Made Easy (28)
...

Descriptions:
1. Manage projects and teams in one place. Start your free trial today. (71)
```

## 💡 Tips
- Always request character counts to catch overflow before pasting into Ads Manager

## ✅ Best Practices
- Vary headline angles: feature, benefit, urgency, proof
- Keep pinned headlines to a minimum for RSA flexibility

## ⚠️ Common Mistakes
- Writing headlines that exceed the 30-character limit
- Repeating the same angle across all headlines
