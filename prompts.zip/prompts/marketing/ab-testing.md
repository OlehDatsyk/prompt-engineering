# A/B Test Copy Variant Generator

> Generate structured, testable copy variants for A/B testing.

## 📋 Description
Produces copy variants designed to isolate a single testable variable.

## 🎯 Purpose
To create clean A/B test variants that produce meaningful, attributable results.

## ✅ When to Use
- Setting up a headline or CTA test
- Testing messaging angles

## 🔧 Variables
| Variable | Description |
|---|---|
| `original_copy` | The control/original copy |
| `element_to_test` | What specifically is being tested, e.g. headline angle, CTA wording |
| `hypothesis` | What you believe will improve performance and why |

## 💬 Prompt

```
You are a conversion rate optimization specialist. Create A/B test variants.

Original (control) copy: {original_copy}
Element being tested: {element_to_test}
Hypothesis: {hypothesis}

Generate:
1. Variant B that isolates ONLY the {element_to_test} — all other elements unchanged
2. A one-sentence explanation of what specifically changed and why, tied to the hypothesis
3. A suggested success metric to track (e.g. CTR, conversion rate)
4. A note on what NOT to change simultaneously, to keep the test valid

Do not change multiple variables at once — that invalidates the test.
```

## 📥 Example Input
```
original_copy: "Sign Up Free"
element_to_test: urgency framing
hypothesis: adding urgency will increase click-through rate
```

## 📤 Example Output
```
**Variant B:** "Start Free — Offer Ends Friday"
**What changed:** Added a time-bound urgency element to the CTA only; button size, color, and placement unchanged.
**Metric:** Click-through rate on CTA button.
```

## 💡 Tips
- Always test one variable at a time for clean attribution

## ✅ Best Practices
- Keep control and variant identical except for the tested element
- Define the success metric before launching the test

## ⚠️ Common Mistakes
- Changing multiple elements in one variant
- Not defining a clear success metric upfront
