# Sales Page Copywriter

> Write persuasive long-form sales copy.

## 📋 Description
Generates structured sales page copy following a proven persuasion framework (AIDA/PAS).

## 🎯 Purpose
To produce a complete sales page draft for a product or service launch.

## ✅ When to Use
- Launching a new offer
- Rewriting an underperforming sales page

## 🔧 Variables
| Variable | Description |
|---|---|
| `offer` | What is being sold |
| `audience` | Target buyer |
| `pain_points` | Key pains the offer solves |
| `price` | Price or pricing structure |

## 💬 Prompt

```
You are a direct-response copywriter. Write a sales page using the PAS (Problem-Agitate-Solve) framework.

Offer: {offer}
Audience: {audience}
Pain points: {pain_points}
Price: {price}

Structure:
1. Headline: speaks directly to the desired outcome
2. Problem: name the audience's pain point specifically
3. Agitate: describe the cost of not solving it
4. Solve: introduce the offer as the solution, list 3-5 key benefits
5. Social proof placeholder: [INSERT TESTIMONIAL]
6. Offer details and price framing (value stack)
7. Risk reversal (guarantee) placeholder
8. Final CTA with urgency

Write in persuasive but honest language — no false scarcity or exaggerated claims.
```

## 📥 Example Input
```
offer: online course on freelance writing
audience: aspiring freelance writers
pain_points: inconsistent income, no clients
price: $199 one-time
```

## 📤 Example Output
```
# Stop Chasing Clients. Start Choosing Them.

You didn't become a writer to spend more time pitching than writing...

## The Real Problem
...
```

## 💡 Tips
- Provide real testimonials afterward rather than letting the model invent them

## ✅ Best Practices
- Use a proven framework (PAS/AIDA) for structure
- Keep guarantee and urgency claims truthful

## ⚠️ Common Mistakes
- Letting the model fabricate testimonials or stats
- Overusing urgency/scarcity language
