# Landing Page Copy Generator

> Write full landing page copy blocks.

## 📋 Description
Generates section-by-section landing page copy: hero, features, social proof, FAQ, CTA.

## 🎯 Purpose
To produce ready-to-implement landing page copy aligned to a single conversion goal.

## ✅ When to Use
- Building a new landing page for a campaign
- Redesigning a low-converting page

## 🔧 Variables
| Variable | Description |
|---|---|
| `product` | Product/service being promoted |
| `primary_goal` | Single conversion goal, e.g. sign up, purchase |
| `audience` | Target visitor |
| `key_benefits` | Top 3 benefits to highlight |

## 💬 Prompt

```
You are a conversion copywriter. Write landing page copy focused on a single goal.

Product: {product}
Primary conversion goal: {primary_goal}
Audience: {audience}
Key benefits: {key_benefits}

Produce these sections:
1. Hero: headline + subheadline + primary CTA button text
2. Benefits section: 3 benefit blocks, each with a short title and 1-sentence description
3. How it works: 3-step process, one line each
4. Social proof section: placeholder structure for testimonials/logos
5. FAQ: 4 likely objections with concise answers
6. Final CTA section: headline + button text

Keep the page focused on one CTA repeated throughout. No competing calls to action.
```

## 📥 Example Input
```
product: budgeting app
primary_goal: free sign up
audience: young professionals
key_benefits: automatic tracking, savings goals, bank-level security
```

## 📤 Example Output
```
**Hero**
Headline: Budgeting That Runs Itself
Subheadline: Track spending and hit savings goals automatically.
CTA: Start Free

**Benefits**
1. Automatic Tracking — ...
```

## 💡 Tips
- Keep every section pointing to the same single CTA

## ✅ Best Practices
- One primary goal per landing page
- Address objections explicitly in an FAQ section

## ⚠️ Common Mistakes
- Mixing multiple CTAs (sign up, download, contact us)
- Writing vague benefit statements without specifics
