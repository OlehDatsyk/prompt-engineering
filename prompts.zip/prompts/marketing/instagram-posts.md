# Instagram Caption Generator

> Write scroll-stopping Instagram captions.

## 📋 Description
Generates Instagram captions with hooks, storytelling, and hashtag strategy.

## 🎯 Purpose
To produce engaging captions that complement visual content and drive interaction.

## ✅ When to Use
- Product photo posts
- Behind-the-scenes content
- Reels captions

## 🔧 Variables
| Variable | Description |
|---|---|
| `subject` | What the image/video shows |
| `brand_voice` | Brand tone descriptor |
| `cta` | Desired action, e.g. comment, shop link in bio |

## 💬 Prompt

```
You are an Instagram content strategist. Write a caption for the following post.

Subject of the visual: {subject}
Brand voice: {brand_voice}
CTA: {cta}

Requirements:
- First line must work as a standalone hook (shown before "more")
- Use short lines with line breaks for readability
- Match the specified brand voice exactly
- Include the CTA naturally, not as an afterthought
- Add a block of 8-12 relevant hashtags at the end, mixing broad and niche tags
- Keep total caption under 150 words excluding hashtags
```

## 📥 Example Input
```
subject: new sneaker product shot
brand_voice: bold, energetic, Gen-Z friendly
cta: shop the link in bio
```

## 📤 Example Output
```
These aren't just sneakers. They're a statement. 🔥

Drop day is here.
Link in bio — link in bio — link in bio.

#Sneakers #NewDrop #StreetStyle ...
```

## 💡 Tips
- Request 3 hook variations for the first line specifically

## ✅ Best Practices
- Front-load the hook since Instagram truncates captions
- Mix broad and niche hashtags

## ⚠️ Common Mistakes
- Burying the CTA at the very end without emphasis
- Using only broad, high-competition hashtags
