# Structured Output Extraction Prompt

> A developer prompt for reliable structured data extraction from unstructured text.

## Prompt

```
Extract structured information from the following text.

Text:
{input_text}

Return ONLY valid JSON matching this schema (no markdown, no explanation, no code fences):
{json_schema}

Rules:
- If a field's value is not present in the text, use null — do not omit the key or invent a value
- For array fields with no items found, return an empty array, not null
- Preserve exact values from the text (names, numbers, dates) — do not reformat or normalize unless the schema specifies a format
```

## When to Use
- Building data extraction pipelines from documents, emails, or user input
- Any integration requiring reliably parseable output

## Tips
- Prefer your API provider's native structured output/tool-calling feature over prompt-only JSON when available — it's more reliable
- Always test with edge cases: empty input, partial matches, and text containing no relevant data at all
