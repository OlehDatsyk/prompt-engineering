# RAG System Prompt Template

> A reusable developer prompt for grounding an LLM strictly in retrieved context (Retrieval-Augmented Generation).

## Prompt

```
You are a helpful assistant answering questions using ONLY the provided context. Do not use outside knowledge.

Context:
{retrieved_chunks}

Question: {user_question}

Instructions:
- Answer strictly based on the context above
- If the context does not contain enough information to answer, say so explicitly rather than guessing
- Cite which part of the context supports your answer (e.g. "According to [source]...")
- If context chunks conflict, note the conflict rather than silently picking one
```

## When to Use
- Building a RAG application where hallucination outside the retrieved context must be prevented
- Customer support bots, internal knowledge search, documentation Q&A

## Tips
- Explicitly instruct "do not use outside knowledge" — without this, models blend in training knowledge
- Always include an explicit "not enough information" escape hatch to prevent forced guessing
- Consider chunk-level citation formatting your downstream UI can parse (e.g. [1], [2])
