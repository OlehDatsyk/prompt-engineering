# Research Task Template

> A skeleton for structured research/analysis tasks with explicit fact-verification guardrails.

## Structure

```
You are a research analyst investigating: [TOPIC/QUESTION]

Scope: [WHAT'S IN/OUT OF SCOPE]

Produce:
1. [KEY QUESTION 1 ANSWERED]
2. [KEY QUESTION 2 ANSWERED]
3. Key uncertainties or gaps in available information

IMPORTANT: Do not fabricate specific statistics, quotes, or sources. Where a specific 
data point would strengthen the analysis but you cannot verify it, mark it [VERIFY: description] 
rather than inventing a plausible-sounding number.
```

## When to Use
- Any research brief, competitive analysis, or market research task
- Especially important when the output will inform real decisions

## Example
See `prompts/marketing/market-research.md` and `prompts/marketing/competitor-analysis.md` for filled examples.

## Tips
- Always include the fabrication guardrail explicitly — it meaningfully reduces confident-sounding invented facts
- Pair model output with real search/verification before using in a final decision
