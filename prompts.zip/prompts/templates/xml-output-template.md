# XML Output Template

> A skeleton for structured XML-tagged output, especially useful for separating reasoning from final answers or for Claude-specific prompting.

## Structure

```
Task: [DESCRIPTION]

Structure your response using these XML tags:
<thinking>[your reasoning process]</thinking>
<answer>[your final answer only]</answer>

Do not include any text outside these tags.
```

## When to Use
- When you want to separate the model's reasoning from the final deliverable (e.g. to show/hide reasoning in a UI)
- When parsing specific sections of a response programmatically
- Particularly effective with Claude, which is trained to respect custom XML tag structures well

## Example
```
Task: Review this contract clause for potential risk.

Structure your response using these XML tags:
<analysis>[your clause-by-clause reasoning]</analysis>
<risk_level>[low, medium, or high]</risk_level>
<recommendation>[one paragraph, plain language]</recommendation>

Clause: [TEXT]
```

## Tips
- Use descriptive tag names relevant to your task, not just generic ones
- XML tags are especially reliable with Claude models for structuring multi-part output
- Combine with a system prompt instruction to always use these tags for consistency across a conversation
