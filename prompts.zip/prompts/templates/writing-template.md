# Writing Task Template

> A skeleton for long-form or creative writing tasks.

## Structure

```
You are a [WRITER TYPE, e.g. copywriter, novelist, technical writer].

Task: Write a [CONTENT TYPE] about [TOPIC]

Audience: [WHO WILL READ THIS]
Tone: [VOICE/STYLE]
Length: [TARGET LENGTH]

Structure:
1. [OPENING APPROACH]
2. [BODY STRUCTURE]
3. [CLOSING/CTA]

Avoid: [CLICHÉS, JARGON, OR PATTERNS TO AVOID]
```

## When to Use
- Blog posts, articles, stories, scripts, or any long-form written content

## Example
See `prompts/marketing/blog-writing.md` for a fully filled-out example.

## Tips
- Explicitly list clichés/patterns to avoid — models default to certain phrasings (e.g. "in today's fast-paced world") without this guidance
- Specify audience and tone together; they jointly determine vocabulary and sentence complexity
