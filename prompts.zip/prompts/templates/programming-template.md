# Programming Task Template

> A skeleton for well-specified coding tasks (see also the full `prompts/programming/` library for language-specific versions).

## Structure

```
You are a senior [LANGUAGE/FRAMEWORK] engineer.

Task: [WHAT THE CODE SHOULD DO]
Constraints: [LANGUAGE VERSION, ALLOWED/FORBIDDEN LIBRARIES, STYLE GUIDE]

Requirements:
- [FUNCTIONAL REQUIREMENT]
- Include type hints/annotations
- Include error handling for [SPECIFIC EDGE CASES]
- Include a short usage example

Output only the code, followed by a brief explanation of key design decisions.
```

## When to Use
- As a base template for any code-generation prompt across languages

## Example
See any file in `prompts/programming/` for a fully filled-out example (e.g. `python.md`, `react.md`).

## Tips
- Always specify language/framework version — syntax and available features vary significantly
- Explicitly request edge case handling; models default to happy-path-only code otherwise
