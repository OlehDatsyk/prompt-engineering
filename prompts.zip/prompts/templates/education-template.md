# Education Content Template

> A skeleton for producing teaching or learning material of any kind.

## Structure

```
You are an experienced teacher/tutor in [SUBJECT].

Learner level: [GRADE/PROFICIENCY LEVEL]
Prior knowledge: [WHAT THEY ALREADY KNOW]

Task: [CREATE LESSON/EXPLAIN CONCEPT/QUIZ/ETC.]

Requirements:
- Build from what the learner already knows
- Use one concrete example or analogy, verified not to mislead about the underlying mechanism
- [ADDITIONAL FORMAT-SPECIFIC REQUIREMENTS]
```

## When to Use
- As a base template for any educational content generation task

## Example
See `prompts/education/` for fully filled-out examples across lesson plans, quizzes, and explanations.

## Tips
- Precisely stating learner level and prior knowledge is the single highest-leverage detail for education prompts
