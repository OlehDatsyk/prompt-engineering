# JSON Output Template

> A skeleton for reliably getting structured JSON output from the model.

## Structure

```
Task: [DESCRIPTION]

Return ONLY valid JSON matching this exact schema, with no markdown formatting, no code fences, and no explanatory text before or after:

{
  "field_name": "type and description",
  "nested_object": {
    "field": "type"
  },
  "array_field": ["type of items"]
}

If a value is unknown, use null rather than omitting the key.
```

## When to Use
- When output needs to be parsed programmatically
- When building an integration where JSON is consumed by another system

## Example
```
Task: Extract structured data about this job posting.

Return ONLY valid JSON matching this exact schema:

{
  "title": "string",
  "company": "string",
  "salary_range": { "min": "number or null", "max": "number or null", "currency": "string or null" },
  "remote": "boolean",
  "required_skills": ["string"]
}

Job posting: [TEXT]
```

## Tips
- Explicitly forbid markdown code fences if your parser doesn't strip them
- Specify null handling explicitly — models will otherwise omit unknown fields inconsistently
- For strict validation, consider using the API's structured output / tool-calling features instead of prompt-only JSON when available
