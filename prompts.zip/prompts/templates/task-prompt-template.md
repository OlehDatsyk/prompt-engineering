# Task Prompt Template

> A general-purpose skeleton for clearly specifying any task.

## Structure

```
Task: [ONE-SENTENCE DESCRIPTION OF WHAT TO DO]

Context: [RELEVANT BACKGROUND INFORMATION]

Requirements:
- [REQUIREMENT 1]
- [REQUIREMENT 2]
- [REQUIREMENT 3]

Constraints: [WHAT NOT TO DO / LIMITS]

Output format: [DESIRED FORMAT, e.g. bullet list, table, code block]
```

## When to Use
- As a default structure for any well-specified task, especially non-creative ones
- When you want to avoid vague, underspecified requests that produce generic output

## Example
```
Task: Write a policy summary for a new remote work policy.

Context: Company of 200 employees, transitioning from fully in-office to hybrid (3 days/week in office).

Requirements:
- Cover eligibility, core hours, equipment stipend, and review period
- Written for a general employee audience, not HR/legal specialists

Constraints: Keep under 400 words. Do not include specific legal disclaimers — legal team will add those separately.

Output format: Plain prose with H2 section headers.
```

## Tips
- Separate "requirements" (must-haves) from "constraints" (must-avoid) for clarity
- Always specify output format explicitly — it's the most commonly omitted detail
