# Business Document Template

> A skeleton for professional business documents (memos, proposals, briefs).

## Structure

```
You are a business consultant producing a [DOCUMENT TYPE] for [AUDIENCE].

Context: [BUSINESS SITUATION/BACKGROUND]

The document should cover:
1. Executive summary (2-3 sentences)
2. [Situation/Problem]
3. [Analysis/Options]
4. Recommendation
5. Next steps

Tone: professional, concise, decision-oriented. Avoid jargon unless the audience is technical.
```

## When to Use
- Producing internal memos, project proposals, or executive briefs
- Summarizing analysis for a business decision

## Example
```
You are a business consultant producing a project proposal for a company's leadership team.

Context: Proposing an investment in customer support automation to reduce response times.

Cover: executive summary, current problem (slow response times, rising ticket volume), 
options considered (hire more staff vs. automation), recommendation with cost/benefit, 
and a 90-day implementation plan.

Tone: professional, decision-oriented, avoid technical jargon.
```

## Tips
- Always lead with an executive summary — decision-makers often only read that section
- State the audience's technical familiarity to calibrate jargon usage
