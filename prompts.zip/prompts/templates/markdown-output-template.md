# Markdown Output Template

> A skeleton for consistently formatted Markdown output.

## Structure

```
Task: [DESCRIPTION]

Format the output as Markdown with:
- A single H1 title
- H2 section headers for [LIST MAIN SECTIONS]
- [Tables/bullet lists/code blocks] where [CONDITION]
- No more than [N] levels of heading nesting
```

## When to Use
- Generating documentation, reports, or content meant for direct rendering
- When consistent structure across multiple generations matters (e.g. batch content generation)

## Example
```
Task: Write a setup guide for a new open-source CLI tool.

Format as Markdown with:
- A single H1 title
- H2 sections: Installation, Usage, Configuration, Troubleshooting
- Code blocks for all commands and config examples
- A table for the Configuration options section
```

## Tips
- Specify heading levels explicitly to keep nested structure predictable across a batch
- Ask for tables specifically where tabular data belongs, or the model may default to bullet lists
