# Excel Dashboard Design Guide

> Design a clean, functional Excel dashboard layout.

## 📋 Description
A prompt for structuring an Excel dashboard that clearly communicates key metrics.

## 🎯 Purpose
To design dashboards that are readable, focused, and update reliably from underlying data.

## ✅ When to Use
- Building a reporting dashboard
- Redesigning a cluttered existing dashboard

## 🔧 Variables
| Variable | Description |
|---|---|
| `metrics` | Key metrics/KPIs to display |
| `audience` | Who will use the dashboard |
| `update_frequency` | How often data refreshes |

## 💬 Prompt

```
You are a dashboard design expert. Design an Excel dashboard.

Metrics/KPIs to display: {metrics}
Audience: {audience}
Update frequency: {update_frequency}

Provide:
1. Layout recommendation (top-left = most important metric, logical grouping of related KPIs)
2. Chart/visual type recommended for each metric, with reasoning
3. Which metrics should be a single headline number (KPI card) vs. a trend chart vs. a table
4. How to structure underlying data so the dashboard auto-updates cleanly (e.g. separate raw data / calculation / display tabs)
5. Formatting guidance: consistent color coding for good/bad performance, minimal chart clutter, no more than 5-7 visuals per screen

Prioritize clarity for the stated audience over visual complexity.
```

## 📥 Example Input
```
metrics: monthly revenue, customer churn rate, top 5 products by sales, revenue trend
audience: executive team, glance-and-go
update_frequency: monthly
```

## 📤 Example Output
```
**Layout:** Top row = 3 KPI cards (Revenue, Churn, New Customers). Below: revenue trend line chart (left), top 5 products bar chart (right).

**Structure:** Raw Data tab (never touched manually) → Calculations tab (pivot/formulas) → Dashboard tab (charts referencing Calculations only).
```

## 💡 Tips
- Specify the audience's technical sophistication — executives want fewer, bigger-picture visuals

## ✅ Best Practices
- Separate raw data, calculations, and display into different tabs
- Limit to 5-7 visuals per dashboard screen to avoid clutter

## ⚠️ Common Mistakes
- Building charts directly off raw data, making the dashboard fragile to data changes
- Overloading a single screen with too many visuals
