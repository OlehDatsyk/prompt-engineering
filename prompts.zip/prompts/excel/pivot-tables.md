# Pivot Table Setup Guide

> Get step-by-step guidance for building a specific Pivot Table.

## 📋 Description
A prompt for producing precise pivot table configuration instructions.

## 🎯 Purpose
To quickly configure a pivot table for a specific analysis need without guesswork.

## ✅ When to Use
- Building a new pivot table for analysis
- Unsure which fields go in which pivot area

## 🔧 Variables
| Variable | Description |
|---|---|
| `data_columns` | Column headers in the source data |
| `analysis_goal` | What insight you want from the pivot table |

## 💬 Prompt

```
You are an Excel expert. Design a Pivot Table configuration.

Source data columns: {data_columns}
Analysis goal: {analysis_goal}

Provide:
1. Which field(s) go in Rows, Columns, Values, and Filters
2. The aggregation type to use for each Values field (Sum, Average, Count, etc.) and why
3. Any calculated field needed, with its formula
4. Step-by-step setup instructions (Insert > PivotTable > ...)
5. A suggestion for a useful sort or filter to apply once built

Keep the design as simple as possible while fully answering the analysis goal — don't over-complicate with unnecessary fields.
```

## 📥 Example Input
```
data_columns: Date, Region, Product, Salesperson, Units Sold, Revenue
analysis_goal: total revenue by region and product, see top performing combinations
```

## 📤 Example Output
```
**Rows:** Region, then Product (nested)
**Values:** Sum of Revenue
**Setup:** Insert > PivotTable > select data range > drag Region and Product to Rows, Revenue to Values (set to Sum)
**Tip:** Sort descending by Revenue to surface top combinations at a glance.
```

## 💡 Tips
- List all available columns so the model can pick the truly relevant ones, not guess

## ✅ Best Practices
- Keep the pivot design minimal and focused on the stated goal
- Specify correct aggregation type per field

## ⚠️ Common Mistakes
- Using Count instead of Sum (or vice versa) inappropriately
- Overloading the pivot with unnecessary fields
