# Excel Formula Generator

> Generate the correct Excel formula for a described task.

## 📋 Description
A prompt for producing accurate, efficient Excel formulas with explanation.

## 🎯 Purpose
To quickly get a working formula for a specific spreadsheet task.

## ✅ When to Use
- Building a calculation you're not sure how to formula-ize
- Debugging an existing formula

## 🔧 Variables
| Variable | Description |
|---|---|
| `task` | What the formula should calculate |
| `cell_layout` | Relevant cell/column references |
| `excel_version` | Excel version, e.g. Microsoft 365, Excel 2019 |

## 💬 Prompt

```
You are an Excel expert. Write a formula for the following task.

Task: {task}
Cell/column layout: {cell_layout}
Excel version: {excel_version}

Requirements:
- Provide the exact formula, ready to paste
- Use functions compatible with the stated Excel version (flag if a function requires 365/newer)
- Explain what each part of the formula does in plain language
- Note any edge cases the formula doesn't handle (e.g. blank cells, text in numeric columns)
- If there's a simpler alternative approach (e.g. a newer dynamic array function), mention it
```

## 📥 Example Input
```
task: sum sales for 'North' region only
cell_layout: Region in column B, Sales in column D, data rows 2-500
excel_version: Microsoft 365
```

## 📤 Example Output
```
```
=SUMIF(B2:B500, "North", D2:D500)
```
**Explanation:** Sums values in D2:D500 where the corresponding cell in B2:B500 equals "North".
**Edge case:** Case-insensitive match; if region names have inconsistent spacing, results may be inaccurate — consider TRIM().
```

## 💡 Tips
- Specify Excel version to avoid recommending functions unavailable to you (e.g. XLOOKUP, dynamic arrays)

## ✅ Best Practices
- Always check version compatibility for newer functions
- Note edge cases the formula doesn't handle

## ⚠️ Common Mistakes
- Recommending 365-only functions to a user on an older Excel version
- Not accounting for blank cells or text-formatted numbers
