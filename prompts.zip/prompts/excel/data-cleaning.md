# Excel Data Cleaning Checklist

> Generate a step-by-step data cleaning plan for messy spreadsheet data.

## 📋 Description
A prompt for producing a systematic Excel data cleaning process tailored to specific data issues.

## 🎯 Purpose
To methodically clean messy data rather than ad-hoc fixing.

## ✅ When to Use
- Preparing raw/messy data for analysis
- Standardizing imported data

## 🔧 Variables
| Variable | Description |
|---|---|
| `data_issues` | Known issues in the data, e.g. duplicates, inconsistent formats |
| `columns` | Relevant column names |

## 💬 Prompt

```
You are a data quality expert working in Excel. Create a cleaning plan.

Known issues: {data_issues}
Columns involved: {columns}

Provide, in order:
1. A numbered cleaning checklist (e.g. trim whitespace, standardize case, remove duplicates, fix date formats)
2. For each step, the specific Excel feature/formula to use (e.g. TRIM(), Remove Duplicates, Text to Columns)
3. Order steps so earlier steps don't get undone by later ones
4. A validation step at the end to confirm cleaning worked (e.g. COUNTIF check for remaining duplicates)
5. A note on what to do with rows that can't be automatically cleaned (flag for manual review, don't silently drop)
```

## 📥 Example Input
```
data_issues: duplicate customer rows, inconsistent phone number formats, trailing whitespace in names
columns: CustomerID, Name, Phone
```

## 📤 Example Output
```
1. Trim whitespace: apply `=TRIM(A2)` across Name column, paste as values
2. Standardize phone format: use Text to Columns or a formula to strip non-digits
3. Remove Duplicates: Data > Remove Duplicates on CustomerID
4. Validate: `=COUNTIF(A:A, A2)>1` to confirm no duplicates remain
```

## 💡 Tips
- List all known data issues upfront so the plan addresses each specifically

## ✅ Best Practices
- Order cleaning steps to avoid undoing earlier fixes
- Flag unfixable rows for manual review rather than silently dropping them

## ⚠️ Common Mistakes
- Removing duplicates before standardizing formats, missing near-duplicates
- Silently deleting rows that don't fit expected patterns
