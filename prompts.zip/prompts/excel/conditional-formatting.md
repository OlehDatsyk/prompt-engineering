# Conditional Formatting Rule Designer

> Design conditional formatting rules for visual data highlighting.

## 📋 Description
A prompt for producing precise conditional formatting rules and formulas.

## 🎯 Purpose
To highlight important data patterns visually and reliably.

## ✅ When to Use
- Highlighting outliers or exceptions in data
- Building visual status indicators (e.g. red/yellow/green)

## 🔧 Variables
| Variable | Description |
|---|---|
| `goal` | What should be visually highlighted |
| `range` | The cell range the rule applies to |
| `condition_logic` | The specific condition/threshold logic |

## 💬 Prompt

```
You are an Excel expert. Design conditional formatting rules.

Goal: {goal}
Range: {range}
Condition logic: {condition_logic}

Provide:
1. The exact formula to use for a "Use a formula to determine which cells to format" rule (if formula-based logic is needed)
2. Step-by-step setup instructions (Home > Conditional Formatting > ...)
3. Suggested formatting style for each condition (color, icon, etc.) with color choices that remain distinguishable for colorblind users
4. Correct absolute/relative cell reference usage in the formula (critical — a common source of errors)
5. A note on rule order/precedence if multiple rules could apply to the same cells
```

## 📥 Example Input
```
goal: highlight rows where inventory is below reorder threshold
range: A2:E500
condition_logic: highlight if Quantity (column C) < Reorder Point (column D)
```

## 📤 Example Output
```
**Formula:** `=$C2<$D2` applied to range A2:E500 (note: column locked with $, row relative so it evaluates per-row)
**Setup:** Select A2:E500 > Conditional Formatting > New Rule > Use a formula > paste formula > choose red fill
**Colorblind note:** Pair red fill with a bold icon/border, not color alone.
```

## 💡 Tips
- State whether the highlight should apply to the whole row or just one cell — this determines reference locking

## ✅ Best Practices
- Lock column references appropriately for whole-row highlighting formulas
- Don't rely on color alone; pair with icons/patterns for accessibility

## ⚠️ Common Mistakes
- Incorrect $ reference locking, causing the rule to misapply across rows/columns
- Overlapping rules with unclear precedence causing unexpected formatting
