# Excel Automation (Macro/VBA) Assistant

> Generate a VBA macro to automate a repetitive Excel task.

## 📋 Description
A prompt for producing working VBA code for task automation.

## 🎯 Purpose
To automate repetitive spreadsheet tasks reliably.

## ✅ When to Use
- Automating a repetitive manual process
- Building a reusable macro for a recurring report

## 🔧 Variables
| Variable | Description |
|---|---|
| `task` | What the macro should automate |
| `trigger` | How the macro should be run, e.g. button click, on open |
| `scope` | Which sheets/ranges are affected |

## 💬 Prompt

```
You are a VBA expert. Write a macro to automate the following task.

Task: {task}
Trigger: {trigger}
Scope: {scope}

Requirements:
- Include error handling (On Error) so the macro fails gracefully with a clear message, not a cryptic runtime error
- Avoid hardcoding cell ranges where possible; use named ranges or dynamic range detection (e.g. last used row)
- Add inline comments explaining each major step
- Include a confirmation message box at the end if the macro modifies data
- State any settings the user needs to enable (e.g. enabling macros, trusting the workbook location)

Output the full VBA code in a code block, followed by setup instructions.
```

## 📥 Example Input
```
task: copy new rows from 'Input' sheet to 'Archive' sheet and clear Input
trigger: button click
scope: Input!A2:D(last row), Archive sheet append
```

## 📤 Example Output
```
```vba
Sub ArchiveRows()
    On Error GoTo ErrHandler
    Dim lastRow As Long
    lastRow = Sheets("Input").Cells(Sheets("Input").Rows.Count, "A").End(xlUp).Row
    ...
    MsgBox "Rows archived successfully."
    Exit Sub
ErrHandler:
    MsgBox "Error: " & Err.Description
End Sub
```
```

## 💡 Tips
- Specify the trigger mechanism — button, worksheet event, or manual run — since setup differs

## ✅ Best Practices
- Always include error handling for graceful failure
- Avoid hardcoded ranges; detect data extent dynamically

## ⚠️ Common Mistakes
- Hardcoding fixed row/column ranges that break when data size changes
- Missing error handling, causing cryptic crashes for end users
