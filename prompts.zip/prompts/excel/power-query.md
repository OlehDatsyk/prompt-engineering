# Power Query Transformation Steps

> Design Power Query steps to clean/transform data.

## 📋 Description
A prompt for producing a precise Power Query (M) transformation sequence.

## 🎯 Purpose
To automate repeatable data cleaning/transformation via Power Query.

## ✅ When to Use
- Cleaning messy imported data repeatedly
- Combining/transforming multiple data sources

## 🔧 Variables
| Variable | Description |
|---|---|
| `source_description` | Description of the source data and its issues |
| `desired_output` | What the cleaned/transformed data should look like |

## 💬 Prompt

```
You are a Power Query expert. Design a transformation sequence.

Source data: {source_description}
Desired output: {desired_output}

Provide:
1. A numbered list of Power Query steps in the order to apply them (e.g. "Remove Columns", "Split Column by Delimiter")
2. For any step requiring specific configuration (delimiter, column name, condition), state it precisely
3. The equivalent M code for any non-obvious/custom step
4. A note on which steps should be applied before vs after others, if order matters for correctness
5. Any step that should be marked to NOT auto-refresh column type detection if it could cause issues
```

## 📥 Example Input
```
source_description: CSV export with a single 'Full Name' column and inconsistent capitalization
desired_output: separate First Name / Last Name columns, proper case
```

## 📤 Example Output
```
1. Split Column by Delimiter: "Full Name" split by space (leftmost) into "First Name" / "Last Name"
2. Transform > Format > Capitalize Each Word on both new columns
3. Rename columns if needed

**M code for step 1:**
```
= Table.SplitColumn(Source, "Full Name", Splitter.SplitTextByDelimiter(" "), {"First Name", "Last Name"})
```
```

## 💡 Tips
- Describe source data issues precisely (inconsistent formats, extra spaces) so steps target the real problem

## ✅ Best Practices
- Order steps logically — cleaning before splitting, etc.
- Provide M code for any non-standard custom step

## ⚠️ Common Mistakes
- Applying transformations in an order that breaks downstream steps
- Not accounting for inconsistent source formatting (extra spaces, mixed case)
