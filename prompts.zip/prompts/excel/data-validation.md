# Excel Data Validation Rule Designer

> Design data validation rules to prevent bad data entry.

## 📋 Description
A prompt for producing precise data validation setups including dropdowns and custom formulas.

## 🎯 Purpose
To prevent invalid data entry at the source rather than cleaning it up later.

## ✅ When to Use
- Building a data entry template/form
- Restricting input to valid values

## 🔧 Variables
| Variable | Description |
|---|---|
| `field` | The field/column needing validation |
| `valid_criteria` | What counts as valid input |
| `error_behavior` | Whether to block invalid entry or just warn |

## 💬 Prompt

```
You are an Excel expert. Design a data validation rule.

Field: {field}
Valid criteria: {valid_criteria}
Error behavior: {error_behavior}

Provide:
1. The Data Validation type to use (List, Whole Number, Custom formula, Date, etc.)
2. The exact settings/formula to enter
3. A clear, specific error message and title for the alert box (not generic "Invalid input")
4. Setup steps (Data > Data Validation > ...)
5. If using a List, whether to source it from a named range (recommended for maintainability) vs. a hardcoded list
```

## 📥 Example Input
```
field: Discount Percentage
valid_criteria: must be between 0 and 50
error_behavior: block entry, show error
```

## 📤 Example Output
```
**Type:** Whole Number (or Decimal), between 0 and 50
**Error Alert:** Style = Stop, Title = "Invalid Discount", Message = "Enter a discount percentage between 0 and 50."
**Setup:** Select range > Data > Data Validation > Settings tab > Whole Number > Between 0 and 50 > Error Alert tab > configure message.
```

## 💡 Tips
- Specify whether invalid entry should be hard-blocked or just show a warning — behavior differs by use case

## ✅ Best Practices
- Write specific, actionable error messages, not generic ones
- Source dropdown lists from named ranges for easier maintenance

## ⚠️ Common Mistakes
- Generic unhelpful error messages that don't explain what's valid
- Hardcoding dropdown list values, making updates require re-editing the rule
