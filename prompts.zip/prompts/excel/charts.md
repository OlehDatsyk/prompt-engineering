# Excel Chart Recommendation & Setup

> Choose and configure the right chart type for your data.

## 📋 Description
A prompt for recommending the correct chart type and configuration for a dataset and goal.

## 🎯 Purpose
To avoid misleading or poorly chosen chart types by matching chart to data/goal.

## ✅ When to Use
- Deciding how to visualize a dataset
- Building a chart for a report or dashboard

## 🔧 Variables
| Variable | Description |
|---|---|
| `data_description` | What the data looks like, e.g. columns and structure |
| `goal` | What you want the chart to show/communicate |

## 💬 Prompt

```
You are a data visualization expert working in Excel. Recommend and configure a chart.

Data: {data_description}
Goal: {goal}

Provide:
1. Recommended chart type, with a one-sentence reason it fits this data/goal better than alternatives
2. What goes on each axis / as series
3. Step-by-step setup (Insert > Chart > ...)
4. Formatting recommendations (e.g. avoid 3D effects, use direct labels instead of a legend if few series)
5. A chart type to explicitly avoid for this data, and why (e.g. pie chart for a time series)

Prioritize clarity and accurate representation of the data over visual complexity.
```

## 📥 Example Input
```
data_description: monthly revenue for 3 product lines over 2 years
goal: show trend over time and compare product lines
```

## 📤 Example Output
```
**Recommended:** Line chart. Time series with multiple categories is best shown as trend lines, not bars or pie.

**Setup:** X-axis = Month, one line per product line (Series).
**Avoid:** Pie chart — it can't represent change over time at all.
```

## 💡 Tips
- Describe the data's shape (categorical vs time series, number of series) precisely — it determines the correct chart type

## ✅ Best Practices
- Match chart type to data structure (time series → line, comparison → bar)
- Avoid 3D effects and unnecessary chart junk

## ⚠️ Common Mistakes
- Using pie charts for time series or many-category data
- Defaulting to bar charts even when a line chart better shows trend
