# Financial Model Structure Generator

> Design the structure of an Excel financial model.

## 📋 Description
A prompt for producing a well-structured financial model layout with correct linking logic.

## 🎯 Purpose
To produce a sound, auditable financial model structure.

## ✅ When to Use
- Building a new financial model from scratch
- Structuring a forecast/budget spreadsheet

## 🔧 Variables
| Variable | Description |
|---|---|
| `model_purpose` | What the model is for, e.g. 3-statement model, startup forecast |
| `time_horizon` | Forecast period, e.g. monthly for 3 years |
| `key_drivers` | Key assumptions/drivers of the model |

## 💬 Prompt

```
You are a financial modeling expert (FP&A background). Design the structure for an Excel financial model.

Model purpose: {model_purpose}
Time horizon: {time_horizon}
Key drivers: {key_drivers}

Provide:
1. Recommended tab/sheet structure (e.g. Assumptions, Revenue Build, P&L, Cash Flow, Dashboard)
2. What belongs on the Assumptions tab, with all key drivers as clearly labeled, easily changeable input cells
3. The core formula logic linking assumptions to outputs (described, not full formulas, unless a specific formula is requested)
4. Best-practice formatting conventions to follow (e.g. blue font for inputs, black for formulas, no hardcoded numbers inside formula cells)
5. A sanity-check/error-check row recommendation (e.g. balance sheet balances check)

Follow standard financial modeling best practices (separation of inputs/calculations/outputs, no hardcoded values buried in formulas).
```

## 📥 Example Input
```
model_purpose: SaaS startup 3-year revenue and cash forecast
time_horizon: monthly, 36 months
key_drivers: new customers/month, churn rate, ARPU
```

## 📤 Example Output
```
**Tabs:** Assumptions, Revenue Build, Opex, Cash Flow, Dashboard

**Assumptions tab:** New customers/month (blue input cell), Monthly churn % (blue input), ARPU (blue input) — all editable, referenced by formulas elsewhere, never hardcoded downstream.

**Check row:** Ending cash balance should never go unexpectedly negative without a flag — add a conditional format alert.
```

## 💡 Tips
- State the model's core purpose clearly — a 3-statement model differs structurally from a simple forecast

## ✅ Best Practices
- Strictly separate inputs, calculations, and outputs across tabs
- Never hardcode numbers inside formula cells — always reference an input

## ⚠️ Common Mistakes
- Hardcoding assumption values directly inside formulas, making updates error-prone
- Mixing inputs and formulas on the same tab without visual distinction
