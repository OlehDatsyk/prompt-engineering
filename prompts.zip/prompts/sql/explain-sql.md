# SQL Query Explainer

> Explain what a SQL query does in plain language.

## 📋 Description
A prompt for translating complex SQL into a clear plain-language explanation.

## 🎯 Purpose
To understand unfamiliar or legacy SQL queries quickly.

## ✅ When to Use
- Inheriting a complex legacy query
- Documenting existing queries

## 🔧 Variables
| Variable | Description |
|---|---|
| `query` | The SQL query to explain |
| `audience` | Technical level of the reader, e.g. non-technical stakeholder, junior developer |

## 💬 Prompt

```
You are a database expert. Explain the following SQL query.

Query:
{query}

Audience: {audience}

Provide:
1. A one-sentence plain-language summary of what the query returns
2. A step-by-step breakdown of each clause (FROM/JOIN, WHERE, GROUP BY, HAVING, ORDER BY) in the order they logically execute, not the order they're written
3. Explanation pitched at the stated audience's technical level — avoid jargon for non-technical readers
4. Any subtlety worth flagging (e.g. a JOIN that could produce duplicate rows, an implicit NULL exclusion)
```

## 📥 Example Input
```
query: SELECT c.name, COUNT(o.id) FROM customers c LEFT JOIN orders o ON c.id=o.customer_id GROUP BY c.name HAVING COUNT(o.id) > 5
audience: junior developer
```

## 📤 Example Output
```
**Summary:** Returns customers who have placed more than 5 orders, including their order count.

**Breakdown:** The LEFT JOIN keeps all customers even those with zero orders; GROUP BY collapses rows per customer; HAVING filters groups after aggregation (unlike WHERE, which filters before).

**Subtlety:** Customers with no orders will have COUNT=0 and be excluded by HAVING > 5, which is correct here but worth knowing.
```

## 💡 Tips
- State the audience explicitly — the explanation should use very different language for stakeholders vs engineers

## ✅ Best Practices
- Explain execution order logically (FROM→WHERE→GROUP BY→HAVING→ORDER BY), not written order
- Flag subtle behaviors like JOIN duplication risk

## ⚠️ Common Mistakes
- Explaining clauses in written order rather than logical execution order
- Missing subtle correctness issues like duplicate rows from JOINs
