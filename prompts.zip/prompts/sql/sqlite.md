# SQLite-Specific Query Assistant

> Write queries accounting for SQLite's dynamic typing and constraints.

## 📋 Description
A prompt for producing correct queries that account for SQLite's specific behavior and limitations.

## 🎯 Purpose
To avoid SQLite-specific pitfalls given its dynamic typing and limited feature set.

## ✅ When to Use
- Working with a SQLite/embedded database
- Building queries for a mobile/local-first app

## 🔧 Variables
| Variable | Description |
|---|---|
| `task` | What the query should accomplish |
| `schema` | Relevant table schema |
| `constraints` | App context, e.g. mobile app local DB |

## 💬 Prompt

```
You are a SQLite expert. Write a query for the following task.

Task: {task}
Schema: {schema}
Context: {constraints}

Requirements:
- Account for SQLite's dynamic typing (type affinity, not strict types) — note if this could cause subtle bugs for the given schema
- Avoid features SQLite doesn't support (e.g. full RIGHT JOIN before 3.39, stored procedures, some ALTER TABLE operations) — flag if the task needs a workaround
- Use SQLite-appropriate date/time functions (julianday, strftime) rather than assuming standard SQL date functions work
- Keep queries efficient for embedded/mobile contexts (avoid unnecessary complexity given typically smaller local datasets)

Output the query, followed by a note on any SQLite-specific consideration.
```

## 📥 Example Input
```
task: get orders from the last 7 days
schema: orders(id, order_date TEXT, total REAL)
constraints: mobile app local database
```

## 📤 Example Output
```
```sql
SELECT id, order_date, total FROM orders
WHERE order_date >= datetime('now', '-7 days');
```
**Note:** SQLite stores dates as TEXT/REAL/INTEGER depending on convention used at insert time — ensure order_date is consistently stored in ISO8601 format for datetime() functions to work correctly.
```

## 💡 Tips
- Confirm how dates are actually stored (TEXT/INTEGER/REAL) since SQLite doesn't enforce a native date type

## ✅ Best Practices
- Use SQLite's own date/time functions rather than assuming standard SQL syntax works
- Flag unsupported features early rather than after implementation

## ⚠️ Common Mistakes
- Assuming a dedicated DATE type exists in SQLite when it uses type affinity instead
- Using unsupported syntax from other SQL dialects
