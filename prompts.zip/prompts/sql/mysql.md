# MySQL-Specific Query Assistant

> Write queries accounting for MySQL-specific behavior.

## 📋 Description
A prompt for producing correct queries that account for MySQL's specific syntax and quirks.

## 🎯 Purpose
To avoid MySQL-specific pitfalls (e.g. GROUP BY behavior, engine-specific locking).

## ✅ When to Use
- Working specifically with MySQL/MariaDB
- Migrating queries from another dialect to MySQL

## 🔧 Variables
| Variable | Description |
|---|---|
| `task` | What the query should accomplish |
| `schema` | Relevant table schema |
| `mysql_version` | MySQL version, e.g. 8.0 |

## 💬 Prompt

```
You are a MySQL expert. Write a query for the following task.

Task: {task}
Schema: {schema}
MySQL version: {mysql_version}

Requirements:
- Use ANSI_QUOTES-safe syntax (backticks for identifiers, not double quotes, unless sql_mode is confirmed otherwise)
- Be explicit about GROUP BY behavior — MySQL's ONLY_FULL_GROUP_BY mode (default since 5.7) requires all non-aggregated selected columns to be in GROUP BY; write compliant queries
- Use window functions/CTEs if MySQL 8.0+; note if a fallback is needed for pre-8.0
- Specify storage engine consideration if relevant (e.g. InnoDB row-level locking for transactional queries)

Output the query, followed by a version-compatibility note if relevant.
```

## 📥 Example Input
```
task: get each customer's most recent order
schema: orders(id, customer_id, order_date, total)
mysql_version: 8.0
```

## 📤 Example Output
```
```sql
SELECT customer_id, order_date, total FROM (
  SELECT *, ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY order_date DESC) AS rn
  FROM orders
) t WHERE rn = 1;
```
**Note:** Uses window functions, requiring MySQL 8.0+. For 5.7 or earlier, a correlated subquery approach would be needed instead.
```

## 💡 Tips
- Confirm MySQL version — window function/CTE support depends on 8.0+

## ✅ Best Practices
- Write ONLY_FULL_GROUP_BY-compliant queries by default
- Use backticks for identifiers for cross-mode compatibility

## ⚠️ Common Mistakes
- Non-compliant GROUP BY queries that fail under default MySQL 5.7+/8.0 settings
- Assuming window function support without checking version
