# Database Trigger Designer

> Design a trigger for automated database-level behavior.

## 📋 Description
A prompt for creating well-scoped, safe database triggers.

## 🎯 Purpose
To automate necessary database-level side effects reliably.

## ✅ When to Use
- Enforcing data integrity rules automatically
- Maintaining an audit log or derived value automatically

## 🔧 Variables
| Variable | Description |
|---|---|
| `event` | Table event, e.g. AFTER INSERT on orders |
| `desired_behavior` | What should happen when triggered |
| `dialect` | Database system |

## 💬 Prompt

```
You are a database engineer. Design a trigger.

Event: {event}
Desired behavior: {desired_behavior}
Dialect: {dialect}

Requirements:
- Write the full trigger definition and its associated function/procedure body
- Keep the trigger logic minimal and fast — avoid heavy computation or external calls inside a trigger
- Consider and state whether this logic might be better placed in application code instead of a trigger (triggers can create hidden, hard-to-debug behavior)
- Avoid recursive trigger risk if the trigger modifies the same table it fires on
- Add a comment explaining the trigger's purpose for future maintainers, since triggers are easy to overlook

Output the trigger code, followed by a note on maintainability considerations.
```

## 📥 Example Input
```
event: AFTER UPDATE on products (price column)
desired_behavior: log old and new price to a price_history table
dialect: PostgreSQL
```

## 📤 Example Output
```
```sql
CREATE OR REPLACE FUNCTION log_price_change() RETURNS TRIGGER AS $$
BEGIN
  IF OLD.price IS DISTINCT FROM NEW.price THEN
    INSERT INTO price_history(product_id, old_price, new_price, changed_at)
    VALUES (OLD.id, OLD.price, NEW.price, now());
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_log_price_change AFTER UPDATE ON products
FOR EACH ROW EXECUTE FUNCTION log_price_change();
```
**Note:** Consider whether this audit logging might be clearer as explicit application-layer code, since triggers are easy for future developers to miss.
```

## 💡 Tips
- Consider whether application-layer logic would be more maintainable than a trigger before committing to one

## ✅ Best Practices
- Keep trigger logic minimal and fast
- Document triggers clearly since they're easy to overlook during debugging

## ⚠️ Common Mistakes
- Heavy/slow logic inside triggers, hurting write performance
- Recursive trigger loops when a trigger modifies its own table without guards
