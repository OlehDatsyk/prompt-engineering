# SQL Query Optimizer

> Optimize a slow SQL query for better performance.

## 📋 Description
A prompt for analyzing and rewriting a SQL query to improve execution performance.

## 🎯 Purpose
To improve query performance based on reasoned analysis, not guesswork.

## ✅ When to Use
- A query is running slower than acceptable
- Preparing queries for scale

## 🔧 Variables
| Variable | Description |
|---|---|
| `query` | The SQL query to optimize |
| `schema` | Table schema including existing indexes |
| `performance_issue` | Observed symptom, e.g. slow on large table |

## 💬 Prompt

```
You are a database performance engineer. Optimize the following query.

Query:
{query}

Schema (including existing indexes): {schema}
Observed issue: {performance_issue}

Process:
1. Identify likely performance issues (missing indexes, unnecessary subqueries, implicit type conversions, SELECT *, non-sargable WHERE clauses)
2. Propose specific fixes for each issue found
3. Provide the optimized query
4. Recommend any new indexes, with the exact CREATE INDEX statement
5. Note any tradeoff of the optimization (e.g. index write overhead, changed result ordering)

Ensure the optimized query returns identical results to the original.
```

## 📥 Example Input
```
query: SELECT * FROM orders WHERE YEAR(order_date) = 2026
schema: orders(id, customer_id, order_date, total), no index on order_date
performance_issue: full table scan on a 5M row table
```

## 📤 Example Output
```
**Issue:** `YEAR(order_date) = 2026` is non-sargable — wrapping the column in a function prevents index usage even if one existed.

**Fix:**
```sql
SELECT id, customer_id, order_date, total
FROM orders
WHERE order_date >= '2026-01-01' AND order_date < '2027-01-01';
```
**Index:** `CREATE INDEX idx_orders_order_date ON orders(order_date);`
```

## 💡 Tips
- Include existing indexes in the schema so recommendations don't duplicate them

## ✅ Best Practices
- Avoid wrapping filtered columns in functions (non-sargable predicates)
- Verify optimized query returns identical results

## ⚠️ Common Mistakes
- Non-sargable WHERE clauses that prevent index usage
- Recommending redundant indexes that already exist
