# SQL JOIN Strategy Advisor

> Determine the correct JOIN type and structure for a multi-table query.

## 📋 Description
A prompt for choosing and constructing the correct JOIN logic for a given data need.

## 🎯 Purpose
To avoid common JOIN mistakes (wrong type, row duplication, unintended exclusions).

## ✅ When to Use
- Combining data from multiple tables
- Debugging unexpected row counts from a JOIN

## 🔧 Variables
| Variable | Description |
|---|---|
| `tables` | Tables involved and their relationship |
| `goal` | What the combined result should represent |
| `null_handling` | Whether unmatched rows should be included or excluded |

## 💬 Prompt

```
You are a database expert. Determine the correct JOIN strategy.

Tables and relationship: {tables}
Goal: {goal}
Should unmatched rows be included or excluded: {null_handling}

Provide:
1. The correct JOIN type (INNER, LEFT, RIGHT, FULL) with reasoning tied to the null_handling requirement
2. The full JOIN query
3. A warning if the relationship is one-to-many and could cause row duplication in aggregates, with the fix (e.g. pre-aggregate before joining)
4. How NULLs from an outer join should be handled in the SELECT/WHERE clause (e.g. COALESCE)
```

## 📥 Example Input
```
tables: customers (1) to orders (many)
goal: list all customers with their total order count, including customers with zero orders
null_handling: include unmatched (zero-order customers)
```

## 📤 Example Output
```
**JOIN type:** LEFT JOIN from customers to orders, since we must include customers with zero orders.

```sql
SELECT c.id, c.name, COUNT(o.id) AS order_count
FROM customers c
LEFT JOIN orders o ON c.id = o.customer_id
GROUP BY c.id, c.name;
```
**Note:** COUNT(o.id) correctly returns 0 for unmatched rows (not COUNT(*), which would return 1).
```

## 💡 Tips
- Clarify explicitly whether unmatched rows should appear — this determines INNER vs OUTER join choice

## ✅ Best Practices
- Use COUNT(column) not COUNT(*) when counting matched rows from an outer join
- Pre-aggregate one-to-many tables before joining to avoid duplication in sums

## ⚠️ Common Mistakes
- Using COUNT(*) after a LEFT JOIN, incorrectly counting unmatched rows as 1
- Row duplication in SUM/AVG due to unaggregated one-to-many joins
