# Database Index Strategy Advisor

> Recommend the right indexes for a table's query patterns.

## 📋 Description
A prompt for designing an index strategy based on actual query patterns.

## 🎯 Purpose
To improve query performance through targeted indexing without over-indexing.

## ✅ When to Use
- Designing indexes for a new table
- Diagnosing why queries are slow despite reasonable design

## 🔧 Variables
| Variable | Description |
|---|---|
| `table_schema` | Table structure |
| `common_queries` | The queries typically run against this table |
| `write_frequency` | How frequently the table is written to |

## 💬 Prompt

```
You are a database performance expert. Recommend an index strategy.

Table schema: {table_schema}
Common queries run against it: {common_queries}
Write frequency: {write_frequency}

Provide:
1. Recommended indexes, each with the exact CREATE INDEX statement
2. For each index, which specific query it optimizes and why (column order matters for composite indexes — explain the order chosen)
3. A note on the write-performance tradeoff given the stated write frequency — don't over-index a heavily-written table
4. Any redundant/overlapping index to avoid creating
5. Whether a covering index would help avoid a table lookup for the most frequent query
```

## 📥 Example Input
```
table_schema: orders(id, customer_id, status, created_at, total)
common_queries: filter by customer_id + status, sort by created_at desc
write_frequency: high (thousands of inserts/hour)
```

## 📤 Example Output
```
**Index:** `CREATE INDEX idx_orders_customer_status_created ON orders(customer_id, status, created_at DESC);`
**Why this order:** customer_id first (most selective, equality filter), then status (equality), then created_at (range/sort) — matches left-to-right index usage rules.
**Tradeoff:** Given high write frequency, avoid adding more than 2-3 indexes on this table; each index adds insert overhead.
```

## 💡 Tips
- Provide actual common query patterns, not just the schema — index design depends entirely on query shape

## ✅ Best Practices
- Order composite index columns: equality filters first, range/sort columns last
- Balance index count against write-heavy workload overhead

## ⚠️ Common Mistakes
- Wrong column order in composite indexes, making them ineffective
- Over-indexing a write-heavy table, hurting insert performance
