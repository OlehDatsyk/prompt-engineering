# Stored Procedure Generator

> Generate a stored procedure with proper parameter handling and error handling.

## 📋 Description
A prompt for producing production-quality stored procedures.

## 🎯 Purpose
To encapsulate reusable database logic safely and efficiently.

## ✅ When to Use
- Encapsulating multi-step database logic
- Building a reusable data operation callable from application code

## 🔧 Variables
| Variable | Description |
|---|---|
| `task` | What the procedure should do |
| `parameters` | Input parameters needed |
| `dialect` | Database system, e.g. PostgreSQL, SQL Server |

## 💬 Prompt

```
You are a database engineer. Write a stored procedure.

Task: {task}
Parameters: {parameters}
Dialect: {dialect}

Requirements:
- Validate input parameters explicitly at the start (e.g. reject negative values, null required fields) and raise a clear error if invalid
- Use transactions where multiple write operations must succeed or fail together
- Include error handling appropriate to the dialect (TRY/CATCH for SQL Server, EXCEPTION blocks for PostgreSQL)
- Add comments explaining non-obvious logic
- Avoid dynamic SQL unless necessary; if used, ensure it's parameterized to prevent injection

Output the full procedure code, followed by an example call.
```

## 📥 Example Input
```
task: transfer funds between two accounts atomically
parameters: from_account_id, to_account_id, amount
dialect: PostgreSQL
```

## 📤 Example Output
```
```sql
CREATE OR REPLACE PROCEDURE transfer_funds(from_id INT, to_id INT, amt NUMERIC) AS $$
BEGIN
  IF amt <= 0 THEN RAISE EXCEPTION 'Amount must be positive'; END IF;
  UPDATE accounts SET balance = balance - amt WHERE id = from_id;
  UPDATE accounts SET balance = balance + amt WHERE id = to_id;
END;
$$ LANGUAGE plpgsql;
```
**Call:** `CALL transfer_funds(1, 2, 100.00);`
```

## 💡 Tips
- Specify the exact dialect — TRY/CATCH, exception handling, and syntax vary significantly

## ✅ Best Practices
- Wrap multi-step writes in transactions for atomicity
- Validate all input parameters before performing operations

## ⚠️ Common Mistakes
- Missing transaction wrapping, leaving data in an inconsistent state on partial failure
- Using unparameterized dynamic SQL, risking injection
