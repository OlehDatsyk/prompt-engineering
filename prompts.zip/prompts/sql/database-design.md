# Database Schema Design Assistant

> Design a normalized relational schema from requirements.

## 📋 Description
A prompt for producing a well-normalized database schema with proper relationships and constraints.

## 🎯 Purpose
To produce a sound relational schema design avoiding common normalization mistakes.

## ✅ When to Use
- Designing a new database from scratch
- Reviewing/refactoring an existing schema

## 🔧 Variables
| Variable | Description |
|---|---|
| `domain` | The business domain/entities involved |
| `requirements` | Key functional requirements |
| `scale_expectations` | Expected data volume/growth |

## 💬 Prompt

```
You are a database architect. Design a relational schema.

Domain: {domain}
Requirements: {requirements}
Scale expectations: {scale_expectations}

Provide:
1. List of tables/entities with their key columns and data types
2. Primary keys and foreign key relationships, described clearly
3. Normalization level applied (aim for 3NF unless a specific denormalization is justified for the stated scale)
4. A Mermaid ER diagram representing the schema
5. Constraints to enforce data integrity (NOT NULL, UNIQUE, CHECK constraints) with reasoning
6. Any deliberate denormalization decision, explicitly justified against the stated scale/requirements

Avoid over-normalizing to the point of requiring excessive JOINs for common queries, if scale/requirements justify some denormalization.
```

## 📥 Example Input
```
domain: e-commerce order system
requirements: customers, products with variants, orders with multiple line items, inventory tracking
scale_expectations: 100K orders/month
```

## 📤 Example Output
```
**Tables:** customers, products, product_variants, orders, order_items, inventory

```mermaid
erDiagram
  customers ||--o{ orders : places
  orders ||--o{ order_items : contains
  products ||--o{ product_variants : has
```

**Constraint:** `order_items.quantity CHECK (quantity > 0)` to prevent invalid line items.
```

## 💡 Tips
- State expected scale — it affects whether normalization or denormalization tradeoffs are justified

## ✅ Best Practices
- Default to 3NF; justify any denormalization explicitly
- Add CHECK/NOT NULL/UNIQUE constraints to enforce integrity at the DB level

## ⚠️ Common Mistakes
- Over-normalizing to the point of requiring excessive JOINs for basic queries
- Missing constraints, allowing invalid data (negative quantities, duplicate emails)
