# SQL Debugging Assistant

> Diagnose why a SQL query returns wrong or unexpected results.

## 📋 Description
A prompt for systematically debugging incorrect SQL query output.

## 🎯 Purpose
To find the actual root cause of incorrect query results rather than guessing.

## ✅ When to Use
- A query returns unexpected/wrong results
- A query errors out and the cause is unclear

## 🔧 Variables
| Variable | Description |
|---|---|
| `query` | The problematic query |
| `schema` | Relevant table schema |
| `expected_result` | What you expected |
| `actual_result` | What you actually got or the error message |

## 💬 Prompt

```
You are a database debugging expert. Diagnose the following issue.

Query:
{query}

Schema: {schema}
Expected result: {expected_result}
Actual result / error: {actual_result}

Process:
1. Identify the most likely root cause with clear reasoning (e.g. JOIN causing row multiplication, incorrect NULL handling, wrong aggregation grouping)
2. If it's a syntax error, pinpoint the exact clause causing it
3. Provide the corrected query
4. Explain specifically why the original produced the wrong result — trace through the logic
5. Suggest a way to verify the fix (e.g. a smaller test case or a sanity-check query)
```

## 📥 Example Input
```
query: SELECT customer_id, SUM(total) FROM orders JOIN refunds ON orders.id=refunds.order_id GROUP BY customer_id
schema: orders(id, customer_id, total), refunds(id, order_id, amount)
expected_result: total spend per customer
actual_result: totals are way too high
```

## 📤 Example Output
```
**Root cause:** The INNER JOIN to refunds multiplies each order row by the number of matching refund rows, inflating the SUM. Also, orders with no refunds are silently excluded.

**Fix:**
```sql
SELECT customer_id, SUM(total) FROM orders GROUP BY customer_id; -- refunds should be handled separately
```
```

## 💡 Tips
- Always include the exact error message or a concrete example of wrong output, not a paraphrase

## ✅ Best Practices
- Trace through the logic to explain why the bug produces the observed wrong result
- Suggest a verification step for the fix

## ⚠️ Common Mistakes
- JOINs causing unintended row multiplication in aggregates
- Guessing at a fix without tracing the actual cause
