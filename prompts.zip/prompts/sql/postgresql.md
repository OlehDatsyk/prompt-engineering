# PostgreSQL-Specific Query Assistant

> Write queries leveraging PostgreSQL-specific features.

## 📋 Description
A prompt for producing queries that take advantage of PostgreSQL's specific capabilities.

## 🎯 Purpose
To leverage PostgreSQL-specific features (JSONB, arrays, window functions, CTEs) correctly.

## ✅ When to Use
- Working with PostgreSQL-specific data types
- Needing advanced query features like window functions or CTEs

## 🔧 Variables
| Variable | Description |
|---|---|
| `task` | What the query should accomplish |
| `schema` | Relevant table schema, including any JSONB/array columns |
| `pg_version` | PostgreSQL version if relevant |

## 💬 Prompt

```
You are a PostgreSQL expert. Write a query for the following task, using PostgreSQL-specific features where they provide a genuine advantage.

Task: {task}
Schema: {schema}
PostgreSQL version: {pg_version}

Requirements:
- Use PostgreSQL-specific syntax (JSONB operators, array functions, window functions, CTEs) where it produces cleaner/faster SQL than standard alternatives
- Explain any PostgreSQL-specific operator used (e.g. ->>, @>, ILIKE) for readers less familiar with them
- Note if a feature used requires a specific minimum PostgreSQL version
- Ensure JSONB queries use appropriate GIN index recommendations if querying JSONB fields frequently
```

## 📥 Example Input
```
task: find users whose settings JSONB contains {"notifications": true}
schema: users(id, settings JSONB)
pg_version: 15
```

## 📤 Example Output
```
```sql
SELECT id FROM users WHERE settings @> '{"notifications": true}'::jsonb;
```
**Explanation:** `@>` is the JSONB containment operator, checking if settings contains the given key-value pair.
**Index recommendation:** `CREATE INDEX idx_users_settings ON users USING GIN(settings);` for fast containment queries at scale.
```

## 💡 Tips
- State the PostgreSQL version if using newer features like MERGE (added in PG15)

## ✅ Best Practices
- Recommend GIN indexes for frequently-queried JSONB columns
- Explain PostgreSQL-specific operators for team readability

## ⚠️ Common Mistakes
- Using JSONB containment queries at scale without a GIN index
- Using version-specific syntax without confirming compatibility
