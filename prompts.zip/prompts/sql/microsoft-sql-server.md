# SQL Server-Specific Query Assistant

> Write queries leveraging T-SQL specific features correctly.

## 📋 Description
A prompt for producing correct T-SQL accounting for SQL Server-specific syntax and behavior.

## 🎯 Purpose
To leverage T-SQL specific features (CTEs, TOP, MERGE, TRY/CATCH) correctly.

## ✅ When to Use
- Working specifically with Microsoft SQL Server
- Writing T-SQL stored logic or complex queries

## 🔧 Variables
| Variable | Description |
|---|---|
| `task` | What the query/procedure should accomplish |
| `schema` | Relevant table schema |
| `sql_server_version` | SQL Server version, if relevant |

## 💬 Prompt

```
You are a Microsoft SQL Server (T-SQL) expert. Write a query/script for the following task.

Task: {task}
Schema: {schema}
SQL Server version: {sql_server_version}

Requirements:
- Use T-SQL syntax correctly: TOP instead of LIMIT, GETDATE()/SYSDATETIME() for current time, proper square-bracket identifier quoting where needed
- Use TRY/CATCH for error handling in procedural code, not generic exception syntax from other dialects
- Use appropriate isolation level/locking hints only when genuinely needed, and explain why
- Note any version-specific feature used (e.g. STRING_AGG requires SQL Server 2017+)

Output the query/script, followed by a version-compatibility note if relevant.
```

## 📥 Example Input
```
task: get the top 10 highest-value orders with a running total
schema: orders(id, customer_id, order_date, total)
sql_server_version: SQL Server 2019
```

## 📤 Example Output
```
```sql
SELECT TOP 10 id, total,
  SUM(total) OVER (ORDER BY total DESC ROWS UNBOUNDED PRECEDING) AS running_total
FROM orders
ORDER BY total DESC;
```
**Note:** Window functions with frame clauses are supported from SQL Server 2012+, well within the stated 2019 version.
```

## 💡 Tips
- Confirm SQL Server version for features like STRING_AGG (2017+) or newer JSON functions

## ✅ Best Practices
- Use TOP not LIMIT for T-SQL row limiting
- Use TRY/CATCH for T-SQL error handling, not other dialects' syntax

## ⚠️ Common Mistakes
- Using LIMIT (not valid T-SQL) instead of TOP
- Mixing other dialects' exception handling syntax into T-SQL code
