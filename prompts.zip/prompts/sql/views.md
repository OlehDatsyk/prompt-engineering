# SQL View Designer

> Design a database view for a recurring query need.

## 📋 Description
A prompt for creating well-structured, maintainable SQL views.

## 🎯 Purpose
To simplify repeated complex queries and provide a stable interface to underlying data.

## ✅ When to Use
- A complex query is used repeatedly across the application
- Providing a simplified data interface to other teams

## 🔧 Variables
| Variable | Description |
|---|---|
| `purpose` | What the view should provide |
| `underlying_tables` | Tables the view will query |
| `materialized` | Whether a materialized view is appropriate |

## 💬 Prompt

```
You are a database architect. Design a SQL view.

Purpose: {purpose}
Underlying tables: {underlying_tables}
Materialized view appropriate: {materialized}

Provide:
1. The CREATE VIEW (or CREATE MATERIALIZED VIEW) statement
2. Reasoning for whether a regular or materialized view is more appropriate given the purpose (materialized trades freshness for read performance)
3. If materialized, the recommended refresh strategy (e.g. on schedule, on-demand, trigger-based)
4. Any performance consideration for querying the view (e.g. underlying JOIN cost still applies on a regular view)
5. Naming convention suggestion consistent with common SQL conventions (e.g. vw_ prefix)
```

## 📥 Example Input
```
purpose: simplified access to active customers with their lifetime order value
underlying_tables: customers, orders
materialized: query is expensive and used in a dashboard refreshed hourly
```

## 📤 Example Output
```
```sql
CREATE MATERIALIZED VIEW vw_customer_ltv AS
SELECT c.id, c.name, SUM(o.total) AS lifetime_value
FROM customers c JOIN orders o ON c.id = o.customer_id
WHERE c.is_active = true
GROUP BY c.id, c.name;
```
**Refresh:** Schedule `REFRESH MATERIALIZED VIEW vw_customer_ltv` hourly via a scheduled job, matching the dashboard's refresh cadence.
```

## 💡 Tips
- State how fresh the data needs to be — it directly determines regular vs materialized view choice

## ✅ Best Practices
- Use materialized views only when read performance matters more than real-time freshness
- Follow a consistent naming convention for views

## ⚠️ Common Mistakes
- Using materialized views for data that must always be real-time
- Forgetting to schedule refreshes for materialized views, causing stale data
