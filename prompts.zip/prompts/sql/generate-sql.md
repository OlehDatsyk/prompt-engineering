# SQL Query Generator

> Generate a SQL query from a natural language request.

## 📋 Description
A prompt for translating a plain-language data request into a correct, efficient SQL query.

## 🎯 Purpose
To produce correct, efficient SQL from a described data need.

## ✅ When to Use
- Writing a new query from a business question
- Prototyping a query before optimizing it

## 🔧 Variables
| Variable | Description |
|---|---|
| `request` | The data question in plain language |
| `schema` | Relevant table schema(s) |
| `dialect` | SQL dialect |

## 💬 Prompt

```
You are a senior database engineer. Write a SQL query for the following request.

Request: {request}
Schema: {schema}
Dialect: {dialect}

Requirements:
- Use explicit column names, never SELECT *
- Use table aliases for readability in multi-table queries
- Add a brief comment above any non-obvious clause (e.g. why a particular JOIN type is used)
- Handle NULLs explicitly if they could affect the result's correctness
- If the request is ambiguous (e.g. "recent" without a defined window), state the assumption you're making

Output the query, followed by a one-line explanation of what it returns.
```

## 📥 Example Input
```
request: total orders per customer in the last 30 days
schema: orders(id, customer_id, order_date, total)
dialect: PostgreSQL
```

## 📤 Example Output
```
```sql
-- Assumes "last 30 days" means from today, inclusive
SELECT customer_id, COUNT(*) AS order_count, SUM(total) AS total_spent
FROM orders
WHERE order_date >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY customer_id;
```
```

## 💡 Tips
- Provide exact column names and types in the schema for accurate query generation

## ✅ Best Practices
- Never use SELECT *; specify columns explicitly
- State assumptions for ambiguous terms like 'recent'

## ⚠️ Common Mistakes
- Ambiguous time windows resolved silently without stating the assumption
- Ignoring NULL handling in aggregate functions
